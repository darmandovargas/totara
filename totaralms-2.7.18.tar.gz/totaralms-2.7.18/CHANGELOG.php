<?php
/*

Totara LMS Changelog

Release 2.7.18 (23rd August 2016):
==================================


Security issues:

    TL-9448        Search terms when searching user messaging are now strictly escaped

                   Previously it was possible to use the wildcard "%" character when searching
                   for users on the Messages page, and doing so would return a list of all
                   users.
                   While the result is correct, allowing the use of the wildcard character
                   here means large result sets can be easily returned.
                   While not strictly a security issue such functionality could be targeted by
                   the likes of DOS attacks as an effective page on which to generate
                   arbitrary load.
                   The search term is now strictly escaped, and "%" is now searched for as a
                   literal.

Bug fixes:

    TL-7902        Attempting to assign a manager that would lead to a circular dependency now results in a validation error

                   Previously it was possible to create a circular reporting path which could
                   lead to unexpected behaviour and possible errors.
                   A validation error is now displayed when attempting to set a users manager
                   if it would result in a circular reporting path.

    TL-9196        Course set completion state is now reset when editing Certification completion records

                   When a certification completion record is changed from "Certified, before
                   window opens" to any other state using the certification completion editor,
                   the corresponding course set completion records will be reset.
                   This prevents users being re-marked certified due to these records when
                   cron runs.
                   Please note that changes in the certification completion editor do not
                   affect course completion. And as a consequence, if the courses contained in
                   the course sets are still marked complete then this may lead to the course
                   sets being marked complete again. This may lead to re-certification.

    TL-9222        The Program and Certification completion editor now shows how a user is assigned
    TL-9262        Fixed a bug with Face-to-face iCal attachments for sessions with multiple dates

                   Previously when loading an iCal attachment from a Face-to-face seminar with
                   multiple dates into your chosen calendar application only a single date
                   (the first date) may have been imported.
                   Now the iCal attachment contains all of the correct information to allow
                   the calendar application to import the event on multiple dates.

    TL-9394        Fixed inconsistent timezone handling in Face-to-face notifications when "User timezone" was selected
    TL-9395        Fixed inconsistent timezone handling on the "My Bookings" page in Face-to-face
    TL-9449        Improved the performance of the Course and Certification completion import report sources
    TL-9777        Fixed Face-to-face unit tests to use site specific module ids for testing
    TL-9820        Improved the reliability of behat testing when executing multiple scenarios

Contributions:

    * Eugene Venter at Catalyst NZ - TL-9777


Release 2.7.17 (26th July 2016):
================================


Important:

    TL-9702        This release contains fixes made in Moodle 2.7.15

                   Moodle 2.7.15 received two fixes as noted below:

                   1. MDL-55069 core: escape special characters in email headers
                      Imported as TL-9515
                   2. MDL-53019 environment: 3.2 requirements added
                      Imported as TL-9556


Security issues:

    TL-9340        Fixed access control when deleting calendar subscriptions

                   Users can only delete their own calendar subscriptions.
                   Previously it was possible to craft a special request that would allow you
                   to delete a calendar subscription regardless of whether you were the owner
                   or not.
                   The moodle/calendar:manageownentries capability is now consistently
                   checked.

    TL-9400        Fixed access control when deleting personal goals

                   A user's personal goals can only be deleted if one of the following
                   conditions is true for the current user:

                   1. They have the totara/hierarchy:managegoalassignments capability in the
                   system context.
                   2. They are a manager of the goal's owner and they have the
                   totara/hierarchy:managestaffpersonalgoal capability in the users context.
                   3. It is one of their own personal goals and they have the
                   totara/hierarchy:manageownpersonalgoal capability in the system context.

                   Previously it was possible to craft a special request that would allow you
                   to delete any personal goal, regardless of whether it was one of your
                   personal goals or not.
                   The relevant capability checks are now consistently applied.

    TL-9515        Fixed sanitisation of user's firstname and lastname when sending emails

                   Totara was not previously sanitising the users firstname and lastname
                   correct when compiling emails to the user.
                   An authenticated user could therefor alter their firstname or lastname in
                   Totara to contain invalid content including additional email addresses.
                   As their firstname and lastname was not being correctly sanitised this
                   could be abused to send spam to others.
                   The users firstname and lastname is now properly sanitised.

                   References MDL-55069

Improvements:

    TL-9221        Added the ability to resolve dismissed program exceptions to the completion editor

                   The Program and Certification completion editors now display information
                   about dismissed program exceptions when viewing a user's completion data,
                   and allow dismissed exceptions to be overridden.

    TL-9314        Improved the information shown when viewing a Certification

                   When a user views one of their certifications, they will see a more verbose
                   description of the status.
                   It is now clear when a user is not required to work on a certification.
                   When working on a specific certification path, only courses in that path
                   are shown (as before), otherwise both paths are shown, rather than trying
                   to show the last path completed (which cannot be calculated under several
                   circumstances).

                   Additionally, a warning has been added, and is shown when the user is due
                   to recertify but the window opening process has not yet occurred.

    TL-9383        Improved the performance of sidebar searches within Report Builder

                   For reports which had multi-check filters enabled in the sidebar, such as
                   in the course catalog, item counts shown in the filter were sometimes being
                   queried twice unnecessarily.
                   In cases where there were thousands of items, this had a noticeable effect
                   on performance.
                   These items counts are now only queried once, and only if needed.

    TL-9483        Fixed Behat file uploads to work in all browsers and in remote selenium instances
    TL-9484        Added a workaround for missing alert confirmation support in PhantomJS
    TL-9556        Environment definition updated to reflect Moodle 3.2 requirements

Bug fixes:

    TL-7907        Fixed manager approval for Face-to-face direct enrolment when automatic signup is enabled

                   Previously if you had a Face-to-face activity that was configured to
                   require manager approval, within a course with a Face-to-face direct
                   enrolment instance added and configured to automatically sign new users up
                   to all available sessions, then when a new user signed up they would be
                   automatically booked to the session requiring manager approval, bypassing
                   the approval stage.
                   Now the Face-to-face direct enrolment plugin, with automatic signup
                   enabled, correctly respects the manager approval requirements for available
                   sessions.

    TL-8601        Fixed backup and restore of multi-select and file type Course custom fields
    TL-8985        Suspending a user no longer cancels past Face-to-face signups

                   Previously if you suspended a user any Face-to-face signups they had made
                   would be cancelled. Even when the Face-to-face session had already been
                   run.
                   Now when a user is suspended only Face-to-face signups for future sessions
                   are cancelled.

    TL-9056        Fixed program enrolment messages not being sent

                   It was possible that some program and certification enrolment messages were
                   not being sent. This would only occur in the unlikely event that the
                   program messaging scheduled task took some time to run, and that program
                   assignments changed during that time (either by a manual change made in the
                   Assignments interface when there were less than 200 users involved in the
                   program, or due to one of the two user assignment scheduled tasks running
                   at the same time). This has now been fixed. This patch does not
                   retroactively send program/certification enrolment messages that were
                   missed.

    TL-9086        HR Import now validates incoming user custom field values consistently

                   Previously HR Import was validating incoming user custom field data without
                   first passing it through the user custom fields API.
                   This could lead to invalid data passing validation as it had not been
                   appropriately translated.
                   HR Import now correctly passes incoming data through the user custom fields
                   API prior to validation to ensure any invalid data is detected and not
                   imported.

    TL-9116        Fixed broken images when viewing the description for a live Appraisal
    TL-9118        HR Import now converts mixed case usernames to lower case

                   This fixes a backwards compatibility issue introduced by TL-8502.
                   TL-8502 improved validation of usernames being imported through HR Import.
                   Unfortunately a previously added hack was present which was converting
                   mixed case usernames to lower case.
                   TL-8502 reverted this hack, ensuring only completely valid usernames could
                   be imported, and any invalid usernames would be skipped with an error.
                   After the release of 2.9.7 we received several reports of people relying on
                   this conversion to import their data.
                   After much discussion we decided to treat this as a backwards compatibility
                   issue and fix it as a bug in 2.7 and 2.9.
                   Now when you import a username with mixed case you will receive a warning,
                   the username will be converted to lower case and the user will be
                   imported.
                   Please note that in Totara 9.0 you will receive an error and the user will
                   not be imported.
                   We advise those who are getting these warning to fix the data they are
                   importing so as to make it accurate.

    TL-9135        Fixed the use of files within textarea type custom fields
    TL-9159        Multi-select custom field data params are now correctly deleted when the field is deleted

                   Previously data params for multi-select custom field values were not being
                   deleted when the multi-select custom field was deleted.
                   This resulted in orphaned data param records being left in the database.
                   Now when a multi-select custom field is deleted the data params for it are
                   also deleted.
                   Additionally an upgrade step will clean up any orphaned multi-select data
                   params that may be lurking in your database.

    TL-9187        Fixed searching of the Program exceptions list by firstname and lastname
    TL-9210        Fixed a missing iCal attachment in the Face-to-face session allocation notification email
    TL-9235        Fixed the display of aggregated yes_or_no Report Builder columns

                   "Yes" is counted as 1, "No" is counted as 0. Aggregate functions use these
                   values for the calculations.

    TL-9387        Fixed the display of Face-to-face sessions in the Face-to-face block
    TL-9392        Available courses on the front page are no longer duplicated when the user is not enrolled in any courses

                   If the front page had been configured to display a list of Enrolled Courses
                   and the user was not enrolled on any courses then a list of available
                   courses would be displayed in stead.
                   Previously if you had also configured the front page to contain a list of
                   available courses this would then lead to the list of available courses
                   being displayed twice.
                   Now when the front page has been configured to display a list of available
                   courses and enrolled courses, when the user is not enrolled on courses then
                   nothing is printed.
                   This stops the list of available courses from being printed twice.

    TL-9397        Fixed an error encountered while exporting a Face-to-face cancellation report

                   This fixes a regression introduced by TL-6962, released in Totara 2.7.14,
                   2.9.6.

    TL-9438        Fixed average aggregation within Report Builder when using MSSQL

                   MSSQL now ensures that it is using decimals when fetching average
                   aggregations.

    TL-9453        Prevented the adding of a Program to a Learning Plan from resetting Program status

                   When a program was already assigned to a user, if the same program was then
                   added to the user's learning plan, the status of the program was reset. The
                   program would likely be re-marked completed by cron, but only if the course
                   requirements were unchanged and the courses involved were still marked
                   complete.
                   Additionally, dates related to the program may have changed.
                   This fix prevents changes when adding a program to a learning plan if the
                   user is already assigned to the program.

    TL-9485        Fixed data param handling in the core data object class
    TL-9669        Fixed the possibility of a "maximum SQL input variables" bug within the Face-to-face upgrade

Contributions:

    * Davo Smith at Synergy Learning - TL-9485
    * Francis Devine at Catalyst NZ - TL-9086
    * Nigel Cunningham at Catalyst AU - TL-8601


Release 2.7.16 (14th June 2016):
================================


Important:

    TL-9190        Fixed Face-to-face session deletion custom field data loss

                   This is a regression introduced by TL-6962 in Totara 2.9.6, and 2.7.14,
                   both released April 2016.
                   In these releases the foreign key for Face-to-face custom fields was
                   changed from the "facetoface_signups_status" table to the
                   "facetoface_signups" table to ensure that data entered by the user was
                   maintained when their session signup status changed.
                   However the session deletion code was overlooked and was still using the
                   old relation to wipe the associated custom field data.
                   If a user deleted a Face-to-face session it may have incorrectly deleted
                   custom field data belonging to a different session.
                   This patch fixes the deletion code so it is using the correct relation and
                   ensures that when the session is deleted, the correct custom field data is
                   also deleted.

                   If you are on either of the mentioned versions we strongly recommend
                   upgrading to the latest release.


Improvements:

    TL-8708        Face-to-face session and event durations can now be aggregated and graphed

                   Face-to-face report sources now handle durations as integers.
                   This allows the the duration field to be aggregated, and used in graphs if
                   so desired.
                   The display of the field within the report is unchanged.


Bug fixes:

    TL-8152        Fixed the deletion of user accounts with empty email addresses

                   Previously if you attempted to delete two or more user accounts with empty
                   email addresses at the same time you would get an error.
                   This was visible most commonly in HR Import.
                   This has now been fixed. A unique non-numeric username is now generated as
                   a holding username during deletion.

    TL-8410        Fixed date validation when uploading Course and Certification completion data

                   Completion dates in course and certification uploads are now more
                   thoroughly validated.
                   If the value for the month is greater than 12, or the value for the day is
                   greater than what should be in the month, the date will be considered
                   invalid and the row will not be processed.

                   This patch also fixes a minor issue with how line endings are processed.
                   Now prior to processing the uploaded file all line endings in the file are
                   normalised.
                   This ensures that files generated on different operating systems are all
                   processed identically.

    TL-8650        Fixed result counting discrepancies within Appraisal reports

                   On the appraisals reports page there is a list of appraisals with counts
                   for "Overdue", "On target", "Complete", etc. There were some discrepancies
                   between these numbers and the reports displayed when clicking on the
                   counts.

    TL-8688        Corrected Face-to-face attendees dialog URL handling to prevent accidental removal of all attendees

                   Prior to this change, in some circumstances, the Face-to-face attendees
                   dialog would generate unexpected URL parameter value combinations which
                   could result in the removal of all users from the attendee list.

    TL-8790        Fixed the display of the user's full name for the roles column within the Face-to-face sessions report
    TL-8874        Face-to-face booking confirmation notification no longer ignores the "Manager copy" setting

                   Prior to this change the booking confirmation notification would be sent to
                   the attendee's manager even if the "Manager copy" setting was turned off.
                   The booking confirmation notification now correctly checks this setting.

    TL-8924        Fixed a display issue with empty due dates on the Program assignments tab
    TL-9074        Fixed searching within the audience filter when the context id is not set
    TL-9102        The "Hide cost and discount" Face-to-face setting now correctly hides the discount code
    TL-9103        Fixed Face-to-face session location custom field filters
    TL-9248        Brackets are now correctly escaped during "LIKE" searches when using MSSQL

                   Previously during "LIKE" search operations, brackets "[" and "]" were not
                   being correctly escaped, which could on occasion lead to incorrect
                   results.
                   This was not exploitable but could have made searching difficult for some
                   MSSQL sites.

    TL-9273        Fixed MSSQL database structure consistency for sites upgraded from old Moodle installations


Release 2.7.15 (23rd May 2016):
===============================


Important:

    TL-7818        Changed certification window opening to also reset RPL activities

                   Previously, when the recertification window opened, RPL course completions
                   were being reset, but RPL activity completions were not. This could cause
                   the situation where a course would re-complete due the RPL activity
                   completions, which in turn triggered certification completion. Depending on
                   certification settings, this could cause a repeating loop. Now, like
                   courses, RPL activity completions will also be reset when the
                   recertification window opens.

                   This change in behaviour brings Totara 2.5, 2.6 and 2.7 in line with 2.9
                   (which has had this change since 2.9.0).

    TL-8973        Activity completions will now always reset on archive regardless of their visibility

                   When activity completions were archived during a certification window
                   opening, the completions for activities set to hidden were ignored and
                   would be retained. Activity completions are now archived regardless of
                   their visibility.

                   This patch also fixes an issue where Face-to-face completion data was not
                   being fully reset if the completion time of the Face-to-face activity was
                   changed to a later time.

                   This change means that after the archive_course_activities function is run,
                   any activities that should not be complete will have no record in the
                   course_modules_completion table, rather than have one which is set to
                   incomplete.

                   As well as affecting certification window opening, these changes will also
                   apply when using the archive completions function within a course.


Security issues:

    TL-9057        Added sesskey checks when applying automatic fixes on the check completions page in the Program completion editor


Improvements:

    TL-7993        Removed the obsolete 'Manager emails' settings from Face-to-face
    TL-8237        Improved the reliability of behat in Firefox and Chrome using the latest version of Selenium

                   The behat integration has been tuned for the latest releases of Selenium.
                   Several old "hacks" made in Totara to get behat working have been removed
                   as the Selenium drivers have improved. This has greatly improved both the
                   performance and reliability of behat in core, though could have some impact
                   on any custom behat tests.

    TL-8376        Refactored the Face-to-face completion state SQL to improve performance
    TL-8665        Added an environment check for "always_populate_raw_post_data"
    TL-8705        Improved how deleted users are being handled on the browse list of users page

                   The detection of legacy deleted users, checking that their email address
                   field is set to an MD5, has been improved by using a regular expression.
                   Users who have an invalid email address (without an @ symbol) will now show
                   in the user list on the "Browse list of users" page.

    TL-9001        Backported mysqli improvement MDL-53944 for sql_cast_char2real()
    TL-9020        Created initial Program and Certification completion transaction logs

                   If a user assigned to a Program or Certification did not have any
                   transaction logs, a snapshot log record will be created during upgrade.
                   Likewise, a certification settings snapshot will be created if none exists.
                   This will help with diagnosing future problems.

    TL-9022        Added confirmation when applying automated fixes to program completions

                   When using the program or certification completion checker or editor, when
                   you activate one of the fixes, you will now need to confirm the action.
                   This is to prevent accidental clicks, and provides additional warnings.

    TL-9033        Increased the form field lengths on the Certification settings form


Bug fixes:

    TL-8247        Fixed missing history records when not overriding the current record during a course completion import

                   Previously if you ticked the override checkbox when uploading course
                   completions, but the most recent completion date in the upload was less
                   than the current completion date in an existing record, the upload would
                   ignore the first record and move straight on to the next one. That first
                   record is now placed into history instead.

    TL-8389        Fixed an issue with empty variables inside aggregate questions
    TL-8408        Fixed the Face-to-face user cancellation status by checking the user's current status, avoiding multiple cancellations
    TL-8472        Fixed the Terms & Conditions dialog box for Face-to-face self approval
    TL-8554        Fixed zero values for appraisals rating questions

                   Both positive and negative numbers are valid values for ratings questions
                   in Appraisals, but a lot of the validation checks were using !empty() which
                   caused problems when trying to use zero. These checks have been updated and
                   zero is now an acceptable value in both numeric and custom ratings

    TL-8561        Changed the display of certification settings in the completion editor to use translatable strings
    TL-8599        Corrected the completion time used for completion criteria based on completion of another course

                   Completion criteria based on completion of another course now use the
                   completion time of that course when setting the completion time of the
                   criteria, rather than using the time that the criteria was aggregated.

    TL-8605        Fixed certification completon records affected by the reassignment bug

                   Patch TL-6790 in the March release of Totara changed the behaviour when
                   re-assigning users onto a certification. This patch repairs certification
                   completion records for users who were, before that patch, re-assigned and
                   ended up being unable to certify. All users which are identified by the
                   completion checker as "Program status should be 'Program incomplete' when
                   user is newly assigned. Program completion date should be empty when user
                   is newly assigned.", and have an "unassigned" historical completion record,
                   will have that historical record restored, as is the current behaviour when
                   reassigning users. Any records which do not meet these specific criteria,
                   or would be in an invalid state if the change was applied, will not be
                   affected and must be processed manually.

    TL-8732        Fixed capability checks around suspended users within the course enrolment interfaces
    TL-8753        Added an automatic fix for mismatched program and certification completion dates

                   The program completion date should match the certification completion date
                   when a user's certification is "Certified, before the window opens". To
                   repair records where the date is incorrect, this patch added an automated
                   fix which can be triggered to copy the certification completion date to the
                   program completion date. Relates to TL-9014.

    TL-8764        Deleted orphaned course reminders for deleted courses
    TL-8785        Removed the incorrect 'leave this page' warning when editing Feedback activity questions
    TL-8793        Reminders which are sent belonging to a user are now deleted when the user is deleted
    TL-8807        Fixed search in the completion upload results report
    TL-8872        Fixed the ordering of the transaction logs in program and certification completion editors
    TL-8881        Fixed html blocks from losing images when being customised.
    TL-8942        Fixed test failures caused by a new timezone in Venezuela
    TL-8969        Fixed an issue with the display of users fullnames and improved the internal documentation

                   In 2.6 and 2.7 the "fullnamedisplay" setting was incorrectly falling back
                   to the format specified in language pack. This has been reverted and the
                   overriding fallback happens only if the value "firstname" is specified in
                   the "fullnamedisplay" setting.

                   A new setting in 2.9 "alternativefullnameformat" has already resolved this
                   in a different way.

    TL-8983        Fixed the repeating update of signup status for suspended and deleted users in Face-to-face

                   Previously a cancellation status update was written to the database for
                   each deleted or suspended user who had signed up to a Face-to-face session
                   prior to deletion/suspension, this happened every time cron ran.
                   Face-to-face now correctly checks if the user already has a cancellation
                   status and does not write a redundant duplicate status.

    TL-8990        Backported upstream fixes for time zone related issues
    TL-8991        Fixed the wrong date being used to calculate the certification completion date

                   If a certification had a course set with more than one course, where not
                   all of the courses were required for completion. And before being assigned
                   to the certification, a user completed (manually or via course completion
                   upload) enough of the courses to complete the course set. The certification
                   completion date was being incorrectly calculated as the latest date of all
                   completed courses, rather than the maximum course set completion date. This
                   patch corrects this, and provides an automated fix (part of the
                   Certification completion editor) to repair any affected records.

    TL-9052        Fixed the status of notification templates when they were updated by a user


Contributions:

    * Artur Poninski at Webanywhere - TL-8599
    * Malgorzata Dziodzio at Webanywhere - TL-8376


Release 2.7.14.1 (26th April 2016):
===================================

Important:

    TL-8846        Face-to-face upgrade restores the latest non-empty signup and cancellation custom field data

                   The 2.7.14 release contained a fix for TL-6962 which was not acting in a
                   way that all users wanted it to.
                   Given an upgrade step is non-reversible, we have put out an emergency
                   release to allow administrators to choose how they want the upgrade to
                   behave.

                   TL-6962 was fixing Face-to-face signup and cancellation custom field data
                   being lost when the user's signup status changed.
                   The root cause of that issue is that custom field data was being stored
                   against the user's signup status rather than the signup itself.
                   Because a user could pass through multiple statuses, this data was lost in
                   the user interface as soon as the user's status changed. This was most
                   commonly seen if manager approval was turned on, in which case the signup
                   note entered by the user when they signed up would be lost when the manager
                   approved them.
                   The solution was to change this, so that data is stored referencing the
                   signup rather than the signup status.
                   This ensures that the data is maintained throughout a user's signup,
                   regardless of which statuses they pass through.
                   During upgrade we had to remap existing data and a choice had to be made.
                   Either we kept the data consistent with what users had previously seen in
                   the system OR we restored the last non-empty value for the field for each
                   signup.
                   We chose in 2.7.14 to keep the data consistent with what users were seeing
                   prior to the upgrade.
                   Since the release we have had feedback that this is not what all sites
                   expected and that they would prefer to have the last non-empty value
                   restored.
                   We appreciate this request and have come up with a solution that will allow
                   each site to choose, if they wish, which they would like to happen.
                   There is now a special configuration variable that can be defined in PHP to
                   change the upgrade behaviour.
                   The following explains what this upgrade step does and how to choose the
                   alternative behaviour if you want it.

                   Default upgrade behaviour:
                   The upgrade finds the last non-empty value for each Face-to-face signup or
                   cancellation custom field and uses that as the value the user entered.
                   This is consistent with the behaviour you will see AFTER upgrading to this
                   version.
                   It is not consistent with the previous behaviour before upgrading, which
                   was not maintaining the value the user entered.
                   This is the default behaviour so you don't need to do anything except
                   upgrade.

                   Alternative upgrade behaviour:
                   Instead of the default behaviour, restore the latest value recorded for the
                   Face-to-face signup or cancellation field, which may be empty due to status
                   changes, and store that as the user's current value.
                   This is consistent with the behaviour prior to custom fields being fixed.
                   It is not consistent with the current behaviour which ensures the value the
                   user entered is maintained.
                   To get this behaviour you must add the following to your config.php before
                   upgrading to 2.7.14.1:
                       $CFG->facetoface_customfield_migration_behaviour === 'latest';

                   If you have already upgraded to the 2.7.14 release the alternative
                   behaviour would have already been applied as this was the only behaviour
                   available in that release.
                   It is possible to change from the alternative behaviour to the current
                   behaviour if you have a backup from prior to the upgrade.
                   If this is you please get in touch with us and we'll provide instructions
                   on how to re-run this part of the upgrade using the data in the backup.


Release 2.7.14 (20th April 2016):
=================================


Important:

    TL-8417        Historical completion records belonging to a course are now deleted if the course gets deleted

                   Previously when a course was deleted the historical completion records were
                   forgotten about and left orphaned.
                   This lead to errors and visual inconsistencies when trying to work with the
                   historical completion records as they now referenced removed courses.
                   Now when a course is deleted all historical completion records held for it
                   are also deleted.
                   Please note that during upgrade all orphaned historical completion records
                   are deleted.

    TL-8711        Scheduled reports belonging to a user are now deleted when the user gets deleted

                   Previously when a user or audience was deleted any scheduled reports
                   belonging to that user were left in the system.
                   This lead to errors as the scheduled reports now referenced users that no
                   longer existed.
                   Now when a user is deleted all scheduled reports belonging to that user are
                   also deleted.
                   During upgrade all orphaned scheduled reports belonging to previously
                   deleted users will be cleaned up.

                   The same is true of audiences referenced as recipients of scheduled
                   reports.
                   Now when an audience is deleted orphaned scheduled report recipient records
                   are also cleaned up.
                   During upgrade all orphaned scheduled reports referencing audiences that no
                   longer exist will be cleaned up.



Improvements:

    TL-8358        Updated the help text for a custom fields' "Locked" setting
    TL-8393        Performance improvement when admins view a course with many activities

                   Previously, when an admin viewed a course, the admin's completion data for
                   each course would be checked for each activity multiple times. The higher
                   the number of activities in a course, the more often these completion
                   checks would occur, causing performance issues when there were many
                   activities involved. This only affected users who could access the course
                   but were not enrolled, such as site administrators. Enrolled users were not
                   affected by this bug. Guest users were also not affected as completion data
                   is not checked for them.

                   The issue occurred due to cached data being cleared incorrectly for the
                   affected users. This has been corrected and page load times for admins on
                   the view course page will now be similar to that of enrolled learners.

    TL-8657        Improved performance of adding courses and programs to audiences
    TL-8751        Added links to run completion checker over whole site

                   Links were added in Manage Programs and Manage Certifications which allow
                   privileged users to run the program and certification completion checkers
                   over all programs or certifications on a site, rather than having to run
                   them one program or certification at a time.



Bug fixes:

    TL-6962        Made signup and cancellation fields consistent throughout Face-to-face

                   Previously Face-to-face custom fields for signup and cancellations were
                   being attached to a users signup status.
                   This was a regression from the conversion of Face-to-face custom fields in
                   2.7 that has been the cause of a several hard to track down problems.
                   In this fix we have changed the attachment point from signup status to the
                   signup itself.
                   This has lead to several minor changes in the Face-to-face API's as noted
                   below.

                   * facetoface_get_attendee no longer returns the statusid or usernote as
                   part of the record it returns.
                   * facetoface_get_attendees no longer returns a usernote as part of the
                   record it returns.
                   * facetoface_user_signup the usernote argument 10 has been deprecated and
                   now displays a debugging notice if used.
                   * facetoface_update_signup_status the usernote argument 4 has been
                   deprecated and now displays a debugging notice if used.
                   * facetoface_get_cancellations no longer returns a cancellation reason
                   property as part of its response.
                   * facetoface_get_requests no longer returns a usernote property as part of
                   the record it returns.
                   * facetoface_user_import no longer imports a usernote (this was not being
                   stored correctly)

    TL-8101        Removed the incorrect "role change" warning for completed dynamic appraisals
    TL-8136        Fixed Face-to-face custom field filters when applied within the calendar
    TL-8156        Fixed capability checks when adding audiences and users as scheduled report recipients
    TL-8162        Ensured only eligible activities are selectable for feedback reminders

                   Only activities which are part of course completion can be tracked for
                   sending out feedback reminder messages. However, it was previously possible
                   to select other activities and the reminder would simply not go out. The
                   select options for activity completion to base a feedback reminder on are
                   now restricted to those that are part of course completion criteria.

    TL-8338        Fixed the Face-to-face signup by waitlist functionality by including overbook capability check
    TL-8346        Corrected Face-to-face terminology within the session report source

                   The Face-to-face session report now correctly refers to users who have self
                   booked via the self-booking service as "Self booked", previously they were
                   incorrectly referred to as "Reserved"

    TL-8374        Ensured the certification completion date is only calculated on the current paths courses
    TL-8380        Removed the sorting from Progress column for Certification overview report
    TL-8399        Fixed the coursenames column in the Program/Certification overview report

                   Previously if a course's short name contained a comma it would be
                   incorrectly processed by the Program overview and Certification overview
                   reports.
                   It is now correctly handled.

    TL-8438        Added a missing string used within the Program membership report
    TL-8458        Face-to-face module can now be managed by users with the 'totara/core:modconfig' capability
    TL-8461        Fixed course deletion to more accurately update program coursesets

                   Previously, all competency course sets were inadvertently being removed
                   from programs whenever any course on the site was deleted. This, and
                   deletion of courses that left other course sets empty, also resulted in
                   exceptions being displayed when viewing programs.

                   This behaviour has been prevented.

                   Two methods have been added to the course_set abstract class in
                   totara/program/program_courseset.class.php, get_courses and delete_course.
                   These will be abstract methods in the next major release. For existing
                   releases, they will output a message if debugging has been turned on. If
                   any custom classes have been created that inherit from this class, it is
                   recommended that you overwrite these methods in the custom class.

    TL-8471        Fixed 'totara/dashboard:manage' capability for non admin user
    TL-8475        Fixed position type display function for Face-to-face session report
    TL-8502        HR Import now correctly handles invalid usernames by logging a warning and continuing on

                   This issue was only encountered when the user delete setting was set to
                   suspend users, and there were users being deleted. However this adds extra
                   validation to the HR import sanity checks so any invalid users will be
                   detected during any sync action.

    TL-8585        Face-to-face notification iCalendar attachments now support updates during signup status and/or session date changes

                   Please note, software that does not support iCalendar sequence will still
                   create new event each time instead of updating it.

    TL-8592        Backport MDL-51408 to fix custom field completion criteria within Badges
    TL-8633        Fixed use of the duedate placeholder in program messages
    TL-8634        Fixed Audience: Visible Learning report when no id is set
    TL-8635        Corrected the handling of timezones on Learning Plan End Date field
    TL-8691        Fixed the handling of locked custom course fields when creating a new course
    TL-8707        Made the 'Duration' column within Face-to-face reports translatable


Release 2.7.13 (23rd March 2016):
=================================


Important:

    TL-6790        Changed the default behaviour of certification reassignment

                   Previously a user who was unassigned and reassigned to a certification
                   would be placed back into their initial certification path. Depending on
                   their current course completions, their status may have been reaggregated
                   on the next cron run. Now the system will look for the latest unassigned
                   certification completion history record and the user will be restored to
                   their previous status instead. Any events that need to occur (such as
                   window opening) will take place when the relevant scheduled task runs (e.g.
                   update_certification_task).


Security issues:

    TL-8642        The following security fixes were included with the merge of Moodle 2.7.13

                   MDL-52378 Non-Editing Instructor role can edit exclude checkbox in Single
                   View
                   MDL-52651 Add no referrer to links with _blank target attribute
                   MDL-52727 Reflected XSS in mod_data advanced search
                   MDL-52774 Enumeration of category details possible without authentication
                   MDL-52808 External function get_calendar_events return events that pertains
                   to hidden activities
                   MDL-52901 External function mod_assign_save_submission does not check due
                   dates
                   MDL-53031 CSRF in Assignment plugin management page


Improvements:

    TL-6723        Added automatic test coverage of the security overview report
    TL-8295        Improved perfomance when getting items assigned to plans

                   This get_assigned_items function by default was returning the counts of any
                   linked items. This was leading to performance issues when the counts were
                   not required. The function now returns this information only when required.

    TL-8422        Improved output of the standard logstore cleanup task
    TL-8484        Linked Report Builder Financial year setting labels to their inputs


Bug fixes:

    TL-8205        Removed unassigned users that incorrectly show up in certification completion reports

                   Reports that used the 'Certification Completion' report source would
                   contain users that had been unassigned from a certification. This would
                   only be the case if the user was unassigned before their recertification
                   window opened and the data for these users would be incorrect for some
                   columns. Unassigned users will no longer show up in certification
                   completion reports, which is in line with documentation on this report
                   source.

                   Note that if you require a report that includes data for unassigned users.
                   You may like to create a report that uses the Record of Learning:
                   Certification report source.

    TL-8274        Fixed calendar navigation on non-default home page
    TL-8277        Fixed incorrect highlighting of menu items

                   When enhanced catalog was off, viewing the pages specific to the enhanced
                   catalog were leading to the Find Learning menu items being highlighted.
                   This has been corrected.

    TL-8280        Fixed manual changes to course completion competency proficiency being overridden

                   Before the patch, if a manager set a course completion competency to
                   proficient, it was being overridden by a cron task. Now, the change the
                   manager made will be kept.

    TL-8339        Fixed saving of due dates when creating and editing objectives in learning plans
    TL-8345        Ensured sum aggregation uses display function if available
    TL-8363        Ensured courses assigned to plans are removed when a course is deleted
    TL-8364        Removed extra line breaks in Face-to-face messages
    TL-8396        Fixed default sort order for graphical report block
    TL-8407        Improved layout of the graph tooltip in Internet Explorer using a rtl langauge
    TL-8409        Prevented saving scheduled reports without a recipient
    TL-8412        Fixed 'menuofchoice' custom field for sidebar filter in report builder
    TL-8419        Fixed issue that prevented blocks from being edited with Totara Dashboard enabled as default home
    TL-8440        Fixed report sort column for scheduled reports
    TL-8441        Increased maxlength of objective scales value name to 255 characters
    TL-8444        Fixed Program and Certification Membership reports for MSSQL
    TL-8479        Fixed the MSSQL NVARCHAR migration upgrade step
    TL-8508        Fixed untranslatable string "Face-to-face name" in Face-to-face sessions report source
    TL-8538        Fixed dates in ODS exports to use current user timezone to match all other export options


Release 2.7.12 (22nd February 2016):
====================================


Security issues:

    TL-8235        Included session key check in Face-to-face when adding and removing attendees
    TL-8392        Fixed handling of non-numeric answers to numeric feedback activity questions


Improvements:

    TL-7542        Added a new report source for language customisations
    TL-7970        Added the program and certification completion editor

                   Enabled with Site administration -> Advanced features -> Enable program
                   completion editor. Only users with the 'totara/program:editcompletion'
                   capability (site admins only, by default) will be able to access the new
                   tab 'Completion' when editing a program or certification. For more
                   information, see the community post:
                   https://community.totaralms.com/mod/forum/discuss.php?d=11040.

    TL-8276        Removed unused CFG settings from Totara messaging code

                   The removed settings are "message_contacts_refresh", "message_chat_refresh"
                   and "message_offline_time".

    TL-8290        Increased maximum value of sortorder field in the Feedback360 questions table.

                   When running MySQL in particular, the number of questions in one Feedback
                   questionnaire would be limited to 128. This was due to the sortorder field
                   in the corresponding table being of the type tinyint. This sortorder field
                   will now use the bigint datatype for all supported databases, which is
                   consistent with similar fields in other tables.

    TL-8371        Changed program course sets to display courses in the order they were added

                   The order of courses in a program or certification course set would vary
                   when returned by a database. They are now ordered by ID of the
                   prog_courseset_course table, making the order more consistent. This means
                   they will be in the same order as what they were when first added to the
                   course set.


Bug fixes:

    TL-6593        Fixed course completion status not updating when changing completion criteria

                   Users were not being marked "In progress" when the were assessed against
                   the new completion criteria.

    TL-8075        Fixed error in HR Import when setting the CSV delimiter to Tab
    TL-8078        Completion progress details page was reworded to more accurately indicate the status

                   Previously, the course status in the Completion progress details page
                   (accessed by clicking the "Progress" bar in Record of Learning: Courses or
                   "More details" in the Completion status block) would show "Not started"
                   even though the learner had actually viewed and completed a SCORM lesson.
                   Moreover, the SCORM activity status would be "Viewed the scorm, Achieved
                   grade" even though the learner had not achieved the grade to complete the
                   activity. These were fixed in this patch. Course status is now "incomplete"
                   as long as its activities are not complete and the activity status
                   correctly indicates the learner failed to achieve the required grade.

    TL-8226        Fixed an issue with the course completion scheduled task

                   There was a problem in the completion cron when a user had completed an
                   activity but hadn't had the module completion record written into the
                   database. The criteria review would call get_info() which now updates the
                   state, creating the module completion record. However the initial review
                   would then continue and due to a dataobject lacking the now existing record
                   it would try to write the record again, causing a conflict. The dataobject
                   is now created after the get_info() call, avoiding this issue.

    TL-8240        Fixed capability checks when assessing a user's access to resources using audience visibility

                   Prior to this fix, in rare situations where the current user was viewing
                   resources available to another user, the access checks were being
                   incorrectly performed for the current user. The checks are now correctly
                   performed for the given user rather than the current user in this
                   situation.

    TL-8253        Fixed a bug which occured in some situations when deleting audiences without members

                   Prior to this fix, if you attempted to delete an audience which had a role
                   assignment associated with it, but not members, you would receive a fatal
                   error. This has now been fixed and the audience is correctly deleted.

    TL-8322        Fixed problem when upgrading to patch T-12199

                   The upgrade step in this patch was changing cohort visibility records for
                   certifications. It tried to change the program-type records to
                   certification-type. Now, if the certification-type record already exists,
                   the program-type record will instead be deleted.

    TL-8361        Fixed incorrect hardcoded max table name length in the XMLDB editor
    TL-8391        Fixed reportbuilder sorting and pagination when Restrict initial display is enabled


Contributions:

    * Eugene Venter at Catalyst NZ - TL-7542, TL-8276
    * Hamish Dewe at Orion Health - TL-8371
    * Jo from Kineo - TL-8392


Release 2.7.11 (18th January 2016):
==================================================


Important:

    TL-7896        Fixed dynamic audience rules that reference an organisation menu type custom field

                   Dynamic audience rules for Organisation menu custom fields can have one of
                   two operators, "Equal to" and "Not equal to".
                   Prior to this fix these operators functioned in reverse. "Equal to" would
                   lead to users within an organisation for which the custom field did NOT
                   include the selected options.
                   Likewise if "Not equal to" was used users within organisations for which
                   the selected value was used would be included as audience members.
                   After this fix the operators are applied correctly.

                   If you have dynamic audiences with rules based upon organisation menu
                   custom fields then we strongly recommend you review these dynamic audience
                   rules and the associated audience memberships.
                   During upgrade these rules will be corrected and audience memberships may
                   change.
                   If you have affected audiences, you can fix them without incurring
                   membership changes by following these steps:

                   1. Disable cron prior to your upgrade.
                   2. Upgrade your site.
                   3. Review the dynamic audiences that are affected. If you need memberships
                   to stay exactly the same then changing the condition on the rule from
                   "Equals to" to "Not equals to" (or vice-versa) will ensure that audience
                   memberships stay as they were prior to this version.
                   4. Approve your changes and review the audience memberships.
                   5. Re-enable and run the cron.

    TL-8047        Fixed a bug found within SQL search routines used by both dialog searches and dynamic audience rules.

                   Prior to this fix if you had a dynamic audience with two or more rules in a
                   single ruleset, where the rules have comma separated values specified in
                   conjunction with any of the following conditions "Contains", "Is equal to",
                   "Starts with", "Ends with" then membership may be incorrect.
                   The bug is due to multiple value search SQL not being correctly wrapped in
                   brackets.

                   After this fix comma separated values are correctly applied when
                   determining dynamic audience membership.

                   Depending upon the order of the rules and how they apply to the users
                   currently in the audience, membership may or may not change.
                   If you have an audience you believe is affected we strongly urge that you
                   first test this version on a copy of your site and after upgrading, closely
                   review audience membership.
                   You will need to review and amend the audience rules if users are removed
                   and you require them to still be included.

                   This bug may also have affected dialog searches when multiple values were
                   being used. Searching in dialogs now correctly handles multiple search
                   values.


Improvements:

    TL-7560        Added missing foreign key to the type field in the pos_assignment table
    TL-7816        Time can now be set when assigning due dates for programs

                   Previously when setting fixed due dates for a program or certification,
                   only the date could be set but not the time, which would fall at the
                   beginning of the day for the person setting it. Now the time can also be
                   set which means less ambiguity for when a due date will expire,
                   particularly for sites where users are in different timezones from each
                   other.

                   If a user is requesting an extension of their due date in a program, they
                   can also specify the time.

                   If a manager's team members have pending extension requests, the manager
                   can now navigate to the page where these requests are updated via the 'My
                   Team' page. Previously they could only get to the page by a link in an
                   email or typing in the url.

    TL-7973        Added a warning for Report builder when internally required columns break custom aggregations
    TL-8133        Renamed the Position and Organisation Report builder filters to be more consistent
    TL-8144        Improved the multi-lang support for Appraisal management pages
    TL-8153        Backported support for MySQL 5.7
    TL-8155        Improved compatibility with PostgreSQL 9.5
    TL-8166        Added a new column 'Course Completions as Evidence' to the My Team embedded report
    TL-8183        Improved the Face-to-face session room filter
    TL-8210        Replaced the logos in the standardtotararesponsive theme with SVG equivalents.
    TL-8228        Improved the multi-lang support for Questions in Appraisals and Feedback360
    TL-8254        Backported grunt support for building of JS and CSS


Bug fixes:

    TL-7012        Fixed the course completion progress bar for courses within a completed learning plan

                   The course completion progress bar was not being correctly displayed in the
                   Record of Learning for course that are part of an already completed
                   learning plan.

    TL-7527        Fixed the default settings for the example appraisal

                   The example appraisal previously required some of the question content to
                   be opened and saved via the interface before goals or competencies could be
                   selected by learners. On a new install of Totara, example appraisals can
                   now be assigned and activated without having to open the question settings
                   beforehand. This also fixes certain instances where a manager could not
                   review goals after they had been reviewed by the learner.

    TL-7608        Increased the maximum character length to 255 for various user fields in HR Import

                   The maximum character length of the institution, department, address and
                   password fields have been increased to 255 to match those allowed through
                   the user interface.

    TL-7809        Updated the language strings for the learning plans "objectives approval" and "status" columns
    TL-7826        Course completions stats on the My Team report now include RPL completions

                   Switched the Course Completion statistics on the My Team embedded report to
                   use course_completion records instead of block_totara_stats.

    TL-7946        Removed the link from progress icon if the user is not enrolled in the course

                   If a user is enrolled in a program but not yet enrolled in a course within
                   that program (e.g. they have not yet launched the course), the progress
                   icon included a link to their completion status. Clicking on this would
                   take that user to a page with an error saying they are not yet enrolled.
                   The progress icon now only acts as a link if they are enrolled or already
                   have a completion status by some other means.

    TL-7978        Fixed the layout of strings in the Completion status block

                   A couple of strings in the completion status block were appended together
                   and were missing spaces. The second part of the string is now passed into
                   the language string which fixes the layout and also allow the string to be
                   translated correctly which previously was not possible.

    TL-8041        Fixed access controls when adding and removing audiences while editing courses

                   When adding audiences via the course edit page, the checks are now ensuring
                   that the cohort enrolment plugin is enabled and that the logged in user has
                   the capabilities 'moodle/course:enrolconfig' and 'enrol/cohort:config' in
                   the course or higher context. Also the audience selector now only displays
                   audiences that the user can view (with 'moodle/cohort:view' in the
                   necessary context).

    TL-8049        Fixed an error when hiding blocks on learning plan pages

                   Previously when trying to hide a block in a learning plan page
                   (totara/plan/component.php) an error would be displayed and the block would
                   not be hidden.

    TL-8056        Fixed styles for the assignment marking guide criterion form section
    TL-8083        Removed dashboards associated with deleted audiences
    TL-8088        Fixed regression when displaying Face to face attendees
    TL-8124        Fixed error when deleting course with Face-to-face activities
    TL-8127        Fixed filters requiring javascript in embedded Audience Member reports
    TL-8135        Fixed the risk displayed for the totara/program:markstaffcoursecomplete capability
    TL-8160        HR Import now correctly sets the default language when creating users
    TL-8167        The Graphical report block now uses the default sort order of the report
    TL-8173        Fixed HTML validation error due to missing closing div tag on the program assignments page
    TL-8184        Stopped timezones being displayed in Face-to-face reports when they are disabled in the plugin settings
    TL-8185        Fixed the pagination on the "Manage programs" and "Manage certifications" pages
    TL-8191        Fixed the validation of Report builder date filters using number of days selectors
    TL-8197        Fixed text placement for RTL graphical reports in Internet Explorer and Edge
    TL-8207        Fixed notice when editing pages with custom block regions without JavaScript
    TL-8221        Course icons are now shown in all circumstances

                   With the enhanced course catalogue disabled, the course icons previously
                   had an incorrect URL causing them to not be displayed. We now validate the
                   URL to ensure it is correct.

    TL-8231        Switched the Face-to-face edit attendees from sending GET params to POST params

                   Prior to this change when editing the attendees of a Face-to-face session
                   the dialog would submit any changes made as GET params.
                   If the session had hundreds or thousands of attendees this could lead to an
                   exceptionally long URL.
                   The length of the URL may then cause problems on some systems, particularly
                   IIS and any site running Suhosin.

    TL-8245        Fixed cohort log data in site logs
    TL-8251        Fixed an error with updating competency properties in a learning plan with JavaScript disabled

                   When updating either priority or status for a competency in a Learning Plan
                   with JavaScript turned off there was a error message thrown. The update was
                   saved but an message was displayed every time there was an update.

    TL-8263        Fixed room validation during Face-to-face session creation when the datetime is not known

                   Prior to this fix when creating a Face-to-face sessions, if a room is
                   selected then a date is selected which causes a resource conflict when
                   saving. If the user then sets "date/time known" to "No" the validation
                   would still fail and stop the session from being saved.


Contributions:

    * Pavel Tsakalidis from Kineo UK - TL-7560
    * Russell England from Kineo USA - TL-8191


Release 2.7.10 (14th December 2015):
====================================


Security issues:

    TL-7957        Totara Connect now prevents reuse of ssotokens for user logins
    TL-7975        Added read/write access controls to group assignment code throughout Totara
    TL-8076        Prevented access to external blog pages when either blogs or external blogs are disabled


Improvements:

    TL-4429        Added an advanced multi-item course name filter to various Report builder report sources
    TL-6283        Removed all uses of deprecated function sql_fullname in Feedback360
    TL-6474        Shortened the display of Report builder Graph labels and legend entries

                   It is now possible to specify limitations on label length for Report
                   builder graphs using the following syntax in the custom settings input:
                     label_shorten = 20
                     legend_shorten = 40

                   To get the previous behaviour without shortening use value 0.

    TL-7684        Make validation of session selection more sensible when using the Face-to-face direct enrolment plugin
    TL-7810        Improved the performance of building hierarchy lists
    TL-8020        Added advanced multi-item Position and Organisation name filters to various Report builder report sources
    TL-8061        Changed the default settings for badge owner notifications to always send email

                   This only effects new installs. Before this patch, by default, badge
                   creators would not receive an email (or any notification) if they were
                   logged in.

    TL-8066        Improved the performance of the Audience enrolments sync
    TL-8093        Improved the display of select boxes with a specified size


Bug fixes:

    TL-6789        Fixed the handling of transactions when exceptions occur within HR Import user sync

                   Prior to this patch, if an exception was generated while assigning user
                   positions, the exception would be handled and processing would continue.
                   However, if the exception occurred within a database transaction, the
                   transaction was not being cleaned up.

    TL-7355        Managers approving Face-to-face booking requests are now notified of the updates success

                   Previously, when a manager approved staff requests for bookings into a
                   Face-to-face session, they would then be redirected to a page saying 'You
                   can not enrol yourself in this course' (assuming they were not enrolled or
                   did not have other permissions to view the attendees page). Following any
                   approvals (by a manager or any other user), the page will now refresh onto
                   the approval required page, with a message confirming the update was
                   successful.

    TL-7400        Fix fatal error on quiz statistics report when using matching questions
    TL-7426        Fixed the course completion status of users after their RPL is deleted

                   Previously their completion would not be re-aggregated until they made
                   further progress in the course, now it is re-aggregated immediately.

    TL-7504        Updated the permissions for the unobscured user email column in Report builder reports

                   Previously the unobscured user email column and filter were only shown when
                   email was turned on in user identity settings, now it is also shown if the
                   user has the site:config capability. This ensures that the admin can use
                   these columns regardless of the user identity setting.

    TL-7521        Fixed values for position start and end dates when syncing with database source

                   If an external database that was being synced via HR Import contained a
                   Null value for position start date and position end date, this was throwing
                   an error. Null values will now mean that no value will be added to the
                   position details.

                   In addition to this, if a position start or end date field contained the
                   value 0, the value added into the position details in Totara would be the
                   current time. This has been changed such that 0 and null are equivalent and
                   result in no value being added to the position details. This is consistent
                   with imports via CSV.

    TL-7620        Fixed the display of defaults for text input custom fields in Report builder
    TL-7712        Fixed an issue with assigning a large number of users to programs

                   Previously when a large number of individuals were already assigned to a
                   program, adding more assignments could lead to an HTTP 414 error due to a
                   large amount of data being included in the URL.

    TL-7731        Fixed the display of non-latin characters in program summaries when viewing Report builder reports
    TL-7781        Fixed pop-up behaviour for admins using a single-activity course with a file
    TL-7842        Fixed stuck certification completions due to a bug previously fixed in TL-6979

                   Certifications which experienced the problem which was fixed in TL-6979
                   would be stuck after upgrading. This patch will repair those records by
                   triggering the window open event again. The records will be in the correct
                   state after installing the upgrade and then running the Update
                   Certifications scheduled task.

    TL-7879        Stopped Program un-enrolment messages being sent to suspended users
    TL-7904        Fixed Terms & Conditions dialog box for Face-to-face direct enrolment plugin
    TL-7911        Fixed the restoration of certificate user information on different sites
    TL-7917        Fixed the "User is suspended" dynamic audience rule when it is used more than once in the same rule set
    TL-7925        Fixed an issue with duplicate grade items when using the assignment submissions report source
    TL-7931        Fixed the booked-by & actioned columns in Face-to-face session report sources

                   The columns now display the actual user name and link instead of the
                   "Reserved" word for the "Booked by" and "Actioned by" columns.

    TL-7965        Fixed consecutive usage of the Face-to-face attendees menu option

                   Previously after adding or removing users via the attendees page, you would
                   have to refresh the page before it would work again.

    TL-7966        Replaced hardcoded "Advanced options" string with a translatable string in Report builder
    TL-7971        Corrected the positioning of short form date pickers for rtl languages
    TL-7976        Fixed an issue with exporting reports to PDF (portrait) on some systems
    TL-7980        Fixed the deletion of scheduled reports
    TL-7997        Fixed the shortname field for Goal types
    TL-8010        Removed unformatted html from output when exporting a user's Record of Learning to PDF
    TL-8026        Fixed the display of Face-to-face session details within Calendar events
    TL-8048        Fixed the sidebar filter for Report builder reports with paging

                   When a sidebar filter is changed, you will be taken back to the first page
                   of results (as happens with other search and filters).

    TL-8050        Prevent the deletion of unrelated scheduled report recipients when deleting a scheduled report

                   Previously if the ID of the scheduled report being deleted matched the ID
                   of a Report builder report, all recipients for scheduled reports based off
                   that report would also be incorrectly deleted.

    TL-8121        Corrected the display of certification due dates when exporting to pdf


Contributions:

    * Artur Rietz at Webanywhere - TL-8010
    * Chris Wharton at Catalyst NZ and Haitham Gasim at Kineo USA - TL-7980
    * Haitham Gasim at Kineo USA - TL-8026
    * Jo Jones at Kineo UK - TL-7976
    * Pavel Tsakalidis at Kineo UK - TL-7975
    * Tim Price at Catalyst Australia - TL-7911


Release 2.7.9.1 (9th December 2015):
====================================


Bug fixes:

    TL-8096        Fixed course module completion calculation

                   This fixes a regression introduced by TL-6981 in 2.9.1, 2.7.9, 2.6.26, and
                   2.5.33 in which the calculation of course module completion would lead to
                   all activities being marked complete incorrectly for a user.
                   The problem occurs when the user completes the first activity in the
                   course. It occurs if the user manually marks themselves complete, achieves
                   the completion criteria (with the exception of "Student must view this
                   activity to complete it"), or is marked complete by a trainer. The user
                   must then log out and log back in again in order to see the problem.
                   The problem will not occur if it is not the first activity in the course.
                   When this occurs all activities in the course will be marked complete,
                   regardless of which section or order they are within the course and
                   regardless of whether they are required for course completion or not.


Release 2.7.9 (16th November 2015):
==================================================


Security issues:

    TL-7886        Fixed access checks for the position assignment AJAX script
    TL-7829        Removed reliance on url parameter for choosing table

                   The script for getting the positions and organisations to assign to a
                   program relied on a url parameter to choose which table to access. The
                   table is now chosen according to the type of hierarchy that the query is
                   for.

    MoodleHQ       Security fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.7.11_release_notes

                   Security related issues:
                   * MDL-51861 enrol: Don't get all parts in get_enrolled_users with groups
                   * MDL-51684 badges: Make sure 'moodle/badges:viewbadges' is respected
                   * MDL-51569 mod_choice: validate user actions and availability
                   * MDL-51091 core_registration: session key check in registration.
                   * MDL-50837 mod_scorm: Fix availability checks
                   * MDL-49940 mod_survey: Fix XSS
                   * MDL-48109 mod_lesson: prevent CSRF on password protected lesson


Improvements:

    TL-6282        Improved handling and displaying of the user's name in Core dialogs
    TL-6657        Added actual due dates to program Assignments and audience Enrolled Learning tabs

                   The Assignments tab in programs and certifications and the Enrolled
                   Learning tab in audiences now include a column "Actual due date". This new
                   column shows the due date that the user will see. For group assignments
                   (such as audiences or organisations), clicking the "View dates" link will
                   show a popup with a list of all assigned users relating to that group
                   assignment. The help popup for the "Actual due date" column explains why
                   assignment due dates may be different from the actual due dates. After
                   upgrading, the "Actual due date" field can be manually added to the
                   "Audience: Enrolled Learning" embedded report, or you can reset it to the
                   default to have it automatically added.

    TL-7183        Trigger updates to program user assignments when changing assignments via the audience Enrolled Learning tab

                   When you make a change in an audience's Enrolled Learning tab, it will
                   immediately trigger an update of program and certification user
                   assignments. If there are less than 200 total users involved in the program
                   then the users will be processed immediately, otherwise the update will be
                   deferred. By default, deferred program user assignments are processed the
                   next time cron runs. This patch makes the behaviour consistent with making
                   changes in a program's Assignments tab.

    TL-7256        Mark programs for deferred user assignment update when assignment membership changes

                   This patch includes several improvements which cause program and
                   certification memberships to be updated sooner:
                   * When audience membership changes, either by a user manually editing an
                   audience or when a dynamic audience's membership is automatically updated,
                   related programs and certifications will be marked as having user
                   assignment changes deferred.
                   * When a user's assigned position, organisation or manager change, programs
                   and certifications related to the old and new positions, organisations and
                   management hierarchy are marked as having user assignment changes
                   deferred.

                   With this change in place, all changes to program membership should now be
                   detected as they occur and are either processed immediately or by the
                   "Deferred program assignments changes" scheduled task. As such, we
                   recommend setting the related tasks to their default schedules: "Deferred
                   program assignments changes" can be run every time cron runs, while
                   "Program user assignments" only needs to be run once per day.

    TL-7529        Fixed handling of RPL records when resetting or deleting a course or its completions

                   This change fixes how RPL records are handled when a course is reset by a
                   certification, deleted or reset by a user, or course completions unlocked
                   by a teacher.

                   When deleting or resetting a course, RPL completions are now also deleted
                   correctly. Previously these were not removed. An upgrade step will safely
                   remove invalid data records for deleted courses.

                   When a user's course completion gets reset by a certification window opening, all
                   course RPL completions will be removed. Activity RPL completions will remain and
                   still count towards the next course and certification completion.

                   As before, when a teacher unlocks course completion criteria and selects to
                   delete, course and activity RPL records will be kept and still count
                   towards a users completion.

                   Contributed by Eugene Venter at Catalyst NZ

    TL-7697        Improved the layout of comments within learning plans
    TL-7722        Added an accessible label to the hidden password field protecting forms

                   TL-7157 introduced a field as a workaround to prevent browsers from
                   automatically loading users saved passwords where they weren't desired.
                   This issue introduces a label for the field so that if this field is
                   detected (via a screen reader or other means) a user is not confused as to
                   its purpose

    TL-7737        Improve help text for Case insensitive shortnames option on Completion import page
    TL-7745        Added labels to settings on Site administration > Front page > Front page settings
    TL-7748        Improved Accessibility when editing the Site administration > Plugins > Activity modules > Quiz Settings
    TL-7750        Improved layout of "User Fullname (with links to learning components)" Report builder column
    TL-7772        Make sure Case insensitive shortname checkbox loads value from database on page load
    TL-7792        Added settings to enforce https access and prevent embedding of content in external Flash and PDF files
    TL-7813        Reduced events triggered when program user assignments are updated

                   Some events were being triggered unnecessarily when updating program and
                   certification user assignments. They will now only be triggered if it is
                   certain that there are changes that need to be signalled.

                   Please remember that user_assignments_task by default is scheduled to
                   execute just once per day, whereas assignments_deferred_task is designed to
                   be run every time cron runs.

    TL-7824        Moved program user assignment deferred flag reset to start of function

                   If changes are made to a program's assignments while the function is
                   running in cron, those changes will be processed the next time the deferred program
                   assignments scheduled task runs (default: Every cron run), rather than having to
                   wait until  program user assignments scheduled task runs (default: Nightly) or
                   another change is made.

    TL-7869        Updated timezone file to 2015g


Bug fixes:

    TL-6957        Display correct due date value in the upcoming certifications block
    TL-6981        Reaggregate course completion when activity completion criteria are unlocked without deletion

                   Previously, course completion status was only reaggregated if "unlock with
                   delete" was used. If "unlock without delete" was used, it was possible that
                   users who meet the new completion criteria were not marked complete, and
                   this would not be fixed by any cron task. This could lead to users being
                   stuck with an incomplete status. Now, the records will be marked for
                   reaggregation and will be processed by the completion cron task.

    TL-7273        Corrected the help text for Report builder simple select filters

                   Filters that use a drop-down select with no additional options such as 'not
                   equal to' now have correct corresponding help text, rather than referring
                   to additional options that do not exist.

    TL-7398        Fix course backup and restore to include completion status
    TL-7437        Switched the badges backpack URL to use HTTPS
    TL-7514        Fixed the display order of Face-to-face sessions for the Face-to-face direct enrolment plugin

                   Sessions will now be displayed in order of their start date/times instead
                   of when they were created

    TL-7559        Enabled the transfer of position and organistion custom fields for the database source of HR Sync
    TL-7562        Fixed strings for audience rules based on course and program completion
    TL-7594        Fixed users booked on a Face-to-face session with no dates being incorrectly removed when another user cancels their booking
    TL-7602        Re-enabled the Save and Cancel buttons for the Face-to-face take attendance tab

                   Save and Cancel buttons present in previous versions have been reintroduced
                   to the Face-to-face take attendance tab. Save must be clicked in order to
                   update attendance records.

    TL-7611        Fixed the handling of username and suspended fields for external database sources in HR Import
    TL-7644        Corrected the amount of white space in the 'recordoflearning' language string
    TL-7659        Prevented cancellation notifications being sent to users booked in completed Face-to-face sessions when the course is deleted
    TL-7660        Fixed the behaviour of pagination on hierarchy index pages

                   When viewing Positions, Organisations, Competencies or Goals within a
                   framework, pagination was not working correctly and instead was displaying
                   all of the items even though the paging bar was displaying the correct
                   number of pages.

    TL-7664        Fixed dynamic audience rules based upon checkbox position custom fields
    TL-7675        Fixed the display of an aggregation warning for Report builder columns

                   The warning that column aggregation options may not be compatible with
                   reports that use aggregation internally is now shown only for reports that
                   actually use aggregation internally.

    TL-7676        Fixed the display of duplicate categories in pie charts
    TL-7686        Fixed URL validation when adding new links to the quicklinks block
    TL-7691        Fixed the removal of individual assignments to company goals

                   When removing a user's individual assignment to a company goal, all user
                   assignments for that user-goal pair were being deleted. Group assignments
                   then regenerated the missing user assignments on the next cron, now only
                   the individual user assignment will be deleted.

    TL-7694        Fix undefined index error when viewing user's position details without specifying type of position
    TL-7695        Re-aggregate when course completion criteria is changed without deletion

                   When changing course completion criteria, and unlocking without deleting
                   existing completion data, re-aggregation was not being performed. Now,
                   users who are assigned but not complete and match the new criteria will be
                   marked complete after cron re-aggregates them. To fix any users affected by
                   this problem, an upgrade script will mark all incomplete users in all
                   courses for re-aggregation, which will be performed by cron, and may take a
                   while to process on larger sites.

    TL-7698        Fixed the handling of position and organisation 'Text area' custom fields within HR Import
    TL-7718        Fixed revoked alerts for deleted users when alert is set to "send alerts to all members"
    TL-7723        Fixed phpunit test failure caused by Norfolk Island timezone change
    TL-7724        Fixed an error when adding audience visibility during program creation.

                   A user who was assigned the site manager role within a category context
                   would previously be presented with an error when giving audiences
                   visibility during program creation. This error no longer appears.

    TL-7725        Removed calls to window.status from group member management pages
    TL-7732        Allow HR import to set posenddate value as blank when posstartdate is set
    TL-7749        Linked the Download table data with the dropdown when exporting site logs
    TL-7769        The Report builder "Manager's name" filter now counts users without a manager as "empty"
    TL-7770        Fixed date validation for Face-to-face sessions when removing dates or wait-listing a session
    TL-7777        Prevented the element library dialog from saving to the database

                   The multi select dialog example in the element library was previously
                   saving to the database, which should not have been happening.

    TL-7783        Fixed the ordering of the Face-to-face waitlist

                   Previously when a user cancelled an overbooked session the Face-to-face
                   replaced them with a user from the waitlist based off the user's names, now
                   the replacement is decided based off their signup time.

    TL-7784        Fixed the help text for Face-to-face 'minimum capacity' setting
    TL-7785        Changed course catalog query to prevent failure in MariaDB

                   A bug in MariaDB was causing a query in the course catalog to return the
                   incorrect values. The query has been changed to avoid the problem. See
                   https://mariadb.atlassian.net/browse/MDEV-9028 for more infomation about
                   the bug.

    TL-7789        Fixed the formatting of the Face-to-face intro page
    TL-7821        Fixed a Totara Connect upgrade step that introduced a non-existent local plugin
    TL-7833        Fixed cron failure when sending Face-to-face notifications

                   When scheduled Face-to-face notifications were being sent out, the cron
                   task would potentially fail if notifications were going to users who had
                   their session bookings approved by a manager. This has now been fixed,
                   notifications go out as normal, and cron is not disrupted.

    TL-7836        Ensured images are restricted by their assigned widths

                   If an image is resized from its native dimensions and then displayed,
                   Internet Explorer would display the image at its native size, and not the
                   size that had been requested.

    TL-7851        Fixed the display of the "duedates" column for program and certification overview Report builder reports
    TL-7876        Stopped the incorrect archiving of facetoface sessions without dates

                   Previously if a user was waitlisted on a Face-to-face session which had no
                   dates set, in a Certification Course. When the user's recertification
                   window opened, the signup would be marked as archived, meaning it would no
                   longer count towards course completion.

    TL-7881        Recreate course completion records when activity criteria are reset with deletion

                   Course completion records for users who were not complete according to the
                   new criteria were not being recreated immediately. Although the records
                   were being created when the completion cron task was run or when a user's
                   status in the course changed, it was possible that some unexpected
                   behaviour could have occurred due to the missing records.

    TL-7883        Fixed date handling on the Face-to-face block calendar page
    TL-7909        Make sure url params are passed when using report builder toolbar search
    TL-7921        Fixed regression with media playback when request_order="GPC" in PHP.ini


Contributions:

    * Eugene Venter at Catalyst NZ - TL-7529


Release 2.7.8 (20th October 2015):
==================================================


Security issues:

    TL-7138        Improved the cleaning of dynamically generated module names

                   Calling "required_param('module', PARAM_COMPONENT)" actually restricts the
                   allowable characters in a module name and the function returns an empty
                   string upon detecting an invalid module name. In the past, there was no
                   check if an empty string was indeed returned. Now, the code throws an
                   "invalid_parameter_exception" if the required_param() call returns an empty
                   string.

    TL-7152        Added workaround for known security issues with Flowplayer
    TL-7377        Fixed the capability moodle/cohort:view allowing a user to edit global audience settings
    TL-7112        Added options to secure how referrer information is sent to external sites


Improvements:

    TL-6570        Added events to the Totara Alerts and Tasks APIs
    TL-6821        Added full textual representation for the 'month of year' and for the 'weekday' within report builder reports
    TL-7089        Added support for external Oracle databases in HR Import
    TL-7298        Implemented access to courses with "enrolled only" visibility via visible programs

                   Previously, if users were assigned to a program containing courses with
                   visibility settings of "enrolled users only" or "enrolled users and members
                   of selected audiences" where they weren't a member of the selected
                   audience(s) and weren't already assigned to the courses, the users couldn't
                   launch the courses because they were hidden. Launching the course from the
                   record of learning and required learning pages now process enrolments
                   before checking visibility, allowing users access to the course.

    TL-7316        Added 'Percentage Completed via RPL' column to 'Course completion by RPL' report source
    TL-7397        Reduced the memory usage of program assignment completion date calculations

                   These functions were loading huge amounts of data in an attempt to improve
                   speed, much of which never going to be used, and resulted in memory
                   overflows in some large sites. They now load the smaller chunks of data
                   which are more likely to be used, this should result in a better balance
                   between speed and memory use.

    TL-7402        Improved the fixed expiry minimum calculation to be relative to completion date

                   Previously, the "Minimum active period" was being calculated relative to
                   the current date. This worked fine for users completing their
                   certifications within Totara, but completion uploads resulted in unexpected
                   results. Now, the calculation will ensure that the new expiry date is at
                   least "Minimum active period" away from the completion date. If the
                   completion date was far in the past, the calculated expiry date may also be
                   in the past. This change will have little effect on users completing their
                   certifications within Totara (the exception being where an activity reports
                   completion to have occurred some time in the past, such as Face to face).

    TL-7413        Improved the completion upload instructions for the certifications "duedate" column
    TL-7419        Improved scheduled tasks error logging
    TL-7511        Improved the layout of the dock when using the Kiwifruit responsive theme
    TL-7512        Increased the size of icons within the enhanced catalogue when using the Kiwifruit responsive theme
    TL-7528        Removed the gap between toolbars and editor content in the Kiwifruit responsive theme
    TL-7576        Improved the performance of the prog_get_all_programs function

                   This change should improve the performance of the Record of Learning
                   Programs & Certifications tabs, along with the required learning page. This
                   will be most noticeable for larger mysql sites.

    TL-7613        Improved right-to-left language support within the my team report
    TL-7656        Added docs explaining that db row locking is not reliable

                   Documentation on lock factories has been expanded to explain that database
                   locking is not reliable and should only be used as a last option.
                   The main reason for this is that the cleanup of locks may be delayed until
                   shutdown, this can lead to locks not being released in the following
                   situations:
                   * If PHP segfaults, as in this situation shutdown handlers are not
                   executed.
                   * The database connection is dropped or closed prior to the shutdown
                   handlers finishing there execution.
                   * Incorrect configuration of FastCGI (especially on IIS) can lead to cron
                   scripts terminating prematurely after a relatively short period of time.
                   * If PHP runs out of memory during its operation.


API changes:

    TL-7502        Embedding of Youtube content now uses the current Google API

                   This is a backport of MDL-50176. Google has switched off support for the
                   API Totara was previously using for Youtube.
                   The current API is now in place and being used for all embedded Youtube
                   content.


Bug fixes:

    TL-4379        Fixed the behaviour of Face-to-face notification templates

                   Face-to-face notifications are now linked to Face-to-face templates. This
                   allows updates to templates to also update linked notifications. This also
                   means when creating a new  Face-to-face activity the there will be
                   notifications for all templates.

    TL-5226        Fixed incorrect email footer when a Feedback360 request is sent to external users
    TL-5261        Made the course upload tool respect the defaults for course completion settings
    TL-5730        Scheduled Face-to-face notifications are now only sent to users who were eligible at the time

                   Previously, if a notification was scheduled to be sent out a certain amount
                   of time prior to the start of the Face-to-face session, this notification
                   would also be sent to any new users who signed up after the scheduled time.
                   Now, even if cron is run much later, these notifications will only go to
                   users who were eligible to receive the notification at the time it was due
                   to be sent.
                   The condition still exists that they must currently be eligible. For
                   example, if a notification is to be sent to booked users only, and a booked
                   user cancels before the notification is sent out, that user will not
                   receive the notification.

    TL-6877        Allow a user to enter a Face-to-face signup note when using the direct enrolment plugin
    TL-6909        Fixed dynamic audience rules based upon checkbox organisation custom fields
    TL-7134        Fixed the 'Force password change' flag which was being incorectly set for single sign on authentication types
    TL-7181        Fixed and restored recipients default values for Face-to-face automatic notifications if they were updated
    TL-7286        Fixed HR Import to properly handle csv files with UTF BOM encoding
    TL-7306        Fixed Face-to-face notifications showing a timezone of 99 when set to display in the user's timezone.

                   Previously, Face-to-face notifications that used the [alldates] placeholder
                   would show '99' in place of the timezone when a session was set to display
                   in the user's timezone. This has been fixed so that they properly show the
                   user's timezone.

    TL-7308        Fixed possible timeouts when activating appraisals and creating appraisal snapshots
    TL-7317        Prevented a scenario in the question bank where it was possible to make a question category one of its own children

                   It was possible for a question category to be a parent of its own child if
                   two people had the edit page open at the same time. This can no longer
                   happen and an appropriate error message will be displayed instead.

    TL-7334        Fixed the user selector to respect the user identity settings
    TL-7338        Removed blank lines from error cells when exporting completion upload reports
    TL-7365        Fixed the display of the task block when empty yet configured to show
    TL-7391        Fixed current session pagination to hide/show reportbuilder columns
    TL-7414        Fixed view hidden learning capabilities when managing learning

                   The capabilities 'moodle/course:viewhiddencourses',
                   'totara/program:viewhiddenprograms' and
                   'totara/certification:viewhiddencertifications' were not being checked
                   correctly when viewing the old course, program or certification catalogs or
                   managing courses, programs or certifications. This prevented users who had
                   been granted one of these capabilities at a category level from viewing the
                   corresponding content at that level or below.
                   Note: This still will not work for the enhanced catalog, due to restrictions
                   with capability checks in report builder sources.

    TL-7431        Fixed the vaildation of position start and end date when importing users via HR Import
    TL-7435        Fixed the misalignment of table cells on the Face-to-face attendance page
    TL-7436        Fixed the editing of a user's position so that the description field is now saved the first time it is edited
    TL-7442        Audience management tabs now correctly check moodle/cohort:view

                   The cabability 'moodle/cohort:view' now allows a user to view, but not
                   edit, the tabs for enrolled learning, visible learning and goals. This
                   works in both system and category contexts.

    TL-7447        Added help icons to Totara Connect client edit form
    TL-7448        Prevented historical Face-to-face session completions from overriding more recent ones

                   There were a couple of problems with Face-to-face session completions. If
                   you marked attendance for a user in a recent session, then later marked
                   their attendance in an older session, then the older session date was being
                   used when calculating completion. This caused a problem when the course had
                   been reset as part of a certification, or when activity completion criteria
                   were unlocked and deleted.

    TL-7450        Prevent incorrect notifications from being sent to users when acting upon a Face-to-face booking request task

                   When a booking request is approved or declined via the tasks block in My
                   Learning, but the request had already been actioned directly via the
                   Approval required tab in the Face-to-face activity an incorrect
                   notification would be sent to the learner.

    TL-7484        Fixed regression in phpunit tests with incorrect file location
    TL-7499        Fixed which users get shown in the recipients fields when manually awarding a badge
    TL-7517        Fixed the sync password setting for Totara Connect server
    TL-7522        Fixed the export of user reports where the User ID was being exported instead of the user's fullname
    TL-7534        Fixed the HR Import of custom user date fields when some values are missing from the CSV file
    TL-7554        Fixed the use of a PHP short tag when adding a menu of choices custom field filter in report builder
    TL-7563        Enabled dock in older versions of internet explorer (IE8 & IE9)
    TL-7570        Fixed the display of Positions and Organisations within the administration block

                   Previously users with permission to view positions and organisations were
                   not always shown these items within the administration settings block.
                   These pages are now correctly shown to users who have permission to view
                   them.

    TL-7573        Improved right-to-left language support within multi-select dialogs
    TL-7592        Fixed room checks to prevent the double booking of rooms
    TL-7650        Increased the length of some database fields in appraisals

                   Short field lengths for scale values and sorting could lead to database
                   errors if adding more than 99 questions to a single page in an appraisal,
                   or more than 99 values to a single scale.
                   This has been fixed by increasing the size of the sortorder and scaletype
                   fields within appraisals.


Contributions:

    * Joby Harding from Mindclick - TL-6570
    * Amir Elion at Kineo Isreal - TL-7613


Release 2.7.7 (22nd September 2015):
==================================================


Improvements:

    TL-6484        Totara Connect Server

                   Totara Connect makes it possible to connect one or more Totara LMS or
                   Totara Social installations to a master Totara LMS installation.
                   This connection allows for users, and audiences to be synchronised from the
                   master to all connected client sites.
                   Once synchronised users can move between the connected sites with ease
                   thanks to the single sign on system accompanying Totara Connect.

    TL-6599        Changes to program assignment dates now override previous exceptions

                   When the completion date of an assignment in a program or certification is
                   changed, any previous exceptions that the related users had will be
                   removed, the specified date will be applied, and exceptions will be
                   recalculated. As a result, exceptions that were previously resolved using
                   "Dismiss and take no action" might reoccur, but this change is providing a
                   means to re-assign those users which was previously not possible (unless
                   the user was completely removed). This patch also enforces the rule that
                   due dates can only be increased (even if an earlier assignment date is set)
                   - previously it was unintentionally possible to decrease them under certain
                   circumstances.

    TL-6634        Added a new capability for managing user profile fields

                   Added totara/core:manageprofilefields capability to allow managing of user
                   profile fields. By default it is not enabled for anyone

    TL-6939        Added a warning that column aggregation options may not be compatible with reports that use aggregation internally
    TL-6965        Reduced the number of DB queries used when triggering events on update of Face-to-face signups
    TL-7151        Added additional settings to the Custom Totara Responsive theme

                   Custom Totara responsive now has the ability to change the text colour,
                   background colour, background image, background image location, and add a
                   footnote.

    TL-7269        Added help text to timezones and times in Face-to-face sessions
    TL-7272        Improved the layout of docked blocks
    TL-7378        Improved the behaviour of the audience-based visibility section of the edit course form


Bug fixes:

    TL-4527        Corrected PHP syntax error when using Hierarchy bulk actions.
    TL-5822        Added a warning to pre-install environment checks if the max_input_vars setting is too low.
    TL-6195        Fixed duplicate messages being sent to managers by Face-to-face when the user has an invalid email address
    TL-6265        Fixed navigation by month in the Face-to-face calendar block
    TL-6632        Fixed the generation of unique tokens within core libraries

                   There were several cases of uniqid being used to generate unique
                   identifiers or tokens.
                   These calls have now been improved to use a method that ensures a truly
                   unique identifier or token is generated.

    TL-6659        Refactored program assignment code

                   Refactored program assignment code to make it more efficient and easier to
                   maintain. It will also prevent sql problems, which could occur on some
                   systems with some configurations, when assigning large numbers of users to
                   programs and certifications (such as using an audience). Performance for
                   adding and removing users has been improved by about a factor of two, while
                   performance when reprocessing existing user assignments (happens during
                   nightly cron) has been significantly improved (from 3 database queries per
                   user assignment down to zero). This should greatly reduce problems
                   experienced with long nightly cron jobs on large sites.

    TL-6804        Fixed competencies in a learning plan showing linked courses even when the course was hidden
    TL-6940        Fixed permissions handling when using the multiple hierarchy dialog

                   The multi hierarchy dialog extends the standard hierarchy dialog but failed
                   to pass through the fourth parameter. This caused the permissions to be
                   incorrectly checked resulting in a false permissions error.

    TL-6970        Fixed hierarchy page not loading due to MySQL join limit

                   MySQL has a limit of 61 tables in a join. When viewing a hierarchy
                   framework, when 60 or more custom fields were defined (across one or more
                   types), the page was failing to load. The query has been changed to prevent
                   this problem.

    TL-6980        Fixed the "Show only active enrolments" option in the Grader Report
    TL-7023        The "Upcoming Certifications" block will now be hidden when "Enable Certifications" is set to Hide or Disable.
    TL-7035        Fixed inconsistent date fields in Excel exports from the Record of Learning - Certifications report source
    TL-7039        Prevented Face-to-face from sending booking confirmations for past sessions

                   When turning off "Approval required" for a Face-to-face activity a booking
                   notification was being sent for sessions in the past. This is now
                   prevented.

    TL-7045        Enable content restriction options for the Face-to-face interest report source
    TL-7074        Fixed the context for capability checks for the display of the button to create new courses, programs and certifications.

                   Users who had been assigned a role with permissions to create programs,
                   certifications or courses within specific categories would not have the
                   relevant "Create" button within the enhanced catalog. Now if they have
                   permissions to create a program, certification or course within any
                   category, this button will appear.

    TL-7114        Show hidden courses, programs and certifications to enrolled users in the Record of Learning

                   Several problems were fixed relating to course, program and
                   certification visibility, in relation to the normal and audience based
                   visibility settings. In some situations, the normal visibility setting was
                   being used when audience visibility was enabled. As a consequence, hidden
                   assigned courses, programs and certifications will now be visible in the
                   Record of Learning, restoring the behaviour from Totara 2.6. As before this
                   patch, hidden assigned courses will not be accessible, but hidden assigned
                   programs and certifications will be.

    TL-7121        Fixed Programs that are potentially stuck as unavailable

                   In 2.6.10, we removed the "availability" checkbox, so that availability is
                   now controlled via the available from/until date fields. This upgrade
                   catches any programs left as unavailable without availability dates. Any
                   issues found will be output to the screen during the upgrade and saved to
                   the upgrade_logs.

    TL-7164        Fixed pagination on the Record of Learning course, program and certification history pages
    TL-7166        Added course reminders to the course backup and restore functionality
    TL-7186        Fixed the translation of generic error messages within totara dialogs
    TL-7191        Fixed a missing sesskey in ajax requests when creating a filter in report builder reports

                   The sesskey and relevant checks were missing in ajax requests involved in
                   adding some audience filters to the report builder.  These have now been
                   put in place.

    TL-7206        Fixed the default end date for learning plans not defaulting to the end date of the associated learning plan template
    TL-7215        Fixed reportbuilder filters for "Menu of choices" custom fields with values containing a comma
    TL-7220        Fixed the Foreign key checks for Totara Dashboards in the XMLDB editor
    TL-7222        Removed the dashboards link from the navigation node when a user has no dashboards assigned
    TL-7224        Fixed the display of Certificates where the "Print Date" depends on a deleted activity
    TL-7234        Fixed the caching of custom Totara Menu urls with course id parameter
    TL-7235        Fixed an error on repository settings pages for hidden but enabled repositories
    TL-7248        Reverted change causing an inability to see uploaded images in Internet Explorer
    TL-7263        Fixed the restoration of course backups containing invalid audience visibility settings

                   If you backup a course with audience visibility it includes the ids of all
                   selected audiences, previously if you attempted to restore this backup
                   without matching audiences it would fail, now it logs a warning and
                   continues restoring the course. It is important to note if you are moving
                   backups between sites the audience ids might not match the expected
                   audiences.

    TL-7265        Improved the layout of tabs when viewing a SCORM
    TL-7275        Fixed case sensitivity for the search within Hierarchy bulk actions.
    TL-7281        Fixed Face-to-face signup process when approval is required for a session with no date

                   This issue occurred when a user signed up to a Face-to-face session that
                   required approval but did not yet have a date. When the manager approved
                   the signup request they were incorrectly booked into the session instead of
                   waitlisted.

    TL-7283        Fixed the field mapping for Organisation and Position imports using a database source
    TL-7292        Fixed a display issue with the file manager when loaded in an iframe

                   When loading the file manager within an atto editor instance and attempting
                   to upload a new file, the display was inconsistent with other file editors.
                   This patch fixes that issue

    TL-7295        Remove unused function rb_display_certification_duedate from base source
    TL-7296        Fixed the minimum Totara 2.2 version in the UPGRADE.txt file
    TL-7303        Fixed hours_minutes display function in the report builder
    TL-7319        Fixed the display of custom fields in the report builder when using a non-English language
    TL-7323        Added checks for https:// links in the learning plans evidence link functionality
    TL-7328        Fixed checks for the course custom fields create, update, and delete capabilities
    TL-7333        Reset cache for current session if required and do not show a menu item if it is disabled through an "Advanced features" setting
    TL-7351        Fixed icon display when managing courses and categories
    TL-7360        Consistently prevent suspended and deleted users from getting any emails
    TL-7362        Updated INSTALL.txt to reflect support for IE8


Contributions:

    * Andrew Hancox at Synergy Learning - TL-6195
    * Carlos Jurado at Kineo UK - TL-6265
    * Eugene Venter at Catalyst - TL-7166
    * Pavel Tsakalidis at Kineo UK - TL-7164


Release 2.7.6 (18th August 2015):
==================================================


Security issues:

    TL-7157        Added a new workaround for password autocompletion issues in some modern browsers

                   This fix works around an issue whereby some modern browsers would
                   automatically fill any password field in any form with a users stored
                   password for the site.
                   This would only occur after the user had made the decision to save Totara
                   authentication credentials within the browser.
                   Previously implemented directives telling the browser to not automatically
                   fill in the field are now ignored.


Improvements:

    TL-3202        HR Import now correctly enforces required user fields

                   It was previously possible to not include some required user fields when
                   using HR Import.
                   First and last name columns are now automatically required if user creation
                   is allowed, and the email field is automatically required if duplicate
                   emails are not allowed and user creation is allowed.
                   It is possible to exclude the first name, last name and email columns if
                   only the user update and/or delete options are enabled.

    TL-5955        Added new events for the creation and deletion of RPL course and activity completions
    TL-6436        Added an option to reset notifications to default for Face-to-face notifications

                   Sites that have been upgraded through Totara 2.4 may have Face-to-face
                   activities that do not have the complete series of notifications a newly
                   created Face-to-face activity would have.
                   This improvement introduces a means of resetting the default notifications
                   allowing those sites that have Face-to-face activities with missing
                   notifications to reset the default notifications if they wish in order to
                   get them back.

    TL-6807        Added a date format setting for HR Import of users when using an external database source
    TL-6817        Added new capabilities to allow the delegation of language settings control

                   Two new capabilities have been added to allow delegation of control of
                   language settings and language packs.
                   Previously this was controlled by the site config capability.
                   By default only site administrators have these new capabilities.
                   The two new capabilities are:

                   * totara/core:langconfig - Allow access to edit language settings.
                   * tool/langimport:managelanguages - Allow installing and uninstalling of
                   language packs.

    TL-6929        Improved Behat tests that use Totara navigation
    TL-6994        Improved the performance of scheduled reports if the export to file system option is enabled

                   Previously scheduled reports with the export to file system option turned
                   on would be generated twice, once for the recipient of the report and once
                   for the file system.
                   The code now only generates the report once and uses it for both the
                   recipient and the file system.

    TL-7109        Changed audience strings to reflect what start and end dates actually do
    TL-7130        Improved the redirect on saving changes when editing Totara menu items

                   The current behaviour is that you will get redirected back to the index
                   page when you save any settings. This means that you will have to go back
                   to the edit page and then navigate to the "Access" tab in order to set
                   custom access rules after having set the visibility to "Use custom access
                   rules".
                   The new behaviour is to redirect to the "Access" tab when the visibility
                   setting is changed to "Use custom access rules".



Bug fixes:

    TL-5709        Prevent exceptions and changes to due date for completed programs

                   Once a user has completed a program, changes cannot be made to their due
                   date using the Assignments tab. A consequence is that new exceptions cannot
                   occur once a user has completed the program. Similarly for certifications,
                   time due changes will not be possible after the user first certifies (after
                   this point, either they are certified, in which case they are due on their
                   expiry date, or their certification has expired, in which case they are
                   overdue).

    TL-3550        Fixed the incorrect removal of completed Feedback 360 requests if JavaScript is disabled

                   This issue was caused by behaviour inconsistency between JS being enabled
                   and disabled.
                   If JS was enabled when editing a Feedback 360 with completed requests and
                   the user clicked add users the page would be lost and the completed
                   requests would be incorrectly removed.
                   The basic interface now behaves in the same way as the enhanced interface.

    TL-6455        Fixed the formatting of report names used within in the Graphical Reports block

                   Report names that contain special characters are now displayed correctly
                   within the Graphical Reports block.

    TL-6487        Fixed the display of competencies achieved through course completion on the My Team page

                   Previously the number of competencies achieved for each team member was
                   been incorrectly displayed on the My Team page if one or more competencies
                   had been achieved through course completion due to stats not being
                   correctly recorded.
                   This has been fixed and an upgrade step ensures all stats are correct.


    TL-6512        Fixed course reminder escalation messages being sent for all historical course completions
    TL-6575        Fixed report builder column order when exporting to Excel in RTL languages
    TL-6645        Changed Certification Completion report source columns to use certification status rather than program status

                   Several fields in the certification completion report source were changed
                   so that their information is determined by the certification status value
                   rather than the program status. The Status column now shows the same data
                   as the Record of Learning: Certifications Status column. Is Complete was
                   changed to Is Certified and Is Not Complete to Is Not Certified. Those two,
                   as well as Is In Progress and Is Not Started were changed to reflect the
                   correct state of the certification. Columns and filters in existing reports
                   have been converted, but customised column headers need to be updated
                   manually to reflect the change. Users should check any saved searches which
                   use these filters, as they may no longer show the information that is
                   expected.

    TL-6708        Fixed course custom field data being saved after events

                   Course custom field data is now being saved before the course_created and
                   course_updated events, allowing observers of those events to access custom
                   field data.

    TL-6767        Fixed HR Import producing a fatal error if more than 65336 import errors were encountered
    TL-6811        Fixed an undefined variable notice when editing a course
    TL-6908        Fixed the display of stage titles when exporting an Appraisal

                   When an Appraisal had a long stage title and either a short description or
                   no description at all the title would sometimes be cut off in the PDF that
                   was produced by the export.
                   This was affecting the interface and PDF snapshots.

    TL-6955        Fixed Face-to-face Session report source Role columns and filters not working

                   These columns and filters are now selectable and use language strings.

    TL-6964        Improved validation when creating main menu items with custom access rules

                   This changes improves the validation of main menu custom access rules to
                   ensure items cannot be created within invalid rules.

    TL-6983        Fixed non-unique query parameter names in report builder filters

                   Report builder filters were previously attempting to generate unique
                   parameter names by hashing a combination of information about the filter.
                   This could lead to duplicate parameter names being generated on occasion
                   causing an error.
                   This has been fixed to use sequential param names instead ensuring a
                   parameter name is always unique.

    TL-6986        Fixed the Face-to-face Manager approval radio button disappearing when user signup note is disabled
    TL-6989        Fixed conflicting content option aliases for report builder reports
    TL-7046        Fixed client side form validation on forms without a header
    TL-7048        Fixed the sending of certification alerts so that suspended users are excluded
    TL-7083        Fixed a missing include when trying to search for a program or certification
    TL-7095        Removed all uses of the sql_fullname function from within the Site Logs report source
    TL-7099        Fixed over restrictive capability checks when uploading custom certificate images

                   User with the totara/core:modconfig capability may now upload custom
                   certificate images through the certificates module setting.
                   This makes it consistent with the other module settings.

    TL-7102        Fixed the cancel button when editing a course section summary

                   Previously the cancel button when editing a course section summary would
                   not cancel the action but instead complete it.
                   The cancel button now correctly disregards any changes the user has made.

    TL-7110        Fixed program exceptions not being triggered when creating new a assignment

                   Previously if an assignment was added to a program or certification, and a
                   completion date was set, all in one step (without saving in between) then
                   exceptions for those assignments were not being checked.
                   The fix for this issue ensures exceptions are correctly checked and
                   triggered.

    TL-7122        Removed the incorrect commas at the end of lines for when displaying Face-to-face room details
    TL-7142        Added a new capability for the certificate modules "email teachers" setting and updated its language strings

                   Previously the setting was sending notifications to everyone with the
                   mod/certificate:manage capability, which resulted in all site managers
                   receiving the messages.
                   The setting is now called send notifications and it uses a new capability
                   mod/certificate:receivenotification which defaults to only the editing and
                   non-editing trainer roles, if you want your site managers or custom roles
                   to receive these notifications you will have to give them the capability.

    TL-7149        Fixed the display of certification status within report builder filters
    TL-7156        Fixed the display of certification renewal status in the Record of Learning report
    TL-7196        Reset Required Learning menu item cache when programs or certifications are completed

                   When the last Required Learning program or certification was completed, the
                   Required Learning menu item was not being immediately removed. This was
                   causing an error message if it was subsequently selected.



New features:

    TL-6407        Added a new colours custom setting to graphs in report builder

                   It is now possible to specify graph series colours in the custom settings
                   for a report builder report.
                   Colours can now be specified using the following syntax in the custom
                   settings input:

                       colours = #ff0000,#00ff00,#0000ff

                   While it is possible to use any colours the browser supports we strongly
                   recommend only hexadecimal colours are used.


Contributions:

    * Chris Wharton at Catalyst NZ - TL-6964
    * Haitham Gasim at Kineo - TL-6955
    * Jamie at E-learning Experts - TL-5709
    * Jo Jones at Kineo - TL-6767
    * Joby Harding at Mindclick and Russell England at Vision by Deloitte - TL-6708


Release 2.7.5.1 (29th July 2015):
==================================================


Bug fixes:

    TL-6763        Fixed the display of the main menu when an item with children was not visible to the user

                   A problem was identified with the Totara main menu when the current user
                   could not see a top level menu item that had sub menu items that were still
                   visible.
                   Visibility was not being inherited by sub menu items correctly and this
                   resulted in a coding error.
                   This was fixed by ensuring that visibility gets inherited by sub menu
                   items.

    TL-7044        Fixed rules for dynamic audiences based on a text input user profile field having multiple values

                   A bug was discovered with dynamic audiences which had been configured with
                   one or more rules on custom user profile fields with a series of comma
                   separated values.
                   When configured in this way users may be incorrectly added and/or removed
                   from the audience.
                   This could lead to users having access to things that they should not
                   otherwise have access to or for users to lose state and data if they were
                   incorrectly removed.

                   The fix for this includes a large number of new automated tests to ensure
                   that this does not happen again.

    TL-7061        Fixed incorrect triggering of the report_created event

                   The report_created event was being incorrectly triggered when embedded
                   reports were being created.
                   This would occur the first time an embedded report was used.
                   The report_created event is now only ever triggered when the user creates a
                   new custom report.


Release 2.7.5 (21st July 2015):
==================================================


Security issues:

    TL-5289        Missing database record errors no longer contain the database table name
    TL-6469        Fixed missing session key error when setting up scheduled reports

                   This occurred if a user search resulted in more than one page of results
                   and one of the page links was clicked. Session key checking was also added
                   to the audience dialog on this page.

    TL-6823        Improved access control handling in Appraisal and Feedback360 assignments

                   Two scripts in Appraisal and two scripts in Feedback360 were identified as
                   having insufficient access control checks.
                   This has now being remedied and all required access control checks are now
                   being made in the four identified scripts.

    TL-6927        Fixed incorrect synchronisation of suspended users in course meta enrolments
    TL-6930        Fixed incorrect protocol handling in the curl library

                   Prior to this patch use of CURLOPT_PROTOCOLS and CURLOPT_REDIR_PROTOCOLS
                   were limited by the existence of the CURLOPT_PROTOCOLS define.
                   This restriction has been removed as it was no longer necessary.

    TL-7032        Improved the generation of random strings within core

                   It was brought to our attention that in some situations the random string
                   generation used during processes such as resetting of user passwords could
                   be predicted and possible exploits crafted.
                   Prior to this patch random string generation used the PHP built in mt_rand
                   function.
                   After this change we use a variety of methods and fall back to our own
                   unpredictable generation.


Bug fixes:

    TL-5562        Fixed a potential problem when inserting multiple records in a batch

                   This fixes a potential problem when importing a broken CSV file into course
                   completion and a potential minor problem when upgrading multiple custom
                   menu fields in Facetoface module.

    TL-6338        Fixed behaviour of "send all to waitlist" Facetoface setting when manager approval is required

                   Previously when manger approval was required and the send all to waitlist
                   setting was enabled, when a user request was approved they were then
                   booked. This fixes the behaviour so the user is correctly put onto the
                   waitlist when their request is approved.

    TL-6347        Fixed "Dropdown menu" profile custom fields always saving the first option
    TL-6378        Fixed report builder display of columns showing 0, 0% or No when the data is empty

                   If a database column contains no value and a Reportbuilder report is using
                   a number, time, grade, percentage or yes/no display function then the cell
                   in the report will now show "-" or will be empty, rather than showing 0, 0%
                   or No. If a custom report expected to display 0, 0% or No, then it should
                   be changed to return a value of 0 when the data contains null or an empty
                   string, e.g. "CASE WHEN val IS NULL OR val = '' THEN 0 ELSE val END AS
                   val".

    TL-6513        Fixed issue causing Certification expiry periods to double

                   If the Certification Completion Upload tool was used uploading completion
                   records for users who were already assigned to the Certification, an issue
                   could arise where the life of the certification would be incorrectly
                   doubled.

    TL-6527        Fixed events not being called when audiences were unenrolled from courses

                   Some problems relating to Facetoface events were also fixed,
                   including users not being removed from future sessions when they were
                   removed in bulk from courses, and ensuring that users are only removed once
                   their last enrolment was removed.

                   This patch also includes changes to unenrol_user_bulk to prevent sql errors
                   caused by unassigning huge numbers of users at once, and adds tests to ensure
                   that individual and bulk unassigning is working correctly.

    TL-6709        Fixed wrapping of long question titles in Appraisal PDF exports
    TL-6745        Fixed an access control bug preventing a manager's manager from reviewing a learner's goals in appraisals

                   The permissions checks to determine who can view goals didn't allow a
                   manager's manager to view a learner's goals and incorrectly displayed a
                   permissions error when they tried to do so.

    TL-6774        Fixed the display of buttons on the manage courses and category page

                   If a user didn't have the correct capabilities there would be 3 buttons
                   displayed with the text "Add new category" that didn't function correctly
                   due to a permissions issue. These buttons now only show when a user has the
                   correct permissions and function as expected.

    TL-6776        Fixed fatal error when viewing competency records within a learning plan
    TL-6784        Fixed the display of unassigned programs on the record of learning: programs report

                   The record of learning was not displaying programs assigned via learning
                   plans, or completed programs that the user was unassigned from.

    TL-6786        Fixed empty usernames bug in reports for users uploaded with empty name fields
    TL-6797        Fixed the access denied error message for appraisals
    TL-6799        Fixed course creator role capabilities for managing audiences
    TL-6802        Fixed a fatal error with learning plan enrolments when a course is included in multiple plans
    TL-6808        Fixed missing calendar icon when adding a set completion date to an audiences enrolled learning
    TL-6816        Fixed fatal error on cron task when calling function dp_plan_item_updated
    TL-6818        Fixed handling of Facetoface completion records when changing attendance for a user
    TL-6819        Changes in memcached connection settings are now applied immediately

                   Prior to this patch changes to memcached cache store settings were not
                   applied immediately.
                   These settings are now applied immediately after changing memcached cache
                   store settings.
                   Please note you still need to restart memcached server manually if the data
                   storage format changes.

    TL-6833        Fixed a regression where the definition of user profile fields could not be edited

                   Code changes associated with TL-6600 resulted in a regression being
                   introduced that prevented site administrators from being able to edit the
                   definition of a custom user profile field.

    TL-6940        Fixed permission handling when using multiple hierarchy dialog

                   The multi hierarchy dialog extends the standard hierarchy dialog but fails
                   to pass through the fourth parameter. This causes the permissions to be
                   incorrectly checked resulting in a false permissions error.

    TL-6960        Fixed alignment of row headings in course completion report
    TL-6976        Fixed issue where trainers were unable to annotate PDF's submited as part of an assignment
    TL-6979        Fixed Facetoface archive when certification window period equals active period

                   If a facetoface belonged to course which belonged to a certification, and
                   the certification window open period was the same as the active period,
                   then when the course was reset to allow recertification, the facetoface
                   activity was automatically re-triggering completion and recertification.

    TL-6997        Fix prog_get_all_programs incorrectly applying visibility

                   On sites which had switched from normal visibility settings to using
                   audience-based visibility, if a program had previously been set to
                   "hidden", progress was not being updated when users completed courses.

    TL-7028        Fixed handling of incorrectly defined embedded reports

                   This patch fixed a fatal error that would be experienced on the
                   Reportbuilder manage reports screen if the site contained an incorrectly
                   defined embedded report.
                   This is a regression from performance improvements made in the last minor
                   release.


Improvements:

    TL-5736        Course and certification completion import reports can now filter errors

                   A new 'errors' filter has been added to course and certification completion
                   import reports

    TL-6333        Improved robustness of completion and conditional activities in the SCORM module

                   Under cases of heavy learner load, or a misconfigured server, causing
                   errors and communication timeouts the SCORM instant completion could be
                   fragile, which could cause knock-on problems with the opening of any
                   subsequent conditional activities . These changes minimise the consequences
                   of any communication errors within the SCORM process.

    TL-6573        Improved support for RTL languages in reportbuilder graphs
    TL-6820        Improve performance when approving audience ruleset changes
    TL-6829        Added an option to the SCORM activity to ignore mastery score when saving state

                   Prior to this patch when a SCORM package provided a mastery score, and
                   LMSFinish was called, and if a raw score had been determined then the
                   status was being recalculated using the raw score and the mastery score.
                   Any status provided by the SCORM (including "incomplete") was being
                   overridden.
                   Turning this option off (it is on by default, to maintain previous
                   behaviour) will prevent this override.
                   This is only applicable to SCORM 1.2 packages.

    TL-6932        Added a link to the manage extension page in the program extension request emails
    TL-6933        Fixed a regression that prevented managers from approving Facetoface requests without enrolling into the course


Contributions:

    * Sergey Vidusov of Androgogic - TL-6820
    * Russell England at Vision By Deloitte - TL-6932


Release 2.7.4.1 (24th June 2015):
==================================================

Bug fixes:

    TL-6706        Fixed "Set fixed completion" option in Enrolled Learning on an Audience

                   When a program or certification is assigned to an Audience in the Audience
                   Enrolled Learning Tab, and the admin attempts to set a completion time, the
                   "Set fixed completion date" option did not work.

    TL-6814        Fixed unwanted creation of certification completion records caused by a regression in TL-6581.

                   Patch TL-6581 caused certification completion records to be created for
                   user who had been unassigned from certifications. This patch removes those
                   new records and ensures that certification completion records are only
                   created for users who are currently assigned.


Release 2.7.4 (23rd June 2015):
==================================================

Security issues:

    TL-6566        Improved XSS prevention checks when serving untrusted files in IE
    TL-6576        Ensured Audience description is sanitised before display

                   Thanks to Hugh Davenport at Catalyst NZ for reporting and providing a fix
                   for this issue.

    TL-6613        Improved validation of local URLs
    TL-6614        Added a warning when a site is not using HTTPS and secure cookies.
    TL-6617        Added username enumeration warnings to the Security Overview report if self-registration is active or protectusernames is disabled.


Improvements:

    TL-5130        Added suspended user rule to dynamic Audiences

                   It is now possible to include or exclude users from a dynamic audience
                   based on whether or not they are suspended

    TL-6133        Improved performance of the main menu resulting in fewer database queries and file includes on each page view
    TL-6255        Added setting to allow users with inactive enrolments to be shown on course completion reports

                   Normally the course completion and activity completion reports within a
                   course do not show completion information for learners who do not have
                   existing active enrolments, but who may have completed activities in the
                   past when enrolled. Disabling this option on both reports will display all
                   completion data in these reports including for those learners with
                   suspended, expired or removed enrolments.

    TL-6303        Improved PDF export of Appraisals when question content results in a page break.
    TL-6329        Added "Use fixed expiry date" recertification option in Certifications

                   This adds a third option for how the expiry dates on certifications are
                   calculated. Details are provided in the help popups in the 'Certification'
                   tab when editing a certification. This patch also slightly changes the
                   behaviour of 'Use certification expiry date' - if a user's assignment (on
                   the 'Assignments' tab) has a completion due date then this date will be
                   used to calculate the expiry date the first time that the user certifies,
                   rather than just using the date that the user completed the certification.
                   The certification import tool has also been updated to support these
                   changes.

    TL-6358        Added config option to control the display of Hierarchy framework, type and item shortcodes

                   Previously whether Hierarchy shortcodes were displayed was defined in code.
                   This patch adds a new config setting under Advanced Features. If you had
                   previously made a customisation to the code (by setting constant
                   HIERARCHY_DISPLAY_SHORTNAMES in totara/hierarchy/lib.php to true) to enable
                   the display of Hierarchy shortcodes, you will need to re-enable the display
                   of shortcodes using the new configuation setting.

    TL-6452        Improved the performance of the course completion scheduled task
    TL-6523        Allowed users to navigate away from long-running report exports in Reportbuilder

                   Attempting to export a large report and then navigate away to any other
                   page while the export was still processing would result in an error: "Timed
                   out while waiting for session lock. Wait for your current requests to
                   finish and try again later." and then the system could then become unusable
                   for that user. Now the user can navigate away from the export safely (which
                   would cancel the export), or continue navigating the site in a different
                   browser window/tab (while waiting for the export window to complete).

    TL-6544        Changed certification Status strings in certification reports to better reflect the actual statuses

                   "Assigned" was changed to "Not certified"
                   "Completed" was changed to "Certified"
                   "Expired" and "In progress" were unchanged.

    TL-6558        Improved scalability of query in course completion

                   This was causing a database error on some platforms due to an oversized IN
                   query with large data sets.

    TL-6582        Fixed inconsistencies in site manager appearance-related capabilities

                   Previously the appearance related permission for a site manager was not
                   consistent comparing a new install and a permission reset. The
                   totara/core:appearance capabilty is now consistently used across all roles.

    TL-6604        Improved appearance of Learning Plans tables on the My Learning pages for RTL languages
    TL-6626        Added new capability controls for access to activity modules plugin settings
    TL-6639        Updated the default content options for the My Team report to include temporary assignments

                   This change will only affect future installs and My Team reports that are
                   reset to default settings, to apply this change manually you can edit the
                   My Team report and on the content tab tick the "Records for user's
                   temporary reports" option.

    TL-6650        Changed program user assignments to defer large changes to happen on the next cron run

                   Previously, when saving changes to user assignments in a Program or
                   Certification, the new users were assigned when the save button was
                   clicked. This was causing pages to time out when assigning large audiences.
                   Now, the contents of the assignment tab are saved immediately but the users
                   are not assigned to the program until the next cron run occurs. On-screen
                   notifications have been added to indicate if pending assignments are
                   waiting for a cron run.

    TL-6735        Added logging whenever activity completion is unlocked
    TL-6756        Improved information provided by webservices logging


Bug fixes:

    TL-5978        Fixed inconsistent access control checks for Learning Plans

                   The behaviour has now been standardised throughout the code. Granting the
                   totara/plan:manageanyplan capability allows users to create and edit plans for any user.
                   Granting totara/plan:accessplan allows users to see and modify their own plans,
                   and allows staff managers to create and edit the plans of their staff.

    TL-6222        Fixed courses incorrectly being visible in the Courses section of the Navigation block when using audience-based visibility
    TL-6263        Fixed reaggregation of course completion

                   Course completion records would never be reaggregated on the cron run, if
                   the "Completion begins on enrolment" course setting was turned off when
                   course completion criteria were unlocked.

    TL-6319        Fixed rules for dynamic Audiences based on a text input user profile/custom field being empty
    TL-6360        Fixed setting of cancellation custom field value when calling facetoface_user_cancel_submission.
    TL-6372        Fixed course deletion so that deleting a course now removes that course from Programs and Certifications

                   Previously if a course was deleted and it was part of a program or
                   certification, then some actions e.g. setting up recertification would
                   cause an error on cron run. This patch ensures that no new orphaned
                   references will be created and also fixes any that currently exist.

    TL-6374        Fixed Reportbuilder 'last/next X days' date filters

                   The 'Is between today and X days before/after today' filters were
                   internally using a specific date rather than a relative number, resulting
                   in saved searches not working as intended. This filter will now always be
                   relative to the date on which it is used. Existing saved searches have been
                   converted, but it is possible that some may be incorrect (although all were
                   wrong without this patch). We advise that users check that saved searches
                   which contain date filters have the intended values.

                   Note that any users that are logged in and using these filters during the
                   upgrade progress may need to log out and back in to see the correct values.

    TL-6403        Fixed error message when displaying categories that contain only hidden courses
    TL-6419        Removed Temporary manager expiry date from Learner's position page when no temporary manager is assigned
    TL-6438        Fixed parameter validation when using the create/update courses web services
    TL-6440        Fixed create/edit capability permissions for Programs and Certifications
    TL-6466        Fixed dynamic Audience rules based off date/time custom fields

                   If the date/time custom field was set to a date after 2038 the rule
                   comparison broke, we switched the cast2int function to use bigint so the
                   comparison can take place.

    TL-6473        Fixed display of Reportbuilder report graph block for reports where a default sort column is specified
    TL-6508        Fixed unenrolled courses showing in My Current Courses home page block
    TL-6515        Fixed scheduling of HR Import, Reportbuilder export and Reportbuilder caching.

                   HR Import scheduling is now using the system timezone. Scheduled reports
                   are now using timezone of the user that created them.

    TL-6516        Fixed resetting of Certification message logs when the recertification window opens

                   When the window opens it tried to delete message logs for the users manager
                   as well as the user even though the manager records were never created.

    TL-6521        Fixed dynamic Audience date-based rules for first and last login dates
    TL-6539        Fixed Program due messages being sent to users who have current exceptions
    TL-6559        Fixed the Evidence report source showing records for deleted users
    TL-6560        Totara Messaging now consistently uses the support user email as the from address when no from user is provided

                   When sending a message, we now use the support_user email if no user is
                   specified. Send functions will also now support NOREPLY_USER.

    TL-6561        Added additional validation when trying to activate Appraisals containing aggregation questions

                   Stops activation of appraisals containing aggregation questions with no
                   selected aggregations

    TL-6562        Fixed Facetoface session custom fields showing PHP Notice and Warning errors when creating a new session
    TL-6579        Fixed ability to add aggregate rating questions to Appraisals when using a non-English language pack
    TL-6581        Improved handling of and recovery from missing Certification completion records

                   Due to various causes such as page timeouts, it is possible that some
                   certification completion records are not being created. This patch ensures
                   that the records are created when users access their certifications. A
                   check has been added to the certification cron task which will find any
                   users who are missing these records and will create them.

    TL-6587        Fixed HR Import log message if a user cannot be deleted
    TL-6589        Removed invalid CSS declaration

                   There was an @charset declaration in a certifications CSS stylesheet that
                   would cause invalid CSS when theme designer mode is turned off. This has
                   been removed.

    TL-6591        Removed unused CSS declarations

                   There were some unused Mozzilla Firefox CSS declarations that were causing
                   issues with custom CSS in Custom Totara Responsive

    TL-6592        Fixed the display of the completion status for deleted users in Record of Learning reports
    TL-6596        Fixed the unassigning of Audience members from system roles when an Audience is deleted
    TL-6597        Fixed blank rows appearing in the sorting default column on Reportbuilder columns tab
    TL-6598        Fixed Facetoface fullname column always showing 'reserved' in reports
    TL-6600        Fixed error when trying to create a user profile custom field after using the browser back button
    TL-6606        Fixed sending of course Reminder messages

                   When a feedback activity is added to a course, invitation and reminder
                   messages would sometimes not be sent, depending on the "Personal messages
                   between users" message output config settings. These reminder messages have
                   now been converted to standard Totara Alerts.

    TL-6608        Fixed order of icons for RTL languages in the Tasks block
    TL-6619        Fixed the error message when trying to delete an unknown post in the Forum
    TL-6628        Fixed error when trying to close an active Appraisal with no assigned users
    TL-6631        Fixed the line wrapping and display of preformatted text in Labels
    TL-6635        Fixed the formatting of exported columns in the Record of Learning: Certifications report

                   Removes the "overdue" and "X days remaining" warnings displayed on the
                   window opens and expiration date columns for exports of reports based off
                   the Record of Learning: Certifications source.

    TL-6647        Fixed the selection of stages to print when printing Appraisals
    TL-6652        Fixed the display of the 'roles that can view' column on the edit Appraisal page
    TL-6661        Fixed alphabetic ordering of user list when using 'Allocate spaces for team' page in a  Facetoface session, when manager reservations are enabled
    TL-6680        Improved display when adding a random quiz question to a quiz when using RTL languages
    TL-6681        Fixed behaviour of Feedback activity forms when form_change_checker is disabled

                   The form change checker detects if any form elements on the page have been
                   changed since last load. If the form change checker is disabled some of the
                   Feedback activity forms were generating errors.

    TL-6694        Prevented incorrect room booking conflicts from being shown when creating a Facetoface session
    TL-6697        Fixed Facetoface custom rooms on session duplication

                   If you duplicated a Facetoface session with a custom room, the room was not
                   duplicated leaving you with 2 sessions using the same custom room. If you
                   then removed the custom room from one session it was deleted, breaking the
                   other session.

    TL-6705        Fixed incorrect risk flag on Plan Evidence capability

                   totara/plan:editownsiteevidence capability was incorrectly marked as a
                   dataloss risk, which made the Security Overview report say the
                   Authenticated User role was incorrectly defined

    TL-6711        Fixed display of course default section title when using multilang filter on a course using the Demo course format
    TL-6720        Fixed role-based visibility access checks on the frontpage
    TL-6744        Fixed error message when adding linked courses to Learning Plan competencies or objectives


Contributions:

    * Hugh Davenport at Catalyst NZ - TL-6576
    * Pavel Tsakalidis at Kineo UK - TL-6452
    * Rickard Skiold at xtractor - TL-6560
    * Russell England at Vision NV - TL-6360
    * Tom Black at Kineo UK - TL-6516


Release 2.7.3 (19th May 2015):
==================================================

Security issues:
    MoodleHQ       Security fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.7.8_release_notes


Improvements:

    TL-2279        Added new global setting to control user deletion behavior
    TL-5311        Added Course Completion History report builder source

                   This report source contains all records from both the current course
                   completions table and the course completions history table.

    TL-6165        Refactored timezone handling functions to improve reliability of all timezone-related functionality
    TL-6197        Added option to suspend course enrolments when users lose access to a Program

                   Previously, when learners were unassigned from a Program or a Program
                   becomes unavailable, any course enrolments in courses within the program
                   would be removed. This improvement now changes the default behaviour from
                   removing enrolments created by the program enrolment plugin, to suspending
                   enrolments.

                   This also adds a configuration setting in Site Admin -> Plugins ->
                   Enrolments -> Program so you can change the behaviour back to the old
                   "unenrol learners from courses" behaviour if you wish.

    TL-6271        Improved Accessibility of scheduled reports in Reportbuilder
    TL-6278        Removed all uses of deprecated function sql_fullname in Facetoface

                   Full name format setting is now used when displaying the User's name

    TL-6295        Showed expected csv format when importing a "database" course activitiy
    TL-6304        Changed default request method in dialogs to POST
    TL-6315        Improved accessibility of admin checkbox lists
    TL-6327        Added ability to specify database server port for HR Import external database source settings
    TL-6331        Changed timezone.txt downloads to use Totara servers
    TL-6334        Renamed Program "start date" to "date assigned"

                   This more accurately reflects the actual information recorded. This patch
                   also recalculates "date assigned" values for certifications where the
                   "start date" was removed (before this patch, "start date" had no meaning
                   for certifications in the recertification phase).

    TL-6348        Removed unneeded code when viewing a Certifications overdue warning
    TL-6350        Added a help description to Badge description to explain its plain text nature
    TL-6359        Improved the performance of Reportbuilder management pages
    TL-6366        Improved  Accessibility of the page title when uninstalling a plugin
    TL-6367        Added accessible text to the hamburger responsive button
    TL-6384        Improved Accessibility of filters in Reportbuilder
    TL-6386        Added hidden label to bulk user actions dropdown
    TL-6387        Added text to the label for the badge search functionality
    TL-6389        Added text to hidden label when editing a course topic
    TL-6391        Improved Accessibility of custom course icons
    TL-6397        Added text to the page title for the Facetoface interest report for Accessability
    TL-6398        Added title to browser sessions page
    TL-6411        Improved display of security information on calendar exports
    TL-6424        Changed Reportbuilder scheduled task default settings so that scheduled reports are sent when scheduled rather than at most once per day

                   Currently when a new Totara site is installed (or upgrade to 2.7) the
                   default schedule for scheduled reports is once a day. This means that any
                   reports scheduled to be sent more frequently do not get sent.

                   This change means that system will check for pending scheduled reports on
                   every cron run so reports will get sent out on schedule.

    TL-6434        Improved performance when loading Program message managers
    TL-6489        Updated the default schedules for Program scheduled tasks

                   This change will update the schedules for all sites currently using the
                   defaults. Site administrators can customise the timing of scheduled tasks
                   on the "Site Admin > server > scheduled tasks" page, any customisations
                   will be unaffected.

API changes:

    TL-6442        Fixed query parameter name conflicts by improving parameter name generation

                   This fix introduced a new method moodle_database::get_unique_param that
                   returns a truly unique param name with very little overhead.
                   The bug fix involves conversion of areas generating their own "unique"
                   param names to this new method.
                   All new code requiring unique generated params should use this method.

Bug fixes:

    TL-5953        Fixed SCORM resizing and title display when using popup "New window" setting
    TL-5977        Fixed upgrade for Facetoface notifications when upgrading from 2.2
    TL-6101        Fixed display of enrolment button for Facetoface session enrolment for users with no manager
    TL-6143        Fixed password import being ignored when undeleting users in HR Import

                   Previously, when undeleting a user, the user's password would always be
                   reset, regardless of whether or not the password column was enabled and a
                   password was specified. Now, password reset only occurs if there is no
                   password specified in the import file.

    TL-6180        Fixed capability checks for category Audiences
    TL-6191        Fixed permissions when adding visible audiences to a program or course

                   Permissions are now being checked on the correct context level so users
                   assigned at the category, program or course contexts with permissions are
                   now able to perform actions. This applies to Audience visibility for
                   courses, programs and certifications and also Audience enrolment for
                   courses.

    TL-6236        Fixed preservation of formatting in HTML emails sent by Appraisals
    TL-6259        Fixed completion import records being processed in the wrong date order

                   This caused a problem if there were multiple completion records for one
                   user in one course being uploaded and the date format used did not sort the
                   same chronologically and alphabetically.

    TL-6279        Removed all uses of deprecated function sql_fullname in Appraisals
    TL-6284        Removed all uses of deprecated sql_fullname() function in Hierarchies
    TL-6285        Removed all uses of deprecated sql_fullname() function in Learning Plans
    TL-6287        Removed all uses of deprecated sql_fullname() function in Reportbuilder
    TL-6305        Fixed Program/Certification alerts and messages to exclude suspended and deleted users
    TL-6321        Removed window.status Javascript changes that have been deprecated by modern browsers
    TL-6322        Fixed unassociated label when viewing role definitions to improve Accessibility
    TL-6326        Fixed inconsistent behaviour of course visibility icons
    TL-6345        Fixed setting of a Certification completion status to 'expired' when renewal expires

                   Previously, these certifications were set back to status 'assigned'. This
                   patch makes no change to the behaviour of certifications, it just ensures
                   that the correct data is recorded in the database.

    TL-6349        Fixed backup and restore of course Audience Visibility settings
    TL-6351        Fixed display of Graphical Reports Block when the report name contains an ampersand
    TL-6354        Fixed incorrect inclusion of deleted users when using recurring Programs
    TL-6361        Fixed immediate synchonrisation of Audience enrolments after modifications in Enrolled learning tab or when editing a course.
    TL-6365        Fixed page title when editing another users profile to improve Accessibility
    TL-6373        Fixed Facetoface notification status incorrectly sending manager copy when notification is disabled

                   If a notification is disabled, the manager and third party email addresses
                   will no longer receive the notification, regardless of the "Manager copy"
                   setting.

    TL-6376        Fixed invalid HTML when viewing a complete Program with an end note
    TL-6399        Fixed Javascript error when adding and removing attendees from a Facetoface session
    TL-6400        Fixed editing of Hierarchy items description field
    TL-6405        Fixed aggregation for Badges issued report source
    TL-6408        Fixed the "time signed up" column on the Facetoface session attendees tab

                   The time signed up column now shows the latest time signed up instead of
                   the first, so if users cancel and signs up again the column will update.

    TL-6409        Fixed progress bar for Programs in Record of Learning
    TL-6418        Fixed deletion of related scheduling and saved search data in Reportbuilder when a report is deleted
    TL-6425        Fixed scheduled runs of HR Import

                   HR Import was running every cron run, now it is running according to the
                   given schedule.

    TL-6437        Fixed usage of complex passwords in HR Import
    TL-6439        Fixed error message when trying to access the course progress page from Record Of Learning after user is unenrolled from course

                   Previously, if a user was unenrolled from a course, the course progress
                   page became inaccessible. Now that unenrolled courses with progress are
                   shown in the Record of Learning, it makes sense to allow users to see what
                   progress they previously made.

    TL-6445        Fixed changes to Facetoface session attendees after a waitlisted session has started
    TL-6449        Fixed schema errors on upgrade from Moodle 2.7.7
    TL-6450        Fixed export of parameteric reports in Reportbuilder

                   Fixed error that blocked export of reports that require specific parameters
                   to work (like appraisal or audience members).

    TL-6457        Fixed checkbox selection/deselection when Program exception "Select issue type" is changed
    TL-6471        Fixed the course enrolment date after unlocking completion criteria
    TL-6472        Fixed Completion History Import if it is using 'Alternatively upload csv files via a directory'
    TL-6490        Fixed activity completion when using manual grading on a Facetoface activity
    TL-6510        Fixed the rule for dynamic Audiences based on a positions multi or menu type custom field values
    TL-6518        Fixed display of the "Evidence Type" column on the Record of Learning
    TL-6520        Fixed the context checks for program deletion capabilities

                   Program deletion was only working if you had the capability at a site
                   level, this fixes it for if you have the correct capabilities at category
                   or program level.

    TL-6543        Fixed query using IN in course completion

                   This was causing a database error due to an oversized query in some
                   databases with large data sets.


Contributions:

    * Andrew Hancox at Synergy - TL-6445
    * Eugene Venter at Catalyst - TL-6345, TL-6348
    * Gavin Nelson at Engage in Learning - TL-6472
    * Jo Jones at Kineo UK - TL-5953, TL-6437
    * Russell England - TL-6520
    * Ted van den Brink at Brightalley - TL-6376


Release 2.7.2 (21st April 2015):
==================================================

Security issues:
    T-13359        Improved param type handling in Reportbuilder ajax scripts

New features:
    T-13624        Added new OpenSesame integration plugin

                   OpenSesame is a publisher of online training courses for business. This new
                   plugin allows you to sign up for OpenSesame Plus subscription and access
                   the large catalogue directly from your Totara site. To start the
                   registration go to "Site administration / Courses / OpenSesame / Sign up
                   for access". After the content packages are downloaded to your site you can
                   either select them when adding SCORM activities or use the Create courses
                   link.

                   Additional information will be made available in the coming days, if you have any
                   queries please contact your partner channel manager.

Improvements:
    T-14222        Improved accessibility of messages tab in Programs
    T-13925        Improved sql case sensitive string comparisons for completion import records.

                   When 'Force' is enabled the system keeps track of the course shortnames
                   being used, each new course is compared in a case sensitive way and if it
                   matches that but doesn't match exactly the system uses the first course
                   name instance. There will be no error messages on the import report about
                   it.

    T-10482        Allowed selection of Facetoface rooms even when date is not known

                   Contributed by Eugene Venter at Catalyst

    T-14210        Added a label when adding users to a program to improve accessibility
    T-14217        Added debug param to all Reportbuilder reports

                   This allows administrators to retrieve additional debugging information if
                   they have problems with reports. Some reports already had this feature, now
                   all of them do.

    T-14254        Added description field to the badge criteria
    T-14293        Added labels to financial year start date setting in Reportbuilder for accessibility
    T-13859        Added functionality to allow administrators to manage Facetoface session reservations

                   If a manager reserved spaces for a their team in a Facetoface session and
                   then they either left or changed role, there was no way to edit/remove the
                   reservations they made.

    T-14263        Improved the display of User full names for Programs
    T-14251        Added option to update cancellation reason fields in Facetoface

                   Before, admins were not able to update cancellation reason fields when
                   removing attendees from a Facetoface session. Now, it can be done in the
                   attendees tab.

    T-13432        Added position and organisation framework columns and filters to all relevant Reportbuilder sources
    T-10833        Added column 'ID number' when exporting Organisations and Positions from Hierarchies

                   Position and Organisation ID numbers are now available when exporting
                   Organisations/Positions via Hierarchy.

                   Also, there is a new Position report source and an Organisation report
                   source that include columns used when importing data via HR Import.

    T-14155        Changed "No time limit" to "No minimum time" in Program course sets

                   There was confusion about the purpose of this setting. Some people thought
                   that "No time limit" meant that it would allow users to spend as long as
                   they wanted to complete a program, but user time allowance is controlled in
                   the assignments tab. Setting "No minimum time" will prevent time allowance
                   exceptions (except where a relative assignment completion date would be in
                   the past, such as "5 days after first login" being set on a user who first
                   logged in one month ago).

    T-13491        Fixed immediate updating of Audience enrolments after changes in dynamic audience rules
    T-14016        Added "Choose" option as the default value for "Menu of choices" type custom fields
    T-10081        Added ability to send Scheduled reports to users, audiences, and external emails
    T-14212        Restored instant completion for course completion criteria

                   Instant course completion was introduced in Totara 2.5 but was mistakenly
                   removed in 2.6.0. This fix restores instant course completion (when the
                   criteria completion depends on other courses) which also improves the
                   performance of the completion cron tasks.

    T-13542        Changed language pack, timezone and help site links to use HTTPS

API Changes:
    T-14151        Removed unused file totara/core/js/completion.report.js.php

                   File has been unused since v1.1

    T-14242        Added finer grained control to Scheduler form element

                   Every X hours and Every X minutes were added to the scheduler form element
                   which is used for scheduled reports, Report Builder cache refresh and HR
                   Import. The frequency that these events occurs is still limited by the
                   frequency of the corresponding scheduled tasks - to take full advantage of
                   this feature, set "Import HR elements from external sources", "Generate
                   scheduled reports" and "Refresh report cache" to run frequently (e.g. every
                   minute). Any customisation using the scheduler form element will also be
                   affected by this enhancement.

    T-14215        Enforced linear date paths when upgrading Totara

                   When upgrading a Totara installation you are now required to follow a
                   linear release date path. This means that you now MUST upgrade to a version
                   of the software released at the same time or after the release date of your
                   current version.

                   For example if you are currently running 2.5.25 which was released on 18th
                   March 2015, you can upgrade to any subsequent version of 2.5, any 2.6 from
                   2.6.18 onwards, or any 2.7 from 2.7.1 onwards.

                   This ensures that sites never end up in a situation where they are missing
                   critical security fixes, and are never in a state where the database
                   structure may not match the code base.

                   The Release Notes forum is a useful source for the date order of version
                   releases https://community.totaralms.com/mod/forum/view.php?id=1834

Bug Fixes:
    T-14311        Fixed the archiving of Facetoface session signups and completion

                   When uploading historic certification completions future facetoface session
                   signups were being archived, now it will only archive signups that
                   completed before the window opens date.

    T-12583        Fixed behaviour of expand/collapse link in the standard course catalog
    T-13550        Fixed Due Date displaying as 1970 on Record of Learning: Certifications

                   This patch fixed a problem where an empty timedue data value was causing a
                   date in 1970 to show in the Due Date field in the Record of Learning:
                   Certifications report source. It also introduces a comprehensive phpunit
                   test for the certification and recertification process.

    T-13853        Fixed handling of position, organisation, and manager when a validation error occurs in email based self registration
    T-13879        Fixed grade filter when checking against RPL grades
    T-14184        Fixed appending of message body after manager prefix in Facetoface 3rd party notifications

                   If Third party email addresses were specified in the Facetoface settings then any
                   third-party copies of emails sent by the system would not contain both of the
                   manager prefix and the body of the message (the content that the learner receives)

    T-14394        Ensured Audience-based course visibility is considered when adding courses to a Learning Plan

                   This is to prevent managers from adding a course to a Learning Plan for one of
                   their direct reports, than the learner does not have visibility of and can
                   therefore never complete.

    T-14235        Fixed Audience rulesets for Course completion and Program completion
    T-14105        Fixed calculation of 'User Courses Started Count' in the 'User' report source

                   This is now calculated based on course completion records, rather than
                   block_totara_stats (which might be missing 'started' records for various
                   reasons, such as migration from Moodle or changing certain completion
                   settings while a course is active). This affects the 'Courses Started'
                   column in the 'My Team' page - courses started should now always be greater
                   than or equal to courses completed.

    T-14344        Fixed wrong ID field in signup and cancellation custom fields when upgrading to 2.7.

                   Thanks to Russell England at Vision NV from contributing to this

    T-14187        Fixed resetting of Hierarchy item types after every HR Import

                   Hierarchy item (e.g. position, organisation etc) types should only be changed
                   if the HR Import source contains the "type" column.

    T-14284        Changed Record of Learning: Courses report source to use enrolment records

                   Previously, it used role assignment records, but roles can be granted
                   without the user being enrolled, and only indicated some level of
                   capability within the course rather than participation. The whole query was
                   also rewritten to improve performance.

                   Thanks to Eugene Venter from Catalyst for this contribution

    T-14338        Fixed user fullname handling in Facetoface when editing attendees
    T-14243        Fixed handling of special characters (e.g. &) when returning selections from dialogs
    T-14366        Fixed Reportbuilder expanded sections when multiple params are used

                   Thanks to Andrew Hancox from Synergy Learning for this contribution

    T-14192        Fixed Assignment Submissions report when it is set to use 'Scale' grade

                   The Submission Grade, Max Grade, Min Grade and Grade Scale values columns
                   were displaying incorrect information.

    T-13890        Fixed date change emails being incorrectly sent when a Facetoface session capacity is changed
    T-13917        Fixed error when adding Score column to Appraisal Details report

                   The report would fail if the Score column was added to an Appraisal
                   containing a Rating (Numeric scale) question.

    T-13886        Fixed PHP Notice messages when adding a Rating (custom scale) question to Appraisals
    T-14265        Fixed display of paragraph formatting dropdown in the Atto text editor
    T-13742        Fixed uploading of Organisation and Position custom fields via HR Import

                   Also added options to the interface for custom fields, found on the source
                   configuration pages for positions and organisations just like they are for
                   users.

    T-13353        Fixed handling of param options in Reportbuilder
    T-13894        Fixed validation and handling of Facetoface notification titles
    T-13993        Fixed error when uploading users with the deleted flag set

                   When uploading users via the upload users function, if a user in the CSV
                   file had the deleted flag set, and was already marked as deleted in the
                   system, an invalid user error was generated and this halted all processing
                   of the CSV file.

    T-14327        Fixed undefined function call when sorting Dashboards

                   Thanks to Eugene Venter at Catalyst NZ for this contribution.

    T-14048        Fixed incorrect Quiz question bank names after previous upgrade

                   Question banks containing subcategories had the subcategory names
                   incorrectly changed by a change in 2.5.20 and 2.6.12. If you are upgrading
                   from a version affected (2.5.20-25, 2.6.12-18) you may want to check if
                   your Quiz question bank categories are affected.

    T-14186        Fixed max length validation for Question input text box
    T-13009        Fixed incorrect creation of multiple custom room records when saving a Facetoface session
    T-14131        Fixed handling of error when importing users via HR Import with the create action disabled

                   Thanks to Andrew Hancox at Synergy Leaning for contributing the solution.

    T-14302        Fixed database host validation in HR Import settings
    T-13846        Fixed the default role setting for the Program Enrolment plugin
    T-14083        Fixed display of 'More info' Facetoface session page

                   When a session was fully booked, learners booked on the session would
                   receive a ""This session is now full" message instead of the actual details
                   of the session.

    T-14220        Fixed page formatting for the certifications content tab
    T-14237        Fixed incorrect display of Required Learning menu item when no programs currently need to be completed
    T-14279        Fixed error when upgrading site to 2.7, with a custom theme that is not using the Totara menu

                   This affects all sites that meet the following criteria:

                   1. Upgrading to 2.7 from earlier versions.
                   1. $CFG->courseprogress has been turned on.
                   2. Using a theme that does not have the Totara menu.

    T-13845        Fixed setting position fields on email-based self authentication
    T-14075        Fixed inability to send a previously declined Learning Plan for re-approval
    T-13839        Fixed the display of Facetoface enrolment plugin feedback on the enhanced catalog
    T-14065        Removed non-functional "deleted user" filter from bulk user action pages


Release 2.7.1 (18th March 2015):
==================================================

Security issues:
    MoodleHQ       Security fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.7.7_release_notes
    T-13996        Removed potential CSRF when setting course completion via RPL
    T-14175        Fixed file access in attachments for Record Of Learning Evidence items
                   Thanks to Emmanuel Law from Aura Infosec for reporting this issue.


API Changes:
    T-14084        Renamed $onlyrequiredlearning parameter in prog_get_all_programs and prog_get_required_programs functions
    T-14058        Converted all Learning Plan add_to_log() calls to events

                   Plan logging was migrated to new events system

    T-14104        Added courses which have completion records to the record of learning

                   Previously, if a user had been enrolled into a course, made some progress
                   or completed it, then been unenrolled from the course, the record of course
                   participation disappeared from the user's record of learning. With this
                   patch, courses will still show when a user has been unenrolled, if their
                   course status was In Progress, Complete or Complete by RPL. This change was
                   made to the Record of Learning: Courses report source, so all reports based
                   on this source will be affected.

Improvements:
    T-13950        Improved display of long text strings in the alerts block
    T-13944        Improved contents of Course Progress and Record of Learning Courses report sources

                   The Course Progress now uses Report Builder (meaning that you can sort,
                   change columns, etc) and contains the same records as Record of Learning
                   Active Courses. The Record of Learning report source has been updated to
                   include course records based on course completion data, so if a user was
                   previously enrolled in a course and had a course completion record then
                   that course will show in the Record of Learning reports.

    T-13951        Implemented sql_round dml function to fix MySQL rounding problems
    T-13867        Added "is not empty" option to text filters in Reportbuilder
    T-13939        Added course custom field value to Program and Certification overview

                   When a courseset is using "Some courses" completion logic and a course
                   custom field is being used as part of the course completion criteria the
                   custom field is now displayed along with the course so that learners are
                   aware of such completion criteria.

    T-14039        Removed HTML table from tasks block

                   Changed to better meet Accessibility guidelines

    T-12395        Improved HTML heading on calendar page

                   Changed to better meet Accessibility guidelines

    T-13938        Improved required courses message on Program overview

                   The "Some courses" option was recently added to the courseset completion
                   requirements for a program. The overview page for the program however did
                   not change to reflect accurately the possible range of different courseset
                   completion requirements.

    T-14015        Added warning messages to the scheduled tasks page if cron has not run recently
    T-14007        Improved contrast on show/hide icons in HR Import -> Manage Elements

                   Changed to better meet Accessibility guidelines

    T-14095        Improved labels for all filter inputs on the "Browse list of users" page

                   Changed to better meet Accessibility guidelines

    T-13734        Improved labels of all inputs on Reportbuilder filters

                   Changed to better meet Accessibility guidelines

Bug Fixes:
    T-14057        Fixed saving of default content for course and program custom fields
    T-12991        Fixed Facetoface manager reservations with multiple bookings

                   Before, if a learner had been assigned a reserved place they could not be
                   assigned to any other sessions; even if multiple sign-ups was on.

                   Now, it should allow managers to assign members of their staff to multiple
                   sessions if "Allow multiple sessions signup per user" setting is on, but
                   not allow more than one user assignment per Facetoface activity if that
                   setting is off.

    T-13920        Fixed export to Excel of completion progress column in Record Of Learning - Programs report source
    T-13884        Fixed error in Appraisals dialog box when selecting required learning for review
    T-14114        Fixed program and certification exceptions being regenerated after being resolved

                   This patch also prevents certification exceptions being generated when an
                   assignment date is in the past and the user is in the recertification stage
                   (at which point the assignment date is not relevant, as the due date is
                   controlled by the certification expiry date instead).

    T-14093        Fixed dynamic audiences rules based on Position and Organisation custom fields

                   Thanks to Eugene Venter at Catalyst for contributing to this

    T-13628        Fixed deletion of custom fields if missing from the HR Import CSV file
    T-13926        Fixed copying instance data when copying block instances

                   When users click the "Customise this page" button in My Learning, blocks
                   copied from the default My Learning page to the user's personal My Learning
                   page can also copy instance specific data. This allows Quick Links blocks
                   to correctly copy the default URLs.

    T-14070        Fixed MySQL 5.6 compatibility issues

                   Totara would not install on MySQL 5.6, and also unit tests were failing
                   with "Specified key was too long" errors

    T-14170        Fixed Course categories path issue due to changes in 2.7 features
    T-14120        Fixed sort in all Audience dialog boxes
    T-13622        Fixed an issue with the validation of aspirational positions
    T-14142        Fixed display of Submission Feedback Comment and Last modified date in Assignment Submissions report source
    T-13472        Fixed several problems where scheduled Appraisal messages were not sent at the right times
    T-14135        Fixed paging when adding items to a learning plan
    T-14158        Fixed the display of Facetoface sessions spanning several days on the calendar

                   Thanks to Eugene Venter at Catalyst for contributing to this

    T-14023        Fixed expansion of the Totara menu when using Standard Totara Responsive theme on small screens
    T-14098        Fixed visibility of hidden/disabled Certifications and Programs in Audience Enrolled Learning
    T-13984        Fixed editing/deleting of blocks when viewing a Choice activity module

                   Thanks to Ben Lobo at Kineo for contributing to this

    T-13962        Fixed error on site settings page after upgrading to Totara 2.7 from Moodle 2.7
    T-13964        Fixed issue with sending appraisal messages to unassigned roles
    T-14046        Fixed the redirection behaviour of custom menu management pages
    T-14021        Fixed the default title of the Mentees block
    T-14125        Fixed compatibility of iCal email attachments with some SMTP servers
    T-14074        Fixed theme precedence issues

                   Currently if you set a mobile theme in Site Administration > Appearance >
                   Themes > Theme Selector, the mobile theme will take precedence over any
                   user, course or category themes when viewing Totara on a mobile device.
                   This patch reverses this (so that User, Course and Category themes will
                   take precedence over a mobile theme).

                   If you wish to maintain the current (pre patch) behaviour add the line
                   "$CFG->themeorder = array('device', 'course', 'category', 'session',
                   'user', 'site');" to your config.php file

    T-13661        Fixed joinlist for the Assignment Submissions report source

                   When viewing the 'Assignment submissions' report source, no assignment
                   submissions were displayed unless they were either graded, or the
                   'Submission grade' column was removed from the report.

    T-14101        Fixed uppercase column names in Facetoface enrolment plugin

                   Can cause database query errors on MSSQL installations using case sensitive
                   collations


Release 2.7.0 (2nd March 2015):
==================================================

New features:
    T-10087  Added new editing and configuration interface for the main menu
    T-11033  Added new badge report source
    T-11185  Added new dynamic Appraisals advanced feature
    T-12199  Added new audience based visibility setting for courses, programs and certifications
    T-12325  Added new course completion date filter for the Record Of Learning all courses report
    T-12772  Added new aggregation and grouping column options in Reportbuilder reports
    T-12892  Added new cut off date and minimum capacity options for Facetoface sessions
    T-12900  Added new self approval feature for Facetoface sessions
    T-12902  Added new feature to allow users to register their interest in a Facetoface session they cannot sign up for
    T-13092  Added new Facetoface course enrolment plugin added to Totara
    T-13093  Added direct enrolment into Facetoface sessions from the enhanced catalog interface
    T-13114  Added feature to allow users to select a position when signing up for a Facetoface session
    T-13195  Added new autowaitlist and signup lottery in Facetoface
    T-13393  Added new setting to log user out of all sessions when their password is changed
    T-13407  Added new page to view all of a user's active sessions
    T-13468  Added new site log report source
    T-13502  Added graphical reporting to Reportbuilder
    T-13510  Added new upgrade log report source
    T-13514  Added new feature to reset main menu to defaults
    T-13693  Added completion status columns to the course completion report source
    T-13713  Added 'is completed', 'is in progress', and 'is not yet started' columns to programs and certifications report sources
    T-13714  Added new percentage aggregation option in Reportbuilder
    T-13715  Added new options to control the audience visibility of main menu items
    T-13718  Added custom fields to Facetoface sessions, signups and cancellations
    T-13721  Added ability to use user placeholders in main menu URLs
    T-13732  Added new audience based dashboards
    T-13765  Added new aggregated question types to Appraisals
    T-14081  Added MySQL configuration checks to the environment page

General improvements:
    T-9537   Added the ability to include children when filtering course categories in Reportbuilder
    T-9800   Improved the including of JS required by Reportbuilder filters
    T-11043  Improved handling when appraisee is missing roles involved in an Appraisal
    T-12309  Added link to the secure page layout in the element library
    T-12344  Improved use of forms when adding links to the Quicklinks block
    T-12388  Improved message when no results are returned for a program search
    T-12450  Added ability to control whether Facetoface session cancellation is available to learners
    T-12586  Removed totara-expanded-width class applied via JS
    T-12592  Fixed database schemas between installed sites and upgraded sites
    T-12662  Renamed Totara Sync to HR Import
    T-12712  Improved number of content types that can be created by the Test Site Generator
    T-12927  Added a new option to hide records between two dates in Reportbuilder date filters
    T-12929  Allowed more user profile fields to be used in Facetoface notifications via substitution
    T-13104  Changed Facetoface session duration to be stored in seconds instead of minutes
    T-13221  Added visibility controls to Appraisal redisplay questions
    T-13303  Introduced rb_display_nice_datetime_in_timezone method to complete timezone function suite
    T-13335  Improved main menu JS dependencies
    T-13338  Removed Recaptcha login protection in lieu of the new user lockout support
    T-13363  Upgraded Totara cron tasks to scheduled tasks
    T-13370  Changed Fusion Reportbuilder export to be longer enabled by default
    T-13383  Prevented admin redirection to enrolment page after course creation
    T-13408  Improved flexibility of which courses need to be completed to complete a Program courseset
    T-13526  Added a debug option to embedded reports
    T-13527  Added new Reportbuilder nice_date column format for displaying date information
    T-13575  Converted set_time_limit calls to use core_php_time_limit::raise instead
    T-13604  Improved handling of Totara user events to match Moodle behaviour
    T-13605  Added support for Totara-specific post upgrade steps
    T-13608  Added display of Standard Totara footer on popup pages
    T-13615  Added performance improvements for bulk user enrolments and role assignments
    T-13643  Removed W3C deprecated HTML tags
    T-13690  Added ability to specify password rotation as part of the password policy
    T-13716  Added ability to prevent cancellations within a certain time of a Facetoface session date
    T-13762  Fixed Reportbuilder file exports to now use parent folder permissions.
    T-13789  Removed unused function prog_get_all_users_programs
    T-13838  Added ability to withdraw from pending enrolments within the enhanced catalogue
    T-13980  Increased maximum database table name length
    T-14053  Improved timezone handling across the entire codebase

Accessibility and usability improvements:
    T-11919  Cleaned up nested HTML tables in toolbars
    T-12013  Improved the display of links in the Kiwifruit Responsive theme
    T-12332  Fixed current item in the navbar being incorrectly shown as a link
    T-12333  Added headings to many pages where there was no heading
    T-12334  Improved contrast of help icons
    T-12340  Converted labels with no associated input to more appropriate elements
    T-12350  Added a heading to the delete Learning Plan page
    T-12354  Added a heading to the form used to create a Learning Plan
    T-12356  Improved alt text for the date selector
    T-12358  Improved title attribute on the tab name when editing a Learning Plan
    T-12359  Increased contrast of notification messages for usability
    T-12367  Fixed positioning of the Save and Cancel buttons in hierarchy dialogues
    T-12374  Fixed multiple h1 elements on the my reports page
    T-12380  Added a heading to the delete scheduled report page
    T-12389  Removed incorrect fieldset HTML elements on Program content tab
    T-12390  Added missing title to the launch course column when viewing an assigned Program
    T-12398  Changed display of ical image to text, and increased the contrast, when viewing the calendar
    T-12415  Converted calendar export to use mforms
    T-12418  Added a heading to the file upload dialogue
    T-12423  Fixed keyboard navigation on user positions page
    T-12424  Fixed the labels for start and end date on the user positions pages
    T-12685  Converted add new user link to a button on the browse users page
    T-13011  Removed HTML tables from Message alerts
    T-13016  Cleaned up nested HTML tables in the alerts report
    T-13702  Converted to mforms date selector when creating Learning Plans
    T-13076  Converted to mforms date selector when creating new Audiences
    T-13089  Converted to mforms date selector when creating and editing Programs
    T-13304  Improved display of instant filtering in Reportbuilder
    T-13360  Improved the display markup of the users current session in a Facetoface module
    T-13362  Removed nested HTML tables in Facetoface events
    T-13369  Improved Facetoface block session filter HTML
    T-13515  Improved HTML layout of calendar filters in Facetoface block
    T-13609  Improved HTML layout when viewing messages
    T-13614  Improved HTML layout when viewing course groups
    T-13705  Fixed positioning of cancel and save buttons
    T-13728  Improved heading hierarchy on required learning pages
    T-13741  Improved HTML layout of web services documentation
    T-13791  Removed HTML table when viewing another user's Required Learning
    T-13804  Added a label to all duration based admin settings
    T-13949  Improved the alt text on images in the statistics block
    T-13999  Added missing labels to time selectors in admin settings

Feature details
===============

== Main menu customisations (T-10087, T-13514, T-13715, T-13721) ==
The following improvements have been made to the main menu:
1. It is now possible to customise the main menu by adding and removing your own items.
   Existing items cannot at present be deleted, as they may be relied upon for navigation.
2. The placement (sorting) of all items in the menu can be customised to your liking.
3. The visibility of all menu items can be controlled. You can both mark an item either hidden/visible or you can configure
   rules to determine the visibility at the time the page is displayed for the current user.
4. User placeholders can be used in the URLs of custom menu items. These get replaced at run time with the data of the current user.
5. At any point the customised main menu can be reset, returning it to the default state.

== Dynamic appraisals (T-11185) ==
This feature consists of two main changes:
1. When a user is added or removed from a group (position/organisation/audience) that is assigned to an active appraisal, the
   appraisals assignments will mirror this change, assigning or removing the user from the appraisal instead of the assignments
   being locked on the appraisal's activation.
2. When a user's role (manager/teamlead/appraiser) is changed or deleted mid-appraisal the change will be mirrored in the appraisal
   roles instead of locked on the appraisals activation.

Upgraded sites will have to enable this feature by ticking the "Dynamic Appraisals" checkbox on the "Advanced features" site
administration page. It is enabled by default for new installations.

A more detailed description of the changes can be found here: https://community.totaralms.com/mod/forum/discuss.php?d=9563

== New aggregation and grouping column options in Reportbuilder reports (T-12772) ==
This new feature allows administrators to create new reports that aggregate rows using different functions.
There are also new configurable display options.
Developers need to update 3rd party reports to include data types for each column, otherwise the new display and aggregation options
will not be available in report configuration interface.

== Facetoface course enrolment plugin (T-13092) ==
The plugin is disabled by default. When enabled it can be added to any course as an enrolment instance.
Users not already enrolled in the course may then enrol in a Facetoface session within the course and as part of the process an
enrolment record will be created and they will be given access to the course.

== Facetoface custom fields (T-13718, T-11744) ==
Its now possible to add custom fields to three places in the Facetoface module.
There are significant changes to the session, signup and cancellation screens in order to accommodate these changes.
The following areas now custom fields:
* Sessions - included when adding and editing sessions. Shown on the session signup page.
* Signups - included when the user signs up to a sessions. Shown when viewing the attendees and in the Facetoface session report.
* Cancellations - including when cancelling a signup to a session. Shown when viewing cancellations and in the Facetoface session
  report.

== T-13732  Audience based dashboards ==
Administrators can now create audience based dashboards.
These dashboards operate just like the My Learning page in that a default can be created and then each user in the assigned
audiences can customise their dashboard to suit their needs.
As many dashboards can be created as desired.
The default home page for a Totara site can now be set to a dashboard and users can also be given the option of choosing a particular
dashboard as their home page.

Database schema changes
=======================

New tables:

Bug ID   New table name
-----------------------------
T-10087  totara_navigation
T-11185  appraisal_role_changes
T-12902  facetoface_interest
T-13092  enrol_totara_f2f_pending
T-13502  report_builder_graph
T-13715  totara_navigation_settings
T-13718  facetoface_session_info_field
T-13718  facetoface_session_info_data
T-13718  facetoface_session_info_data_param
T-13718  facetoface_signup_info_field
T-13718  facetoface_signup_info_data
T-13718  facetoface_signup_info_data_param
T-13718  facetoface_cancellation_info_field
T-13718  facetoface_cancellation_info_data
T-13718  facetoface_cancellation_info_data_param

New fields:

Bug ID   Table name                New field name
------------------------------------------------------------
T-11185  appraisal_user_assignment status
T-11185  appraisal_role_assignment timecreated
T-12772  report_builder_columns    transform
T-12772  report_builder_columns    aggregate
T-12772  report_builder_cache      queryhash
T-12892  facetoface_sessions       mincapacity
T-12892  facetoface_sessions       cutoff
T-12900  facetoface_sessions       selfapproval
T-12900  facetoface                selfapprovaltandc
T-12902  facetoface                declareinterest
T-12902  facetoface                interestonlyiffull
T-13195  facetoface_sessions       waitlisteveryone
T-13502  report_builder            timemodified
T-13502  report_builder_saved      timemodified
T-13715  totara_navigation         visibilityold
T-12450  facetoface                allowcancellationsdefault
T-12450  facetoface_sessions       allowcancellations
T-13408  prog_courseset            mincourses
T-13408  prog_courseset            coursesumfield
T-13408  prog_courseset            coursesumfieldtotal
T-13716  facetoface                cancellationscutoffdefault
T-13716  facetoface_sessions       cancellationcutoff

Modified fields:

Bug ID   Table name                Field name
--------------------------------------------------------
T-13718  facetoface_notice_data    data     Changed to text

Dropped tables:

Bug ID   Table name
-------------------------
T-13718  facetoface_session_field
T-13718  facetoface_session_data

Dropped fields:

Bug ID   Table name                Field name
--------------------------------------------------------
T-12772  report_builder_cache      config
T-12772  report_builder_settings   cached value


API changes
===========

== T-9800 Reportbuilder filters can now include the JS they require ==
* Newly introduce rb_filter_type::include_js allows filters to include any JS they require.

== T-11185  New dynamic appraisals advanced feature ==
* totara_assign_core::store_user_assignments - two new optional arguments $newusers (arg 1) and $processor (arg 2), both default to
  null.
* totara_assign_core::get_current_users - new argument $forcegroup (arg 4)
* totara_setup_assigndialogs - one new optional argument (arg 1) The html output of a notice to display on change
* totara_appraisal_renderer::confirm_appraisal_activation - new argument $warnings (arg 1)

== T-12199     New audience based visibility setting for courses, programs and certifications ==
* totara_visibility_where - new optional argument $fieldvisible (arg 3) defaults to course.id.
* rb_base_source::add_course_table_to_joinlist - new optional argument $jointype (arg 4) defaults to LEFT

== T-13104  Facetoface session duration is now stored in seconds instead of minutes ==
* Facetoface_sessions.duration is now stored in seconds instead of in minutes.

== T-13221  Added visibility controls to Appraisal redisplay questions ==
* New method question_base::inherits_permissions; classes extending question_base can now optionally override inherits_permissions
  and return true if the question class should inherit its permissions from another question.
  Initially used for the redisplay question type as it should inherit its permissions from the earlier question it is displaying.

== T-13303  Introduced rb_display_nice_datetime_in_timezone method to complete timezone function suite ==
* new rb_base_source::rb_display_nice_datetime_in_timezone method

== T-13338  Recaptcha login protection has been removed in lieu of the new user lockout support ==
* login_forgot_password_form::captcha_enabled method has been removed. It is no longer used.

== T-13363  Upgraded Totara cron tasks to scheduled tasks ==
The following functions have been removed:
* registration_cron
* totara_core_cron
* block_totara_stats::cron method has been removed.
* reminder_cron
* facetoface_cron
* totara_appraisal_cron
* totara_certification_cron
* tcohort_cron
* totara_cohort_cron
* totara_hierarchy_cron
* totara_message_install
* totara_message_cron
* totara_plan_cron
* totara_program_cron
* totara_reportbuilder_cron

The following files have been removed. If you have cron set up to call any of these you will need to update your cron configuration.
* admin/tool/totara_sync/run_cron.php
* totara/appraisal/cron.php
* totara/appraisal/runcron.php
* totara/certification/cron.php
* totara/cohort/cron.php
* totara/hierarchy/prefix/competency/cron.php
* totara/hierarchy/prefix/goal/cron.php
* totara/message/cron.php
* totara/plan/cron.php
* totara/program/cron.php
* totara/reportbuilder/cron.php
* totara/reportbuilder/runcron.php

== T-13393  New setting to log user out of all sessions when their password is changed ==
* \core\session\manager::kill_user_sessions - new optional argument $keepsid (arg 2) keep the given session id alive. If not
 * provided all sessions belonging to the user will be ended.

== T-13502  Implement graphical reporting in Reportbuilder ==
It is now possible to add graphs to reports. The graphs from each report may be also displayed as page blocks.
Developers need to update 3rd party reports to include date types for each numerical column, otherwise the columns will not be
available when setting up graphs in reportbuidler interface.

== T-13527  Implemented report build date column format ==
This change introduces a new nice date list display class and removes remaining uses of the deprecated rb_display_nice_date function.

== T-13605  added support for Totara specific post upgrade steps ==
It is now possible to define Totara specific post upgrade steps.
These steps should be defined within db/totara_postupgrade.php.
A single method should exist within this file xmldb_pluginname_totara_postupgrade.

== T-13714  New percentage aggregation option in the Reportbuilder ==
* New \totara_reportbuilder\rb\aggregate\percent and \totara_reportbuilder\rb\display\percent classes.
* New boolean datatype for report source columns. Existing columns have been converted where required.
* rb_base_source::rb_display_percent function removed as we have now got dedicated type, aggregate and display for percentages.

== T-13721  User placeholders can now be used in main menu URL's ==
* \totara_core\totara\menu\item::get_url - new optional argument $replaceparams (arg 1) when true (default) params in the URL will
  be replaced with relevant data.

== T-13604  Cleanup Totara user events ==
* \totara_core\event\user_firstlogin was removed, use standard \core\event\user_loggedin
  event instead, in case of first login $USER->firstaccess and $USER->currentlogin are equal.

== T-13604  Cleanup Totara user events ==
* \totara_core\event\user_enrolment was removed, use standard \core\event\user_enrolment_created
  event instead

== T-13711  Non numeric columns are no longer shown as graph data sources in Reportbuilder ==
* rb_base_source::get_used_components - new method that should be overridden to return an array of frankenstyle components used by
  the current source and all parents.
* totara_reportbuilder\rb\aggregate\base::is_graphable - new method that should be overridden by all aggregate classes and should
  return true if the given column can be graphed or false otherwise. By default it runs null and Reportbuilder will guess.
* totara_reportbuilder\rb\display\base::is_graphable - new method that should be overridden by all display classes and should return
  true if the given column can be graphed or false otherwise. By default it runs null and Reportbuilder will guess.
* totara_reportbuilder\rb\transform\base::is_graphable - new method that should be overridden by all transform classes and should
  return true if the given column can be graphed or false otherwise. By default it runs null and Reportbuilder will guess.
* New column option “graphable” can be set to true if the column being defined is graphable.

== T-13789  Remove unused function prog_get_all_users_programs ==
* prog_get_all_users_programs function was removed.

== T-13980  Increase maximum database table name length ==
This change increases the maximum database table name length from 28 to 40.
This facilitates better table naming in Totara.

Other notable changes
=====================

T-12772  Imported SVGGraph 2.16 third party library into Totara
T-13092  New enrol_totara_facetoface plugin added to Totara.
T-13407  New report_usersessions plugin added to Totara.
T-13732  New Totara component totara_dashboard
T-13732  New block_totara_dashboard plugin added to Totara.
T-14081  We strongly advise anyone not already using InnoDB or XtraDB to convert to one of these.
T-14081  InnoDB should be configured to use the Barracuda file format and to use one file per table.

*/
