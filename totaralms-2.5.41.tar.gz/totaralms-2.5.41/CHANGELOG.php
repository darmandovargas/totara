<?php
/*

Totara LMS Changelog

Release 2.5.41 (26th July 2016):
================================


Security issues:

    TL-9340        Fixed access control when deleting calendar subscriptions

                   Users can only delete their own calendar subscriptions.
                   Previously it was possible to craft a special request that would allow you
                   to delete a calendar subscription regardless of whether you were the owner
                   or not.
                   The moodle/calendar:manageownentries capability is now consistently
                   checked.

    TL-9400        Fixed access control when deleting personal goals

                   A user's personal goals can only be deleted if one of the following
                   conditions is true for the current user:

                   1. They have the totara/hierarchy:managegoalassignments capability in the
                   system context.
                   2. They are a manager of the goal's owner and they have the
                   totara/hierarchy:managestaffpersonalgoal capability in the users context.
                   3. It is one of their own personal goals and they have the
                   totara/hierarchy:manageownpersonalgoal capability in the system context.

                   Previously it was possible to craft a special request that would allow you
                   to delete any personal goal, regardless of whether it was one of your
                   personal goals or not.
                   The relevant capability checks are now consistently applied.

    TL-9515        Fixed sanitisation of user's firstname and lastname when sending emails

                   Totara was not previously sanitising the users firstname and lastname
                   correct when compiling emails to the user.
                   An authenticated user could therefor alter their firstname or lastname in
                   Totara to contain invalid content including additional email addresses.
                   As their firstname and lastname was not being correctly sanitised this
                   could be abused to send spam to others.
                   The users firstname and lastname is now properly sanitised.

                   References MDL-55069

Improvements:

    TL-9221        Added the ability to resolve dismissed program exceptions to the completion editor

                   The Program and Certification completion editors now display information
                   about dismissed program exceptions when viewing a user's completion data,
                   and allow dismissed exceptions to be overridden.

Bug fixes:

    TL-9392        Available courses on the front page are no longer duplicated when the user is not enrolled in any courses

                   If the front page had been configured to display a list of Enrolled Courses
                   and the user was not enrolled on any courses then a list of available
                   courses would be displayed in stead.
                   Previously if you had also configured the front page to contain a list of
                   available courses this would then lead to the list of available courses
                   being displayed twice.
                   Now when the front page has been configured to display a list of available
                   courses and enrolled courses, when the user is not enrolled on courses then
                   nothing is printed.
                   This stops the list of available courses from being printed twice.

    TL-9453        Prevented the adding of a Program to a Learning Plan from resetting Program status

                   When a program was already assigned to a user, if the same program was then
                   added to the user's learning plan, the status of the program was reset. The
                   program would likely be re-marked completed by cron, but only if the course
                   requirements were unchanged and the courses involved were still marked
                   complete.
                   Additionally, dates related to the program may have changed.
                   This fix prevents changes when adding a program to a learning plan if the
                   user is already assigned to the program.

    TL-9466        Fixed notice when sending registration information via cron when executed from the command line


Release 2.5.40 (14th June 2016):
================================


Improvements:

    TL-9233        Allow the use of mariadb in config.php in all branches


Bug fixes:

    TL-8874        Face-to-face booking confirmation notification no longer ignores the "Manager copy" setting

                   Prior to this change the booking confirmation notification would be sent to
                   the attendees manager even if the "Manager copy" setting was turned off.
                   The booking confirmation notification now correctly checks this setting.

    TL-9248        Brackets are now correctly escaped during like searches when using MSSQL

                   Previously during like search operation brackets "[" and "]" were not being
                   correctly escaped, which could on occasion lead to incorrect results.
                   This was not exploitable but could easily have made searching difficult for
                   some MSSQL sites.


Release 2.5.39 (23rd May 2016):
===============================


Important:

    TL-7818        Changed certification window opening to also reset RPL activities

                   Previously, when the recertification window opened, RPL course completions
                   were being reset, but RPL activity completions were not. This could cause
                   the situation where a course would re-complete due the RPL activity
                   completions, which in turn triggered certification completion. Depending on
                   certification settings, this could cause a repeating loop. Now, like
                   courses, RPL activity completions will also be reset when the
                   recertification window opens.

                   This change in behaviour brings Totara 2.5, 2.6 and 2.7 in line with 2.9
                   (which has had this change since 2.9.0).

    TL-8973        Activity completions will now always reset on archive regardless of their visibility

                   When activity completions were archived during a certification window
                   opening, the completions for activities set to hidden were ignored and
                   would be retained. Activity completions are now archived regardless of
                   their visibility.

                   This patch also fixes an issue where Face-to-face completion data was not
                   being fully reset if the completion time of the Face-to-face activity was
                   changed to a later time.

                   This change means that after the archive_course_activities function is run,
                   any activities that should not be complete will have no record in the
                   course_modules_completion table, rather than have one which is set to
                   incomplete.

                   As well as affecting certification window opening, these changes will also
                   apply when using the archive completions function within a course.


Security issues:

    TL-8615        Added noreferred attribute to links set to open in a new tab or window

                   This is a backport of MDL-52651 to Totara 2.5.39, and 2.6.32

    TL-9008        Fixed an exploit with the window opened when working with SCORMS in new windows

                   This is a backport of MDL-53546 to Totara 2.2.47, 2.4.41, 2.5.39, and
                   2.6.32

    TL-9009        Added a missing sesskey check to forum/markposts.php

                   This is a backport of MDL-53755 to Totara 2.2.47, 2.4.41, 2.5.39, and
                   2.6.32

    TL-9010        Fixed capability checks when viewing a user's badges

                   This is a backport of MDL-53589 to Totara 2.4.41, 2.5.39, and 2.6.32

    TL-9057        Added sesskey checks when applying automatic fixes on the check completions page in the Program completion editor


Improvements:

    TL-7993        Removed the obsolete 'Manager emails' settings from Face-to-face
    TL-8866        Increase the max year in date pickers to 2037

                   Due to the Year 2038 bug we can only increase this to 2037 in 2.5. See
                   https://en.wikipedia.org/wiki/Year_2038_problem for details on this issue.

    TL-9020        Created initial Program and Certification completion transaction logs

                   If a user assigned to a Program or Certification did not have any
                   transaction logs, a snapshot log record will be created during upgrade.
                   Likewise, a certification settings snapshot will be created if none exists.
                   This will help with diagnosing future problems.

    TL-9022        Added confirmation when applying automated fixes to program completions

                   When using the program or certification completion checker or editor, when
                   you activate one of the fixes, you will now need to confirm the action.
                   This is to prevent accidental clicks, and provides additional warnings.


Bug fixes:

    TL-8605        Fixed certification completon records affected by the reassignment bug

                   Patch TL-6790 in the March release of Totara changed the behaviour when
                   re-assigning users onto a certification. This patch repairs certification
                   completion records for users who were, before that patch, re-assigned and
                   ended up being unable to certify. All users which are identified by the
                   completion checker as "Program status should be 'Program incomplete' when
                   user is newly assigned. Program completion date should be empty when user
                   is newly assigned.", and have an "unassigned" historical completion record,
                   will have that historical record restored, as is the current behaviour when
                   reassigning users. Any records which do not meet these specific criteria,
                   or would be in an invalid state if the change was applied, will not be
                   affected and must be processed manually.

    TL-8753        Added an automatic fix for mismatched program and certification completion dates

                   The program completion date should match the certification completion date
                   when a user's certification is "Certified, before the window opens". To
                   repair records where the date is incorrect, this patch added an automated
                   fix which can be triggered to copy the certification completion date to the
                   program completion date. Relates to TL-9014.

    TL-8764        Deleted orphaned course reminders for deleted courses
    TL-8872        Fixed the ordering of the transaction logs in program and certification completion editors
    TL-8991        Fixed the wrong date being used to calculate the certification completion date

                   If a certification had a course set with more than one course, where not
                   all of the courses were required for completion. And before being assigned
                   to the certification, a user completed (manually or via course completion
                   upload) enough of the courses to complete the course set. The certification
                   completion date was being incorrectly calculated as the latest date of all
                   completed courses, rather than the maximum course set completion date. This
                   patch corrects this, and provides an automated fix (part of the
                   Certification completion editor) to repair any affected records.

    TL-9005        Fixed program enrolment messages not being sent

                   When users were becoming assigned to a program or certification due to
                   "first login" or "indirect" assignment (some action which was not manually
                   performed in the Assignments interface, such as when a user becomes a
                   member of an audience which is already assigned to a program), they were
                   not receiving any configured program enrolment messages. This has been
                   fixed. This patch does not retroactively send program/certification
                   enrolment messages that were missed.


Release 2.5.38 (20th April 2016):
=================================


Improvements:

    TL-8393        Performance improvement when admins view a course with many activities

                   Previously, when an admin viewed a course, the admin's completion data for
                   each course would be checked for each activity multiple times. The higher
                   the number of activities in a course, the more often these completion
                   checks would occur, causing performance issues when there were many
                   activities involved. This only affected users who could access the course
                   but were not enrolled, such as site administrators. Enrolled users were not
                   affected by this bug. Guest users were also not affected as completion data
                   is not checked for them.

                   The issue occurred due to cached data being cleared incorrectly for the
                   affected users. This has been corrected and page load times for admins on
                   the view course page will now be similar to that of enrolled learners.

    TL-8751        Added links to run completion checker over whole site

                   Links were added in Manage Programs and Manage Certifications which allow
                   privileged users to run the program and certification completion checkers
                   over all programs or certifications on a site, rather than having to run
                   them one program or certification at a time.


Bug fixes:

    TL-8374        Ensured the certification completion date is only calculated on the current paths courses
    TL-8438        Added a missing string used within the Program membership report


Release 2.5.37 (23rd March 2016):
=================================


Important:

    TL-6790        Changed the default behaviour of certification reassignment

                   Previously a user who was unassigned and reassigned to a certification
                   would be placed back into their initial certification path. Depending on
                   their current course completions, their status may have been reaggregated
                   on the next cron run. Now the system will look for the latest unassigned
                   certification completion history record and the user will be restored to
                   their previous status instead. Any events that need to occur (such as
                   window opening) will take place when the relevant scheduled task runs (e.g.
                   update_certification_task).


Security issues:

    TL-8614        Prevented reflected XSS vulnerability in mod_data advanced search
    TL-8616        Fixed access control in ajax script returning navigation branches
    TL-8617        Fixed external function get_calendar_events to not return events for hidden activities
    TL-8619        Added session check to assignment plugins management


Bug fixes:

    TL-8367        Fixed visiblity of hidden courses on the My Bookings page
    TL-8444        Fixed Program and Certification Membership reports for MSSQL


Release 2.5.36 (22nd February 2016):
====================================


Important:

    TL-8347        Fixed dynamic audience rules that reference an organisation menu type custom field

                   This patch is a backport of TL-7896, which was recently included in Totara
                   2.6 and above.

                   Dynamic audience rules for Organisation menu custom fields can have one of
                   two operators, "Equal to" and "Not equal to".
                   Prior to this fix these operators functioned in reverse. "Equal to" would
                   lead to users within an organisation for which the custom field did NOT
                   include the selected options.
                   Likewise if "Not equal to" was used users within organisations for which
                   the selected value was used would be included as audience members.
                   After this fix the operators are applied correctly.

                   If you have dynamic audiences with rules based upon organisation menu
                   custom fields then we strongly recommend you review these dynamic audience
                   rules and the associated audience memberships.
                   During upgrade these rules will be corrected and audience memberships may
                   change.
                   If you have affected audiences, you can fix them without incurring
                   membership changes by following these steps:

                   1. Disable cron prior to your upgrade.
                   2. Upgrade your site.
                   3. Review the dynamic audiences that are affected. If you need memberships
                   to stay exactly the same then changing the condition on the rule from
                   "Equals to" to "Not equals to" (or vice-versa) will ensure that audience
                   memberships stay as they were prior to this version.
                   4. Approve your changes and review the audience memberships.
                   5. Re-enable and run the cron.


Security issues:

    TL-8392        Fixed handling of non-numeric answers to numeric feedback activity questions


Improvements:

    TL-7970        Added the program and certification completion editor

                   Enabled with Site administration -> Advanced features -> Enable program
                   completion editor. Only users with the 'totara/program:editcompletion'
                   capability (site admins only, by default) will be able to access the new
                   tab 'Completion' when editing a program or certification. For more
                   information, see the community post:
                   https://community.totaralms.com/mod/forum/discuss.php?d=11040.


Bug fixes:

    TL-6593        Fixed course completion status not updating when changing completion criteria

                   Users were not being marked "In progress" when the were assessed against
                   the new completion criteria.

    TL-8078        Completion progress details page was reworded to more accurately indicate the status

                   Previously, the course status in the Completion progress details page
                   (accessed by clicking the "Progress" bar in Record of Learning: Courses or
                   "More details" in the Completion status block) would show "Not started"
                   even though the learner had actually viewed and completed a SCORM lesson.
                   Moreover, the SCORM activity status would be "Viewed the scorm, Achieved
                   grade" even though the learner had not achieved the grade to complete the
                   activity. These were fixed in this patch. Course status is now "incomplete"
                   as long as its activities are not complete and the activity status
                   correctly indicates the learner failed to achieve the required grade.

    TL-8226        Fixed an issue with the course completion scheduled task

                   There was a problem in the completion cron when a user had completed an
                   activity but hadn't had the module completion record written into the
                   database. The criteria review would call get_info() which now updates the
                   state, creating the module completion record. However the initial review
                   would then continue and due to a dataobject lacking the now existing record
                   it would try to write the record again, causing a conflict. The dataobject
                   is now created after the get_info() call, avoiding this issue.

    TL-8253        Fixed a bug which occured in some situations when deleting audiences without members

                   Prior to this fix, if you attempted to delete an audience which had a role
                   assignment associated with it, but not members, you would receive a fatal
                   error. This has now been fixed and the audience is correctly deleted.

    TL-8391        Fixed reportbuilder sorting and pagination when Restrict initial display is enabled


Contributions:

    * Jo from Kineo - TL-8392


Release 2.5.35 (18th January 2016):
==================================================


Important:

    TL-8047        Fixed a bug found within SQL search routines used by both dialog searches and dynamic audience rules.

                   Prior to this fix if you had a dynamic audience with two or more rules in a
                   single ruleset, where the rules have comma separated values specified in
                   conjunction with any of the following conditions "Contains", "Is equal to",
                   "Starts with", "Ends with" then membership may be incorrect.
                   The bug is due to multiple value search SQL not being correctly wrapped in
                   brackets.

                   After this fix comma separated values are correctly applied when
                   determining dynamic audience membership.

                   Depending upon the order of the rules and how they apply to the users
                   currently in the audience, membership may or may not change.
                   If you have an audience you believe is affected we strongly urge that you
                   first test this version on a copy of your site and after upgrading, closely
                   review audience membership.
                   You will need to review and amend the audience rules if users are removed
                   and you require them to still be included.

                   This bug may also have affected dialog searches when multiple values were
                   being used. Searching in dialogs now correctly handles multiple search
                   values.


Improvements:

    TL-8166        Added a new column 'Course Completions as Evidence' to the My Team embedded report


Bug fixes:

    TL-7012        Fixed the course completion progress bar for courses within a completed learning plan

                   The course completion progress bar was not being correctly displayed in the
                   Record of Learning for course that are part of an already completed
                   learning plan

    TL-7826        Course completions stats on the My Team report now include RPL completions

                   Switched the Course Completion statistics on the My Team embedded report to
                   use course_completion records instead of block_totara_stats.


    TL-8135        Fixed the risk displayed for the totara/program:markstaffcoursecomplete capability
    TL-8231        Switched the Face-to-face edit attendees from sending GET params to POST params

                   Prior to this change when editing the attendees of a Face-to-face session
                   the dialog would submit any changes made as GET params.
                   If the session had hundreds or thousands of attendees this could lead to an
                   exceptionally long URL.
                   The length of the URL may then cause problems on some systems, particularly
                   IIS and any site running Suhosin.


Release 2.5.34 (14th December 2015):
====================================


Security issues:

    TL-7975        Added read/write access controls to group assignment code throughout Totara
    TL-8076        Prevented access to external blog pages when either blogs or external blogs are disabled


Bug fixes:

    TL-7426        Fixed the course completion status of users after their RPL is deleted

                   Previously their completion would not be re-aggregated until they made
                   further progress in the course, now it is re-aggregated immediately.

    TL-7842        Fixed stuck certification completions due to a bug previously fixed in TL-6979

                   Certifications which experienced the problem which was fixed in TL-6979
                   would be stuck after upgrading. This patch will repair those records by
                   triggering the window open event again. The records will be in the correct
                   state after installing the upgrade and then running the hourly
                   certifications cron job.

    TL-7879        Stopped Program un-enrolment messages being sent to suspended users
    TL-7911        Fixed the restoration of certificate user information on different sites
    TL-7976        Fixed an issue with exporting reports to PDF (portrait) on some systems
    TL-7997        Fixed the shortname field for Goal types
    TL-8032        Fixed the display of the completion status for deleted users in Record of Learning reports


Contributions:

    * Jo Jones at Kineo UK - TL-7976
    * Pavel Tsakalidis at Kineo UK - TL-7975
    * Tim Price at Catalyst Australia - TL-7911


Release 2.5.33.1 (9th December 2015):
=====================================


Bug fixes:

    TL-8096        Fixed course module completion calculation

                   This fixes a regression introduced by TL-6981 in 2.9.1, 2.7.9, 2.6.26, and
                   2.5.33 in which the calculation of course module completion would lead to
                   all activities being marked complete incorrectly for a user.
                   The problem occurs when the user completes the first activity in the
                   course. It occurs if the user manually marks themselves complete, achieves
                   the completion criteria (with the exception of "Student must view this
                   activity to complete it"), or is marked complete by a trainer. The user
                   must then log out and log back in again in order to see the problem.
                   The problem will not occur if it is not the first activity in the course.
                   When this occurs all activities in the course will be marked complete,
                   regardless of which section or order they are within the course and
                   regardless of whether they are required for course completion or not.



Release 2.5.33 (16th November 2015):
==================================================


Security issues:

    TL-7829        Removed reliance on url parameter for choosing table

                   The script for getting the positions and organisations to assign to a
                   program relied on a url parameter to choose which table to access. The
                   table is now chosen according to the type of hierarchy that the query is
                   for.

    TL-7853        Added missing sesskey protection to lesson module
    TL-7855        Fixed output escaping in survey activity
    TL-7856        Added sesskey check to hub registration
    TL-7857        Fixed input validation in choice activity
    TL-7858        Fixed availability changes in SCORM activity
    TL-7859        Respect view badges capability
    TL-7870        Backport password autofilling workaround in more areas
    TL-7886        Fixed access checks for the position assignment AJAX script


Improvements:

    TL-7183        Trigger updates to program user assignments when changing assignments via the audience Enrolled Learning tab

                   When you make a change in an audience's Enrolled Learning tab, it will
                   immediately trigger an update of program and certification user
                   assignments. If there are less than 200 total users involved in the program
                   then the users will be processed immediately, otherwise the update will be
                   deferred. By default, deferred program user assignments are processed the
                   next time cron runs. This patch makes the behaviour consistent with making
                   changes in a program's Assignments tab.

    TL-7529        Fixed handling of RPL records when resetting or deleting a course or its completions

                   This change fixes how RPL records are handled when a course is reset by a
                   certification, deleted or reset by a user, or course completions unlocked
                   by a teacher.

                   When deleting or resetting a course, RPL completions are now also deleted
                   correctly. Previously these were not removed. An upgrade step will safely
                   remove invalid data records for deleted courses.

                   When a user's course completion gets reset by a certification window opening, all
                   course RPL completions will be removed. Activity RPL completions will remain and
                   still count towards the next course and certification completion.

                   As before, when a teacher unlocks course completion criteria and selects to
                   delete, course and activity RPL records will be kept and still count
                   towards a users completion.

                   Contributed by Eugene Venter at Catalyst NZ

    TL-7737        Improve help text for Case insensitive shortnames option on Completion import page
    TL-7824        Moved program user assignment deferred flag reset to start of function

                   If changes are made to a program's assignments while the function is
                   running in cron, those changes will be processed the next time cron runs,
                   rather than having to wait until the nightly cron or another change is
                   made.

    TL-7869        Updated timezone file to 2015g


Bug fixes:

    TL-6957        Display correct due date value in the upcoming certifications block
    TL-6981        Reaggregate course completion when activity completion criteria are unlocked without deletion

                   Previously, course completion status was only reaggregated if "unlock with
                   delete" was used. If "unlock without delete" was used, it was possible that
                   users who meet the new completion criteria were not marked complete, and
                   this would not be fixed by any cron task. This could lead to users being
                   stuck with an incomplete status. Now, the records will be marked for
                   reaggregation and will be processed by the completion cron task.

    TL-7437        Switched the badges backpack URL to use HTTPS
    TL-7664        Fixed dynamic audience rules based upon checkbox position custom fields
    TL-7686        Fixed URL validation when adding new links to the quicklinks block
    TL-7691        Fixed the removal of individual assignments to company goals

                   When removing a user's individual assignment to a company goal, all user
                   assignments for that user-goal pair were being deleted. Group assignments
                   then regenerated the missing user assignments on the next cron, now only
                   the individual user assignment will be deleted.

    TL-7695        Re-aggregate when course completion criteria is changed without deletion

                   When changing course completion criteria, and unlocking without deleting
                   existing completion data, re-aggregation was not being performed. Now,
                   users who are assigned but not complete and match the new criteria will be
                   marked complete after cron re-aggregates them. To fix any users affected by
                   this problem, an upgrade script will mark all incomplete users in all
                   courses for re-aggregation, which will be performed by cron, and may take a
                   while to process on larger sites.

    TL-7833        Fixed cron failure when sending Face-to-face notifications

                   When scheduled Face-to-face notifications were being sent out, the cron
                   task would potentially fail if notifications were going to users who had
                   their session bookings approved by a manager. This has now been fixed,
                   notifications go out as normal, and cron is not disrupted.

    TL-7876        Stopped the incorrect archiving of facetoface sessions without dates

                   Previously if a user was waitlisted on a Face-to-face session which had no
                   dates set, in a Certification Course. When the user's recertification
                   window opened, the signup would be marked as archived, meaning it would no
                   longer count towards course completion.

    TL-7881        Recreate course completion records when activity criteria are reset with deletion

                   Course completion records for users who were not complete according to the
                   new criteria were not being recreated immediately. Although the records
                   were being created when the completion cron task was run or when a user's
                   status in the course changed, it was possible that some unexpected
                   behaviour could have occurred due to the missing records.

    TL-7921        Fixed regression with media playback when request_order="GPC" in PHP.ini


Contributions:

    * Eugene Venter at Catalyst NZ - TL-7529


Release 2.5.32 (20th October 2015):
==================================================


Security issues:

    TL-7138        Improved the cleaning of dynamically generated module names

                   Calling "required_param('module', PARAM_COMPONENT)" actually restricts the
                   allowable characters in a module name and the function returns an empty
                   string upon detecting an invalid module name. In the past, there was no
                   check if an empty string was indeed returned. Now, the code throws an
                   "invalid_parameter_exception" if the required_param() call returns an empty
                   string.

    TL-7152        Added workaround for known security issues with Flowplayer
    TL-7377        Fixed the capability moodle/cohort:view allowing a user to edit global audience settings


API changes:

    TL-7502        Embedding of Youtube content now uses the current Google API

                   This is a backport of MDL-50176. Google has switched off support for the
                   API Totara was previously using for Youtube.
                   The current API is now in place and being used for all embedded Youtube
                   content.


Bug fixes:

    TL-5730        Scheduled Face-to-face notifications are now only sent to users who were eligible at the time

                   Previously, if a notification was scheduled to be sent out a certain amount
                   of time prior to the start of the Face-to-face session, this notification
                   would also be sent to any new users who signed up after the scheduled time.
                   Now, even if cron is run much later, these notifications will only go to
                   users who were eligible to receive the notification at the time it was due
                   to be sent.
                   The condition still exists that they must currently be eligible. For
                   example, if a notification is to be sent to booked users only, and a booked
                   user cancels before the notification is sent out, that user will not
                   receive the notification.

    TL-6909        Fixed dynamic audience rules based upon checkbox organisation custom fields
    TL-7181        Fixed and restored recipients default values for Face-to-face automatic notifications if they were updated
    TL-7308        Fixed possible timeouts when activating appraisals and creating appraisal snapshots
    TL-7436        Fixed the editing of a user's position so that the description field is now saved the first time it is edited
    TL-7448        Prevented historical Face-to-face session completions from overriding more recent ones

                   There were a couple of problems with Face-to-face session completions. If
                   you marked attendance for a user in a recent session, then later marked
                   their attendance in an older session, then the older session date was being
                   used when calculating completion. This caused a problem when the course had
                   been reset as part of a certification, or when activity completion criteria
                   were unlocked and deleted.

    TL-7570        Fixed the display of Positions and Organisations within the administration block

                   Previously users with permission to view positions and organisations were
                   not always shown these items within the administration settings block.
                   These pages are now correctly shown to users who have permission to view
                   them.


Release 2.5.31 (22nd September 2015):
==================================================


Security issues:

    TL-7373        Fixed potential XSS through grouping description


Bug fixes:

    TL-4527        Corrected PHP syntax error when using Hierarchy bulk actions.
    TL-5822        Added a warning to pre-install environment checks if the max_input_vars setting is too low.
    TL-6195        Fixed duplicate messages being sent to managers by Face-to-face when the user has an invalid email address
    TL-6632        Fixed the generation of unique tokens within core libraries

                   There were several cases of uniqid being used to generate unique
                   identifiers or tokens.
                   These calls have now been improved to use a method that ensures a truly
                   unique identifier or token is generated.

    TL-6659        Refactored program assignment code

                   Refactored program assignment code to make it more efficient and easier to
                   maintain. It will also prevent sql problems, which could occur on some
                   systems with some configurations, when assigning large numbers of users to
                   programs and certifications (such as using an audience). Performance for
                   adding and removing users has been improved by about a factor of two, while
                   performance when reprocessing existing user assignments (happens during
                   nightly cron) has been significantly improved (from 3 database queries per
                   user assignment down to zero). This should greatly reduce problems
                   experienced with long nightly cron jobs on large sites.

    TL-6804        Fixed competencies in a learning plan showing linked courses even when the course was hidden
    TL-7039        Prevented Face-to-face from sending booking confirmations for past sessions

                   When turning off "Approval required" for a Face-to-face activity a booking
                   notification was being sent for sessions in the past. This is now
                   prevented.

    TL-7114        Show hidden programs to enrolled users in the Record of Learning

                   Several problems were fixed relating to course, program and
                   certification visibility, in relation to the normal and audience based
                   visibility settings. In some situations, the normal visibility setting was
                   being used when audience visibility was enabled. As a consequence, hidden
                   assigned programs will now be visible in the Record of Learning, bringing
                   them in line with courses and certifications. As before this patch, hidden
                   assigned courses will not be accessible, but hidden assigned programs and
                   certifications will be.

    TL-7191        Fixed a missing sesskey in ajax requests when creating a filter in report builder reports

                   The sesskey and relevant checks were missing in ajax requests involved in
                   adding some audience filters to the report builder.  These have now been
                   put in place.

    TL-7224        Fixed the display of Certificates where the "Print Date" depends on a deleted activity
    TL-7248        Reverted change causing an inability to see uploaded images in Internet Explorer
    TL-7265        Improved the layout of tabs when viewing a SCORM
    TL-7360        Consistently prevent suspended and deleted users from getting any emails


Contributions:

    * Andrew Hancox at Synergy Learning - TL-6195


Release 2.5.30 (18th August 2015):
==================================================


Security issues:

    TL-7157        Added a new workaround for password autocompletion issues in some modern browsers

                   This fix works around an issue whereby some modern browsers would
                   automatically fill any password field in any form with a users stored
                   password for the site.
                   This would only occur after the user had made the decision to save Totara
                   authentication credentials within the browser.
                   Previously implemented directives telling the browser to not automatically
                   fill in the field are now ignored.


Improvements:

    TL-6436        Added an option to reset notifications to default for Face-to-face notifications

                   Sites that have been upgraded through Totara 2.4 may have Face-to-face
                   activities that do not have the complete series of notifications a newly
                   created Face-to-face activity would have.
                   This improvement introduces a means of resetting the default notifications
                   allowing those sites that have Face-to-face activities with missing
                   notifications to reset the default notifications if they wish in order to
                   get them back.

    TL-7109        Changed audience strings to reflect what start and end dates actually do


Bug fixes:

    TL-5709        Prevent exceptions and changes to due date for completed programs

                   Once a user has completed a program, changes cannot be made to their due
                   date using the Assignments tab. A consequence is that new exceptions cannot
                   occur once a user has completed the program. Similarly for certifications,
                   time due changes will not be possible after the user first certifies (after
                   this point, either they are certified, in which case they are due on their
                   expiry date, or their certification has expired, in which case they are
                   overdue).

    TL-6512        Fixed course reminder escalation messages being sent for all historical course completions
    TL-6767        Fixed HR Import producing a fatal error if more than 65336 import errors were encountered
    TL-6908        Fixed the display of stage titles when exporting an Appraisal

                   When an Appraisal had a long stage title and either a short description or
                   no description at all the title would sometimes be cut off in the PDF that
                   was produced by the export.
                   This was affecting the interface and PDF snapshots.

    TL-7048        Fixed the sending of certification alerts so that suspended users are excluded
    TL-7085        Replaced a hardcoded "Participants" string in Appraisals with a translatable string
    TL-7102        Fixed the cancel button when editing a course section summary

                   Previously the cancel button when editing a course section summary would
                   not cancel the action but instead complete it.
                   The cancel button now correctly disregards any changes the user has made.

    TL-7110        Fixed program exceptions not being triggered when creating new a assignment

                   Previously if an assignment was added to a program or certification, and a
                   completion date was set, all in one step (without saving in between) then
                   exceptions for those assignments were not being checked.
                   The fix for this issue ensures exceptions are correctly checked and
                   triggered.

    TL-7142        Added a new capability for the certificate modules "email teachers" setting and updated its language strings

                   Previously the setting was sending notifications to everyone with the
                   mod/certificate:manage capability, which resulted in all site managers
                   receiving the messages.
                   The setting is now called send notifications and it uses a new capability
                   mod/certificate:receivenotification which defaults to only the editing and
                   non-editing trainer roles, if you want your site managers or custom roles
                   to receive these notifications you will have to give them the capability.

    TL-7149        Fixed the display of certification status within report builder filters
    TL-7156        Fixed the display of certification renewal status in the Record of Learning report
    TL-7241        Fixed the creation of embedded reports on a clean installation

                   Previously, embedded reports were only being generated the first time that
                   each report was accessed. Now, they are also all created when the Manage
                   Reports page is first accessed.



Contributions:

    * Jamie at E-learning Experts - TL-5709
    * Jo Jones at Kineo - TL-6767


Release 2.5.29.1 (29th July 2015):
==================================================


Bug fixes:

    TL-7017        Fixed Totara Sync incorrectly deleting existing users when the CSV source has invalid values

                   A bug was found in Totara Sync when 'Source contains all records' has been
                   turned on, the 'Delete' sync action has been enabled, and a user in the
                   source has an invalid manager.
                   In this situation the user record would be incorrectly deleted.

    TL-7044        Fixed rules for dynamic audiences based on a text input user profile field having multiple values

                   A bug was discovered with dynamic audiences which had been configured with
                   one or more rules on custom user profile fields with a series of comma
                   separated values.
                   When configured in this way users may be incorrectly added and/or removed
                   from the audience.
                   This could lead to users having access to things that they should not
                   otherwise have access to or for users to lose state and data if they were
                   incorrectly removed.

                   The fix for this includes a large number of new automated tests to ensure
                   that this does not happen again.


Release 2.5.29 (21st July 2015):
==================================================


Bug fixes:

    TL-4479        Fixed bug with poorly wrapped forum subjects when sent as an email
    TL-5552        Fixed manager approval being skipped when changing the date/time of a session
    TL-5562        Fixed a potential problem when inserting multiple records in a batch

                   This fixes a potential problem when importing a broken CSV file into course
                   completion and a potential minor problem when upgrading multiple custom
                   menu fields in Facetoface module.

    TL-6513        Fixed issue causing Certification expiry periods to double

                   If the Certification Completion Upload tool was used uploading completion
                   records for users who were already assigned to the Certification, an issue
                   could arise where the life of the certification would be incorrectly
                   doubled.

    TL-6527        Fixed events not being called when audiences were unenrolled from courses

                   Some problems relating to Facetoface events were also fixed,
                   including users not being removed from future sessions when they were
                   removed in bulk from courses, and ensuring that users are only removed once
                   their last enrolment was removed.

    TL-6653        Fixed email duplication from program enrolment messaging
    TL-6709        Fixed wrapping of long question titles in Appraisal PDF exports
    TL-6784        Fixed the display of unassigned programs on the record of learning: programs report

                   The record of learning was not displaying programs assigned via learning
                   plans, or completed programs that the user was unassigned from.

    TL-6799        Fixed course creator role capabilities for managing audiences
    TL-6802        Fixed a fatal error with learning plan enrolments when a course is included in multiple plans
    TL-6979        Fixed Facetoface archive when certification window period equals active period

                   If a facetoface belonged to course which belonged to a certification, and
                   the certification window open period was the same as the active period,
                   then when the course was reset to allow recertification, the facetoface
                   activity was automatically re-triggering completion and recertification.

    TL-6997        Fix prog_get_all_programs incorrectly applying visibility

                   On sites which had switched from normal visibility settings to using
                   audience-based visibility, if a program had previously been set to
                   "hidden", progress was not being updated when users completed courses.



Security issues:

    TL-5289        Missing database record errors no longer contain the database table name
    TL-6823        Improved access control handling in Appraisal and Feedback360 assignments

                   Two scripts in Appraisal and two scripts in Feedback360 were identified as
                   having insufficient access control checks.
                   This has now being remedied and all required access control checks are now
                   being made in the four identified scripts.

    TL-6927        Fixed incorrect synchronisation of suspended users in course meta enrolments
    TL-6930        Fixed incorrect protocol handling in the curl library

                   Prior to this patch use of CURLOPT_PROTOCOLS and CURLOPT_REDIR_PROTOCOLS
                   were limited by the existence of the CURLOPT_PROTOCOLS define.
                   This restriction has been removed as it was no longer necessary.

    TL-7032        Improved the generation of random strings within core

                   It was brought to our attention that in some situations the random string
                   generation used during processes such as resetting of user passwords could
                   be predicted and possible exploits crafted.
                   Prior to this patch random string generation used the PHP built in mt_rand
                   function.
                   After this change we use a variety of methods and fall back to our own
                   unpredictable generation.


Improvements:

    TL-6932        Added a link to the manage extension page in the program extension request emails
    TL-7040        Improved default capabilities for totara sync


Contributions:

    * Russell England at Vision By Deloitte - TL-6932


Release 2.5.28.1 (24th June 2015):
==================================================

Bug fixes:

    TL-6769        Fixed undefined constant error when deleting a course
    TL-6814        Fixed unwanted creation of certification completion records caused by a regression in TL-6581.

                   Patch TL-6581 caused certification completion records to be created for
                   user who had been unassigned from certifications. This patch removes those
                   new records and ensures that certification completion records are only
                   created for users who are currently assigned.


Release 2.5.28 (23rd June 2015):
==================================================

Security issues:

    TL-6566        Improved XSS prevention checks when serving untrusted files in IE
    TL-6576        Ensured Audience description is sanitised before display

                   Thanks to Hugh Davenport at Catalyst NZ for reporting and providing a fix
                   for this issue.

    TL-6613        Improved validation of local URLs


Improvements:

    TL-6358        Added config option to control the display of Hierarchy framework, type and item shortcodes

                   Previously whether Hierarchy shortcodes were displayed was defined in code.
                   This patch adds a new config setting under Advanced Features. If you had
                   previously made a customisation to the code (by setting constant
                   HIERARCHY_DISPLAY_SHORTNAMES in totara/hierarchy/lib.php to true) to enable
                   the display of Hierarchy shortcodes, you will need to re-enable the display
                   of shortcodes using the new configuation setting.

    TL-6544        Changed certification Status strings in certification reports to better reflect the actual statuses

                   "Assigned" was changed to "Not certified"
                   "Completed" was changed to "Certified"
                   "Expired" and "In progress" were unchanged.

    TL-6558        Improved scalability of query in course completion

                   This was causing a database error on some platforms due to an oversized IN
                   query with large data sets.

    TL-6650        Changed program user assignments to defer large changes to happen on the next cron run

                   Previously, when saving changes to user assignments in a Program or
                   Certification, the new users were assigned when the save button was
                   clicked. This was causing pages to time out when assigning large audiences.
                   Now, the contents of the assignment tab are saved immediately but the users
                   are not assigned to the program until the next cron run occurs. On-screen
                   notifications have been added to indicate if pending assignments are
                   waiting for a cron run.

    TL-6664        Improved the performance of Reportbuilder management pages
    TL-6735        Added logging whenever activity completion is unlocked

Bug fixes:

    TL-5978        Fixed inconsistent access control checks for Learning Plans

                   The behaviour has now been standardised throughout the code. Granting the
                   totara/plan:manageanyplan capability allows users to create and edit plans for any user.
                   Granting totara/plan:accessplan allows users to see and modify their own plans,
                   and allows staff managers to create and edit the plans of their staff.

    TL-6222        Fixed courses incorrectly being visible in the Courses section of the Navigation block when using audience-based visibility
    TL-6263        Fixed reaggregation of course completion

                   Course completion records would never be reaggregated on the cron run, if
                   the "Completion begins on enrolment" course setting was turned off when
                   course completion criteria were unlocked.

    TL-6319        Fixed rules for dynamic Audiences based on a text input user profile/custom field being empty
    TL-6374        Fixed Reportbuilder 'last/next X days' date filters

                   The 'Is between today and X days before/after today' filters were
                   internally using a specific date rather than a relative number, resulting
                   in saved searches not working as intended. This filter will now always be
                   relative to the date on which it is used. Existing saved searches have been
                   converted, but it is possible that some may be incorrect (although all were
                   wrong without this patch). We advise that users check that saved searches
                   which contain date filters have the intended values.

                   Note that any users that are logged in and using these filters during the
                   upgrade progress may need to log out and back in to see the correct values.

    TL-6440        Fixed create/edit capability permissions for Programs and Certifications
    TL-6516        Fixed resetting of Certification message logs when the recertification window opens

                   When the window opens it tried to delete message logs for the users manager
                   as well as the user even though the manager records were never created.

    TL-6539        Fixed Program due messages being sent to users who have current exceptions
    TL-6581        Improved handling of and recovery from missing Certification completion records

                   Due to various causes such as page timeouts, it is possible that some
                   certification completion records are not being created. This patch ensures
                   that the records are created when users access their certifications. A
                   check has been added to the certification cron task which will find any
                   users who are missing these records and will create them.

    TL-6633        Fixed sharing of config and dbmeta caches by version

                   Configuring the config or database meta information caches to be shared by
                   version could lead to a notice and caches being over-shared regardless of
                   version.
                   This fix ensure that the version is properly loaded in early initialisation
                   situations when sharing has been configured to include version for these
                   two sites.

    TL-6663        Fixed enforcement of required custom profile fields when self-registration is enabled and the registering user is currently logged-in as a guest
    TL-6680        Improved display when adding a random quiz question to a quiz when using RTL languages
    TL-6744        Fixed error message when adding linked courses to Learning Plan competencies or objectives


Contributions:

    * Hugh Davenport at Catalyst NZ - TL-6576
    * Tom Black at Kineo UK - TL-6516


Release 2.5.27 (19th May 2015):
==================================================

Security issues:

    MDL-50128      mod_data: String needed escaping before being used in regex
    MDL-49718      externallib: unittest correction
    MDL-50090      user: suspended user can login upon conrimation
    MDL-49718      webservices: Fix forced format and force external text cleaning
    MDL-50099      auth: less verbose account confirmed message
    MDL-49179      setuplib: print_error() uses local URLs exclusively
    MDL-49179      weblib: Secure the direct usage of $_SERVER['HTTP_REFERER']
    MDL-49179      mod_forum, mod_quiz: Prevent misuse of get_referer()
    MDL-49941      quiz: mod/quiz:grade should declare RISK_XSS
    MDL-49401      moodlelib: PARAM_LOCALURL supports loginhttps
    MDL-49204      core_message: Checking current user
    MDL-49364      quiz statistics: escape output in the response analysis
    MDL-49087      mnet: Ensure typeroot is in dirroot
    MDL-49087      mnet: Use real dataroot instead of user-provided
    MDL-48691      webservices: Check if the user must be changing password
    MDL-49084      core_tag: add capability check to flag as inappropriate action
    MDL-49144      blocks: Sanitise alt and title for block controls
    MDL-38466      filters: Redos protection and unit tests
    MDL-38466      filters: ReDoS protection for text to URL conversion.
    MDL-49167      YUI: Fix for theme/yui_combo.php and $CFG->yuislashargs


Improvements:

    TL-5311        Added Course Completion History report builder source

                   This report source contains all records from both the current course
                   completions table and the course completions history table.

    TL-6295        Showed expected csv format when importing a "database" course activitiy
    TL-6304        Changed default request method in dialogs to POST
    TL-6327        Added ability to specify database server port for Totara Sync external database source settings
    TL-6331        Changed timezone.txt downloads to use Totara servers
    TL-6348        Removed unneeded code when viewing a Certifications overdue warning
    TL-6350        Added a help description to Badge description to explain its plain text nature
    TL-6411        Improved display of security information on calendar exports
    TL-6462        Add 'course update' event trigger to move_courses function

API changes:

    TL-6442        Fixed query parameter name conflicts by improving parameter name generation

                   This fix introduced a new method moodle_database::get_unique_param that
                   returns a truly unique param name with very little overhead.
                   The bug fix involves conversion of areas generating their own "unique"
                   param names to this new method.
                   All new code requiring unique generated params should use this method.


Bug fixes:

    TL-5977        Fixed upgrade for Facetoface notifications when upgrading from 2.2
    TL-6180        Fixed capability checks for category Audiences
    TL-6191        Fixed permissions when adding visible audiences to a program or course

                   Permissions are now being checked on the correct context level so users
                   assigned at the category, program or course contexts with permissions are
                   now able to perform actions. This applies to Audience visibility for
                   courses, programs and certifications and also Audience enrolment for
                   courses.

    TL-6259        Fixed completion import records being processed in the wrong date order

                   This caused a problem if there were multiple completion records for one
                   user in one course being uploaded and the date format used did not sort the
                   same chronologically and alphabetically.

    TL-6305        Fixed Program/Certification alerts and messages to exclude suspended and deleted users
    TL-6345        Fixed setting of a Certification completion status to 'expired' when renewal expires

                   Previously, these certifications were set back to status 'assigned'. This
                   patch makes no change to the behaviour of certifications, it just ensures
                   that the correct data is recorded in the database.

    TL-6354        Fixed incorrect inclusion of deleted users when using recurring Programs
    TL-6373        Fixed Facetoface notification status incorrectly sending manager copy when notification is disabled

                   If a notification is disabled, the manager and third party email addresses
                   will no longer receive the notification, regardless of the "Manager copy"
                   setting.

    TL-6376        Fixed invalid HTML when viewing a complete Program with an end note
    TL-6437        Fixed usage of complex passwords in Totara Sync
    TL-6439        Fixed error message when trying to access the course progress page from Record Of Learning after user is unenrolled from course

                   Previously, if a user was unenrolled from a course, the course progress
                   page became inaccessible. Now that unenrolled courses with progress are
                   shown in the Record of Learning, it makes sense to allow users to see what
                   progress they previously made.

    TL-6445        Fixed changes to Facetoface session attendees after a waitlisted session has started
    TL-6450        Fixed export of parameteric reports in Reportbuilder

                   Fixed error that blocked export of reports that require specific parameters
                   to work (like appraisal or audience members).

    TL-6457        Fixed checkbox selection/deselection when Program exception "Select issue type" is changed
    TL-6471        Fixed the course enrolment date after unlocking completion criteria
    TL-6472        Fixed Completion History Import if it is using 'Alternatively upload csv files via a directory'
    TL-6490        Fixed activity completion when using manual grading on a Facetoface activity
    TL-6510        Fixed the rule for dynamic Audiences based on a positions multi or menu type custom field values
    TL-6520        Fixed the context checks for program deletion capabilities

                   Program deletion was only working if you had the capability at a site
                   level, this fixes it for if you have the correct capabilities at category
                   or program level.


Contributions:

    * Andrew Hancox at Synergy - TL-6445
    * Eugene Venter at Catalyst - TL-6345, TL-6348
    * Gavin Nelson at Engage in Learning - TL-6472
    * Jo Jones at Kineo UK - TL-6437
    * Russell England - TL-6462, TL-6520
    * Ted van den Brink at Brightalley - TL-6376


Release 2.5.26 (21st April 2015):
==================================================

Security issues:
    T-13359        Improved param type handling in Reportbuilder ajax scripts

Improvements:
    T-13925        Improved sql case sensitive string comparisons for completion import records.

                   When 'Force' is enabled the system keeps track of the course shortnames
                   being used, each new course is compared in a case sensitive way and if it
                   matches that but doesn't match exactly the system uses the first course
                   name instance. There will be no error messages on the import report about
                   it.

    T-14217        Added debug param to all Reportbuilder reports

                   This allows administrators to retrieve additional debugging information if
                   they have problems with reports. Some reports already had this feature, now
                   all of them do.

    T-14016        Added "Choose" option as the default value for "Menu of choices" type custom fields
    T-13542        Changed language pack, timezone and help site links to use HTTPS

API Changes:
    T-14215        Enforced linear date paths when upgrading Totara

                   When upgrading a Totara installation you are now required to follow a
                   linear release date path. This means that you now MUST upgrade to a version
                   of the software released at the same time or after the release date of your
                   current version.

                   For example if you are currently running 2.5.25 which was released on 18th
                   March 2015, you can upgrade to any subsequent version of 2.5, any 2.6 from
                   2.6.18 onwards, or any 2.7 from 2.7.1 onwards.

                   This ensures that sites never end up in a situation where they are missing
                   critical security fixes, and are never in a state where the database
                   structure may not match the code base.

                   The Release Notes forum is a useful source for the date order of version
                   releases https://community.totaralms.com/mod/forum/view.php?id=1834

Bug Fixes:
    T-14302        Fixed database host validation in Totara Sync settings
    T-13917        Fixed error when adding Score column to Appraisal Details report

                   The report would fail if the Score column was added to an Appraisal
                   containing a Rating (Numeric scale) question.

    T-14311        Fixed the archiving of Facetoface session signups and completion

                   When uploading historic certification completions future facetoface session
                   signups were being archived, now it will only archive signups that
                   completed before the window opens date.

    T-12583        Fixed behaviour of expand/collapse link in the standard course catalog
    T-13550        Fixed Due Date displaying as 1970 on Record of Learning: Certifications

                   This patch fixed a problem where an empty timedue data value was causing a
                   date in 1970 to show in the Due Date field in the Record of Learning:
                   Certifications report source. It also introduces a comprehensive phpunit
                   test for the certification and recertification process.

    T-14184        Fixed appending of message body after manager prefix in Facetoface 3rd party notifications

                   If Third party email addresses were specified in the Facetoface settings then any
                   third-party copies of emails sent by the system would not contain both of the
                   manager prefix and the body of the message (the content that the learner receives)

    T-14105        Fixed calculation of 'User Courses Started Count' in the 'User' report source

                   This is now calculated based on course completion records, rather than
                   block_totara_stats (which might be missing 'started' records for various
                   reasons, such as migration from Moodle or changing certain completion
                   settings while a course is active). This affects the 'Courses Started'
                   column in the 'My Team' page - courses started should now always be greater
                   than or equal to courses completed.

    T-14187        Fixed resetting of Hierarchy item types after every Totara Sync run

                   Hierarchy item (e.g. position, organisation etc) types should only be changed
                   if the Sync source contains the "type" column.

    T-14243        Fixed handling of special characters (e.g. &) when returning selections from dialogs
    T-14192        Fixed Assignment Submissions report when it is set to use 'Scale' grade

                   The Submission Grade, Max Grade, Min Grade and Grade Scale values columns
                   were displaying incorrect information.

    T-13886        Fixed PHP Notice messages when adding a Rating (custom scale) question to Appraisals
    T-14266        Fixed the display of Learning Plans date started when viewing a completed plan
    T-13353        Fixed handling of param options in Reportbuilder
    T-13894        Fixed validation and handling of Facetoface notification titles
    T-14048        Fixed incorrect Quiz question bank names after previous upgrade

                   Question banks containing subcategories had the subcategory names
                   incorrectly changed by a change in 2.5.20 and 2.6.12. If you are upgrading
                   from a version affected (2.5.20-25, 2.6.12-18) you may want to check if
                   your Quiz question bank categories are affected.

    T-14186        Fixed max length validation for Question input text box
    T-14131        Fixed handling of error when importing users via Totara Sync with the create action disabled

                   Thanks to Andrew Hancox at Synergy Learning for contributing the solution.

    T-14083        Fixed display of 'More info' Facetoface session page

                   When a session was fully booked, learners booked on the session would
                   receive a ""This session is now full" message instead of the actual details
                   of the session.

    T-14075        Fixed inability to send a previously declined Learning Plan for re-approval
    T-14065        Removed non-functional "deleted user" filter from bulk user action pages


Release 2.5.25 (18th March 2015):
==================================================

Security issues:
    T-13996        Removed potential CSRF when setting course completion via RPL
    T-14175        Fixed file access in attachments for Record Of Learning Evidence items
                   Thanks to Emmanuel Law from Aura Infosec for reporting this issue.

API Changes:
    T-14084        Renamed $onlyrequiredlearning parameter in prog_get_all_programs and prog_get_required_programs functions
    T-14104        Added courses which have completion records to the record of learning

                   Previously, if a user had been enrolled into a course, made some progress
                   or completed it, then been unenrolled from the course, the record of course
                   participation disappeared from the user's record of learning. With this
                   patch, courses will still show when a user has been unenrolled, if their
                   course status was In Progress, Complete or Complete by RPL. This change was
                   made to the Record of Learning: Courses report source, so all reports based
                   on this source will be affected.

Bug Fixes:
    T-13920        Fixed export to Excel of completion progress column in Record Of Learning - Programs report source
    T-14001        Fixed "Same as preceding question" checkbox in IE8 when assigning roles to a question in Appraisals
    T-13698        Fixed display of required learning review questions when learners are completing an Appraisal
    T-13995        Removed unused files from codebase

                   The following files have been removed
                   * course/completion_dependency.php
                   * totara/core/js/completion.dependencies.js.php

    T-11338        Fixed saving of options when using multiple choice questions in Appraisals
    T-13986        Fixed deletion of course custom field data when a course is deleted
    T-13366        Fixed certifications incorrectly causing the programs tab to appear in Record of Learning
    T-13884        Fixed error in Appraisals dialog box when selecting required learning for review
    T-14114        Fixed program and certification exceptions being regenerated after being resolved

                   This patch also prevents certification exceptions being generated when an
                   assignment date is in the past and the user is in the recertification stage
                   (at which point the assignment date is not relevant, as the due date is
                   controlled by the certification expiry date instead).

    T-14093        Fixed dynamic audiences rules based on Position and Organisation custom fields

                   Thanks to Eugene Venter at Catalyst for contributing to this

    T-13628        Fixed deletion of custom fields if missing from the Totara Sync CSV file
    T-13926        Fixed copying instance data when copying block instances

                   When users click the "Customise this page" button in My Learning, blocks
                   copied from the default My Learning page to the user's personal My Learning
                   page can also copy instance specific data. This allows Quick Links blocks
                   to correctly copy the default URLs.

    T-14070        Fixed MySQL 5.6 compatibility issues

                   Totara would not install on MySQL 5.6, and also unit tests were failing
                   with "Specified key was too long" errors

    T-13946        Fixed change password function for users with an apostrophe in their username
    T-14120        Fixed sort in all Audience dialog boxes
    T-14079        Fixed visibility of course items in Learning Plan page

                   There were several problems relating to being able to add courses to a
                   learning plan that are not visible to the learner. This fix is preventing
                   an admin to add invisible courses and taking into account audience
                   visibility.

    T-13472        Fixed several problems where scheduled Appraisal messages were not sent at the right times
    T-14135        Fixed paging when adding items to a learning plan
    T-14041        Fixed installation on PostgreSQL when the dbschema option is present

                   Added support for custom schemas in PostgreSQL

    T-14096        Fixed formatting of dates in Certification report sources
    T-13661        Fixed joinlist for the Assignment Submissions report source

                   When viewing the 'Assignment submissions' report source, no assignment
                   submissions were displayed unless they were either graded, or the
                   'Submission grade' column was removed from the report.

    T-14072        Fixed intermittent query parameters error when using the select course dialog
    T-13630        Fixed MSSQL ORDER BY for audience rule set when using a custom text input field with 'Choose' option
    T-13922        Fixed Totara Sync error messages to display strings over 255 chars long
    T-14088        Fixed incorrect reference to course completion data in delete user confirmation text
    T-14027        Prevented users from deleting the default category


Release 2.5.24 (18th February 2015):
==================================================

Improvements:
    T-13071        Created separate report sources for certification completion/overview

                   The logic in program reports was not up to the task of displaying
                   certifications, so they have been moved into their own report sources. The
                   "Program Overview" report source is now mirrored by "Certification
                   Overview", and "Program Completion" by "Certification Completion". If you
                   are currently using program reports to display certifications then you will
                   need to create the certification versions of the reports, where you will
                   find all the same functionality plus some new certification specific fields
                   and functionality.

    T-13854        Added additional information to 'Delete user' confirmation page

API Changes:
    T-14043        Added ability to unlock activity completion without deletion

                   This change also fixes a bug whereby a user editing an activity included in
                   course completion but not yet completed by any users causes all users who
                   have previously completed the course to loose their data.

Bug Fixes:
    T-13888        Fixed displayed value of Course Date Completed column in Program Overview report source
    T-13603        Fixed sending of Facetoface session trainer cancellation notifications to all assigned trainers
    T-14013        Fixed validation bug when copying Facetoface session with predefined room
    T-13952        Fixed display of Totara Menu with custom CSS applied in Custom Totara and Custom Totara Responsive themes
    T-13885        Fixed display of HTML encoded characters when added via a dialogue box

                   When editing a users position (primary or otherwise), if an organisation,
                   position or user is added to the users position via a dialogue box and the
                   data added contains HTML encoded characters (such as an ampersand - &amp;)
                   the character was displayed in its encoded form (i.e. &amp;)
                   rather than its non-encoded form (i.e. &). This has been corrected.

    T-13988        Fixed issue with timezone calculations incorrectly detecting session role conflicts in Facetoface
    T-13812        Fixed several interface problems related to editing rules in dynamic audiences
    T-14042        Fixed cleanup of users enrolled on a certification by an audience, who are no longer part of the audience
    T-13910        Fixed user checkbox filter when searching list of users
    T-13887        Fixed saved searches being incorrectly applied on scheduled reports
    T-13619        Fixed RTL display issues in admin tables in Standard Totara Responsive theme
    T-13433        Fixed calculation across DST boundaries for Reportbuilder and Sync next scheduled run

                   Scheduled daily Reportbuilder reports and scheduled daily Sync runs would
                   trigger repeatedly on every cron run for an hour during DST boundaries
                   where the clocks are going back/forward an hour.

    T-13582        Fixed 'Currently Viewing' navigation section when Learning Plans are disabled
    T-13724        Excluded inaccessible courses and programs from being added to learning plans
    T-13881        Fixed iCal description fomatting issue where spaces between words could be removed
    T-13190        Fixed users being incorrectly enrolled onto unavailable programs
    T-13599        Fixed Facetoface Waitlisted tab incorrectly being disabled after adding/removing attendees
    T-13761        Fixed error when editing a Facetoface session that uses predefined rooms


Release 2.5.23.1 (2nd February 2015):
==================================================

Security issues:
    MDL-48980      Always clean the result from min_get_slash_argument
    T-13866        Ensured require_login is called before course visibility checks

Improvements:
    T-13873        Added notification that course completion criteria changes will be applied on next cron

                   This patch reverts the changes made in patch T-13138. Performing instant
                   course completion recalculation when changing course completion criteria
                   could cause performance issues, and be inconsistent with other features,
                   such as certification completion recalculation.


Bug Fixes:
    T-13868        Changed display of times to 24-hour format in non-English languages

                   The %p date format modifier to display AM/PM with time data in the 12-hour
                   clock format is unreliable across platforms and locales so we have switched
                   to 24-hour time display for most non-English languages. You can change this
                   back by making a local language customisation to the
                   nice_time_in_timezone_format and timedisplay24 strings in
                   totara_reportbuilder, and the sessiondatetimeformat string in
                   mod_facetoface, using the formats described here
                   http://php.net/manual/en/function.strftime.php

    T-13006        Fixed users in limbo due to facetoface session signup capacity collisions

                   It is possible, although highly unlikely, that two users tried to sign up
                   to the last place in a session at the same time, and one of the users
                   became stuck in limbo, neither properly assigned nor able to sign up to
                   another session. This patch fixes existing records and prevents the error
                   from occurring.


Release 2.5.23 (21st January 2015):
==================================================

Security issues:
    MDL-47920      mod/lti/ajax.php security problems
    MDL-48368      XSS in course request pending approval page
    MDL-48329      Messages external functions doesn't check if messaging is enabled
    MDL-48106      Multiple CSRF in mod glossary
    MDL-48017      calendar/externallib.php lacks self::validate_context($context);
    MDL-47964      Forced logout via auth/shibboleth/logout.php
    MDL-48546      ReDOS in the multimedia filter
    MDL-48748      Import fixed English strings (en_fix) into the main English pack

Improvements:
    T-12100        Added the ability to assign a certification to an audience under enrolled learning
    T-13477        Improved scalability for the program cron and reports

                   Thanks to Kineo UK for providing the core of this patch

    T-11141        Added the ability to use spaces in field names in a CSV file for Totara Sync
    T-13653        Improved behaviour of Facetoface session duration in relation to session date/time

                   The session duration field is now disabled when session date/time is known,
                   and is automatically recalculated (as before) when the session is saved

API Changes:
    T-13636        Fixed "from" address in Face-to-face waitlist emails when a user cancels their booking

                   The optional param $fromuser has been added to several
                   facetoface_user_signup and several Face-to-face notification functions.

Bug Fixes:
    T-13647        Fixed Overall Total columns in Appraisal Detail report source
    T-13552        Fixed duplicate records in Program Completion reports

                   This patch removes duplicate records from tables prog_completion and
                   prog_user_assignment. Deleted program completion records are archived in
                   prog_completion_history. Indexes are added to these tables to prevent
                   future duplication of records and discrepancies in the record of learning
                   and required learning reports.

    T-13880        Fixed missing language string in Facetoface notifications
    T-12679        Fixed completion date on a course with multiple Facetoface sessions

                   If a course contained a Facetoface session with multiple sessions where a
                   user could complete the activity multiple times (for example a course used
                   as part of a recurring certification) the course completion date would
                   always use the date of the earliest session the user completed, not their
                   most recent completion

    T-13422        Fixed archiving of completion on certifications containing a Facetoface

                   In some circumstances if a certification path contained a course with a
                   Facetoface activity, course and activity completions would not be reset
                   properly when the recertification window opened, making it impossible to
                   recertify.

    T-13819        Changed course completion criteria unlocking - no records are changed until save changes is clicked

                   Existing course completion records were being removed immediately upon
                   clicking the "Unlock criteria and delete existing completion data" button.
                   This change causes the deletion of data to be delayed until the Save
                   changes button is clicked. If the users changes their mind, they can click
                   Cancel to abort the data reset.

    T-13835        Fixed SCORM retriggering course completion during certification archive

                   In some circumstances if a certification contained a course with a SCORM
                   activity, when the certification window opened course completion would not
                   be archived and reset properly.

    T-13725        Fixed incorrect check when unassigning users from a program/certification

                   When removing users from certifications that were uploaded via the upload
                   completion tool, the role_assignments table was being checked, when the
                   correct check should be on prog_user_assignment.

    T-11643        Fixed display of error message if a program extension request fails
    T-13756        Fixed email filters on User report source

                   Added a filter "User's Email (Ignoring user display setting)" and fixed
                   filtering on email addresses where the search term contained the @ symbol


Release 2.5.22 (18th December 2014):
==================================================

Improvements:
    T-13426        Fixed approval workflow in Learning Plans

                   When a learner has permission to approve their own Learning Plan they now
                   get an Activate button instead of Approve and Decline buttons

    T-13547        Improved editing and display of Program Summary, Summary files and Endnote fields.

                   These fields are now shown in the program Overview tab. Clicking the Edit
                   Program Details button is now working correctly.

    T-12257        Standardised the behaviour of programs, certifications and courses catalogues
    T-13585        Improved alignment of activity completion checkboxes
    T-13418        Fixed issues with bulk adding attendees on a Facetoface session where manager approval is required

                   This changes the default behaviour when bulk adding attendees to a
                   Facetoface session. Now if Manager approval is required an approval request
                   will be sent. There is also a new check-box at the bottom of the list to
                   ignore the manager approval setting.

    T-12796        Added a help button explaining which statuses are included in 'All Booked' on Facetoface notifications page
    T-13561        Improved performance of the My Reports tab

Bug Fixes:
    T-13410        Link appraisal review question statuses

                   When the status of an item (e.g. a goal or competency) is changed, other
                   instances of the same item on the same page will automatically change to
                   match.

    T-13581        Removed commas on course page for Facetoface room when room fields are empty
    T-13560        Fixed setting of Site Manager and User capabilities on fresh installs

                   When Totara is freshly installed on a server it sets up the capabilities
                   for each system role. It was found that the following capabilities were not
                   being applied to the site manager and user roles correctly:

                     - totara/plan:manageevidencetypes (Site Manager)
                     - totara/plan:editsiteevidence (Site Manager)
                     - totara/plan:editownsiteevidence (Site Manager and User)

                   This is now corrected for a fresh installation. For existing installations,
                   administrators need to manually edit the roles and allow the capabilities
                   listed above.

    T-12676        Fixed Totara Sync database source connections with non-alphanumeric passwords
    T-13439        Restricted user search in Facetoface bookings block to those with required capabilities

                   The search form will only be visible to users who have the
                   'block/facetoface:viewbookings' capability in the context of at least one
                   other user, and search results are filtered to those they can access.

    T-13556        Fixed redirect to Record of Learning after a manager manually completes a learner's course in a Program
    T-13597        Fixed database query related to some Program due date and time allowance calculations.

                   If a program had more than one course set with a "THEN" condition between
                   them AND a learner assignment had a fixed or empty completion date, then it
                   was sometimes possible for an invalid program exception to be generated for
                   the learner, or (only with non-empty, fixed completion date) the due date
                   may have been incorrectly calculated (possibly giving the learner an
                   extended due date).

    T-12749        Fixed undefined constant warning while managing courses
    T-13779        Fixed Program function prog_get_all_users_programs to return correct program ids
    T-13737        Added message body after manager prefix in Facetoface notifications

                   Contributed by Aaron Barnes from Catalyst

    T-13158        Fixed display of Badge descriptions that contain line breaks
    T-12967        Fixed hardcoded string in the time completed filter for the Feedback Summary report source
    T-13483        Fixed Facetoface notifications not being sent to managers when notify manager checkbox is selected
    T-13652        Fixed bugs with Facetoface session room validation

                   Session validation is now performed every time a session is saved. If
                   validation fails, the problem will be displayed in the form, allowing the
                   user to correct the problem. With this change, the room will no longer be
                   automatically removed every time the session date or time is changed.

    T-13589        Fixed learner description for Course and Program tabs on Learning Plan
    T-13539        Fixed date type custom user profile fields being overwritten with today's date when updating users with Totara Sync
    T-13119        Fixed importing of MS Outlook iCal files into the Calendar


Release 2.5.21 (14th November 2014):
==================================================

Security issues:
    MoodleHQ       Security fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.5.9_release_notes
    T-13465        Fixed access control when viewing archived certificates
    T-13145        Fixed potential security vulnerabilities when editing saved searches in Reportbuilder
    T-13146        Prevent guests from using the saved search feature in Reportbuilder

                   Totara's data manipulation policy is that guest users cannot make any
                   changes that will alter data

Improvements:
    T-11144        Backported MDL-39726 to improve performance of quiz backup/restoration

Bug Fixes:
    T-13462        Fixed Program assignments based on the position start event.

                   This fixes a bug that was introduced recently. To fix affected
                   programs (those with "Completion time unknown" exceptions, where the
                   students have valid positions and start times), click "Save changes" in the
                   assignments tab of each affected program.

    T-13375        Fixed restoring deleted users and assigning them as managers in the same user sync

                   When syncing users and position assignments, sync will now process the
                   position assignments after all user creation/updates/deletion.

    T-13371        Fixed incorrect calculation of manual course enrolment durations

                   SCOPE: when users were enrolled onto a course manually and an enrollment
                   duration was set, the calculation of the end date was incorrect if the
                   enrollment period crossed a daylight-savings boundary.

                   IMPACT: manual enrollment periods may have had an end date that was
                   incorrect by one hour

    T-13137        Fixed capability check in totara_course_is_viewable function
    T-13406        Ensured url property is set on reports before displaying report list
    T-13229        Fixed RPL course completion records being deleted when activity is updated
    T-13400        Fixed Program Completion report source displaying deleted programs
    T-12985        Fixed setting of default user for course badge creators when restoring a course backup
    T-13404        Fixed evidence filter not working in the Evidence report source
    T-13358        Fixed program extension requests which had been approved being overriden by cron
    T-13457        Fixed incorrect enrolment start dates when uploading course completion records

                   When course completion records were uploaded using the coursecompletion
                   import tool, any user enrolment records created had a random start date in
                   2000. The enrolment start date is now the date of the course completion
                   import upload.

    T-12300        Fixed incorrect visibility of Facetoface sessions in the calendar

                   Made visibility of Facetoface sessions in the calendar match the visibility
                   of the course containing the Facetoface session, when audience visibility
                   is enabled.

    T-13511        Fixed upgrade errors when the activitynames filter is enabled


Release 2.5.20 (29th October 2014):
==================================================

Security issues:
    T-12620        Fixed Facetoface access control issues

Improvements:
    T-13411        Change quiz result reports query to use get_recordset

                   This change is intended to improve performance for quiz reports containing
                   large amounts of data, especially to avoid memory overflow when exporting.

    T-12677        Improved error messages for Totara Sync

                   Specifically database read/write messages.

                   It is intended to provide a better information rather than the generic
                   "Error writing to database" if an error occurs during the import.

    T-12610        Improved multilingual support in mod_quiz question bank category selector
    T-12823        Removed invalid string in language pack for the totara_core component

Bug Fixes:
    T-13199        Fixed handling of program exceptions when linked user assignments do not exist
    T-13376        Fixed automatic conditional completion of course not cascading timecompleted correctly
    T-13367        Show error rather than warning when accessing hidden course

                   This prevents users from seeing the names of courses which should be hidden
                   to them, preventing privacy issues.

    T-12942        Fixed an issue with Appraisal questions where the list of visible roles overlaps the input field
    T-12481        Fixed custom user profile fields not being formatted correctly in Bulk User Actions download
    T-13334        Fixed error when trying to send multiple Program Due messages in certifications
    T-13423        Fixed border going off the page in A4 formats in certificates
    T-12140        Fixed the SCORM Interactions report processing SCOs with duplicated questions incorrectly
    T-13138        Fixed course completion when condition activity completion is changed

                   IMPACT: A new event has been defined to reaggregate course completion when
                   updating Course Completion with module requirements using "ANY of the
                   conditions are met"

    T-12300        Fixed incorrect visibility of Facetoface sessions in the calendar

                   Made visibility of Facetoface sessions in the calendar match the visibility
                   of the course containing the Facetoface session, when audience visibility
                   is enabled.

    T-13169        Fixed incorrect column type string in Record Of Learning Certifications report
    T-12765        Added sort order in program assignments to select the completion date for a user

                   IMPACT: when having more than one assignment for a user in programs or
                   certifications, it is not possible to know what completion date is taken
                   into account in the user's due date. Now a sort order has been added, so
                   the last assignment made for the user is the one the system uses to
                   determine the due date.

                   Also, there is a change that allows overriding the overdue date in
                   certifications once it has passed. So, if a certification has expired for a
                   user and the completion date set is greater than the expiry date, then it
                   will be used as the new expiry date.

    T-13278        Fixed nested audiences being updated even when they have expired
    T-13054        Fixed Overdue incorrectly appearing on completed programs and certifications
    T-13318        Fixed issue where uploading course completion records can result in incorrect Program completion dates

                   IMPACT: if the course completion upload tool was used to upload course
                   completions, and the completed course then resulted in a program being
                   completed, the resulting program completion dates were incorrect as the
                   code incorrectly used the MAX completion date in the uploaded CSV to set
                   the completion date for every user in the Program. Now sets the date for
                   each user individually properly to match the completion CSV data.

                   SCOPE: every user in a program that contains courses, where completion data
                   for those courses is being uploaded via the course completion tool

    T-13297        Fixed the Program is live warning while editing Programs when audience visibility is enabled
    T-12640        Fixed issue with many text fields in large appraisals and feedback360

                   Added support for large tables when using MySQL 5.5 or later. Database
                   servers need to be configured to use the new Barracuda database format and
                   one file per table setting. Existing database tables are not fixed during
                   upgrade, use admin/cli/mysql_compressed_rows.php to fix existing
                   installations.

                   PostgreSQL and MS SQL servers are not affected.

    T-12515        Fixed parameter names for manager rules in Dynamic Audiences

API Changes:
    T-12906        Fixed links to embedded reports in My Reports

                   Added new public property 'url' to every $report object


Release 2.5.19 (30th September 2014):
==================================================

Security issues:
    MoodleHQ       http://docs.moodle.org/dev/Moodle_2.5.8_release_notes

Bug Fixes:
    T-12878        Fixed course enrolment checks to take audience visiblity into account
    T-13219        Fixed undefined index error when caching user report
    T-13063        Removed excess obsolete entries from cohort rule table
    T-13107        Fixed Facetoface Reminder notifications being sent to to cancelled users
    T-13155        Fixed launch of SCORMs using simple popup display mode in certain languages
    T-13148        Fixed scalability of appraisals and Facetoface upgrade script for large numbers o f deleted users
    T-12835        Fixed quiz activities sending blank messages
    T-12682        Fixed reportbuilder export to PDF compatibility with IOS devices.
    T-12989        Fixed reportbuilder caching for reports containing columns with incorrectly formatted date/time data
    T-12940        Fixed the behaviour around selecting recipients while sending messages to users on a Facetoface session
    T-13010        Fixed the user join in Facetoface attendance exports
    T-12977        Fixed Facetoface notification emails when there are scheduling conflicts
    T-10554        Fixed reportbuilder reports for old (2.2) and new Assignment modules
    T-13007        Fixed creation of dynamic audience rules with empty parameters
    T-13178        Fixed column grade not showing in courses report when uploading course completion records
    T-13197        Fixed certification link in ROL pointing to required learning
    T-13205        Fixed Program exceptions count methods incorrectly including deleted users
    T-13194        Increase uniqueness of param keys for audience rules
    T-13196        Changed reportbuilder capability check to use the user:viewalldetails capability
    T-12987        Fixed overwriting a users existing 'Auth' field with totara sync

API Changes:
    T-12713        Enforce unique property if set when importing user custom profile fields with Sync


Release 2.5.18 (2nd September 2014):
==================================================

Improvements:
    T-12735        Improved scalability for the program management page
    T-12943        Improved debugging on Audience rules tab

API Changes:
    T-12921        Changed generator class inheritance to resolve conflicts with PHP5.5

Bug Fixes:
    T-12917        Fixed wording of breadcrumbs when viewing learner details as a manager
    T-11854        Fixed error adding courses to Learning Plans when Audience Visibility is enabled
    T-12464        Added error messages when importing course completion records with different grade on same day, user and course
    T-12872        Fixed Appraisal Stages so they can be completed on the final due day
    T-12890        Fixed Totara Sync to allow spaces in directory paths
    T-12775        Disabled incorrect trust text usage
    T-12511        Fixed get_roles_involved sql query when previewing an appraisal
    T-12910        Fixed required parameter checks on the edit scheduled reports page
    T-12767        Fixed backup and restore of Facetoface sessions without rooms
    T-12799        Fixed filtering of course name through multilang filter for Certificates
    T-12880        Fixed database error when deleting Programs
    T-12576        Fixed the handling of dates with a zero value in Reportbuilder filters
    T-12904        Fixed Totara Sync to allow @ in directory paths
    T-12445        Fixed URL encoding in Hierarchies
    T-12829        Fixed error on cron when a certification does not contain any courses
    T-12893        Fixed the TinyMCE Editor fullscreen mode on IE8


Release 2.5.17 (5th August 2014):
==================================================

Security issues:
    T-12633        Fixed an issue with the session data when viewing/downloading a Certificate
    T-12632        Fixed an issue with token access for external Feedback360 requests
    T-12634        Fixed an issue with file downloads in Feedback360 and Appraisals
    T-12745        Improved capability checks around Reportbuilder scheduled reports
    T-12619        Improved sesskey checks throughout the system

Improvements:
    T-12693        Improved validation checks around retrieving Programs within a category
    T-12311        Added checks for Program availability to the Program catalog
    T-12522        Instantly update program assignments if affecting less than 200 learners
    T-12561        Increased the maximum length of Hierarchy scale names and values for use with the multi-lang filter

Bug Fixes:
    T-11556        Fixed resolving Program exceptions through setting a realistic time allowance
    T-12487        Fixed the type of assignment set when uploading completion records for Certifications
    T-12799        Fixed filtering of course name through multi-lang filter for Certificates
    T-12742        Fixed the downloading of a Badge image
    T-12760        Added the default database collation in all tables including temporary tables


Release 2.5.16 (23rd July 2014):
==================================================

Security issues:
    MoodleHQ       http://docs.moodle.org/dev/Moodle_2.5.7_release_notes
    T-12579        Fixed potential security risk in Totara Sync when using database sources

Bug Fixes:
    T-12668        Fixed programs potentially appearing multiple times in a users required learning
    T-12675        Fixed the ordering of completion criteria for course completion reports
    T-12691        Fixed the sending of Stage Due messages in the Appraisal cron
    T-11883        Fixed the multilang filter for goal and competency scales
    T-12672        Fixed Totara Sync deleting users with no idnumber set
    T-12720        Fixed an issue with filtering messages by icon in the Alerts block
    T-11938        Fixed an issue with the 'set completion' link when assigning a position to a program
    T-12737        Fixed the description for the Enable Audience-based Visibility setting
    T-12678        Fixed errors when using Totara Sync with database sources when position dates are text fields
    T-12658        Fixed capabilities of Site Manager to enable them to create hierarchy frameworks


Release 2.5.15 (8th July 2014):
==================================================

Improvements:
    T-12547        Added validity checks to the position assignments form
    T-12497        Improved internationalisation for the display of audience rules
    T-12527        Added username of creator to Facetoface report and improved logging of attendees actions

Database Upgrades:
    T-12546        Fixed issues with facetoface upgrades caused by orphaned facetoface notification sent records
    T-12578        Added the ability to continue appraisals with missing roles

Bug Fixes:
    T-12203        Fixed reaggregation of Competencies when the aggregation type is changed
    T-12657        Fixed the padding for the body element in Internet Explorer
    T-12324        Fixed the formatting of date fields in Excel exports
    T-12488        Removed Dynamic Audiences from the 'add to audiences' option in bulk user actions
    T-12538        Fixed category drop down selector not working correctly when creating programs in Internet Explorer
    T-12097        Fixed issues with the Program content tab when javascript is disabled
    T-12480        Fixed issue with including a competency's linked courses in a learning plan
    T-12451        Fixed the sort order of course dependencies in the course completion form
    T-12567        Fixed the starting of new attempts for completed SCORMs which open in a new window
    T-12545        Fixed deletion of associated data when deleting a facetoface notification
    T-12521        Fixed dynamic audiences not updating if the cohort enrolment plugin is disabled
    T-12570        Fixed the sending of Program messages to the wrong users when completion is set relative to an action
    T-12489        Fixed an issue with expanding a scorm activity from the navigation block in a course
    T-12512        Fixed problems with column generators in the Appraisal Detail report
    T-12616        Fixed manager columns for the Program Overview report
    T-12572        Added check to ensure generator columns can not be added to the same report multiple times
    T-12623        Fixed the "view all" link in the record of learning and required learning sidebar
    T-12519        Fixed the pagination of the catalog for Certifications
    T-12465        Fixed duplicate records issue when importing more than 250 course completion records
    T-12524        Fixed the default facetoface reminder notifications failing to send
    T-12498        Fixed the display of custom field names for rules in Dynamic Audiences
    T-11883        Fixed the multilang filter for goal and competency scales


Release 2.5.14 (10th June 2014):
==================================================

Improvements:
    T-12494    Added ability to edit/delete evidence items created through course completion upload - Requires role with totara/plan:accessanyplan or totara/plan:editsiteevidence capabilities

Bug Fixes:
    T-11816    Fixed display of Articulate Storyline SCORMs for iPads - Adds new display setting of "Popup (simple)" to be used on Articulate SCORM packages
    T-12484    Fixed missing global declaration in certificate_get_date_completed function in mod/certificate
    T-12263    Fixed type filter javascript in Audience visible learning tab
    T-12239    Fixed debug warning on Audience visible learning tab
    T-12239    Fixed assigning of certifications on Audience visible learning tab
    T-12455    Fixed display of search results on Audience visible learning tab
    T-12510    Fixed language strings where Audiences are still referred to as Cohorts
    T-12278    Fixed Facetoface attendance export to show users who do not have a manager
    T-12320    Fixed Facetoface iCal attachment line breaks
    T-12469    Fixed sending of Facetoface notifications when a session date/time is changed
    T-12034    Fixed sending of Facetoface notifications where messages were not sent to every user in a session
    T-12471    Fixed display of grade percentage in course completion reports for uploaded course completion records
    T-12513    Fixed display of appraisal status column from number to readable text on Appraisal Summary report
    T-11887    Fixed errors when viewing Appraisals after an assigned learner or manager has been deleted
    T-12242    Fixed file saving on scheduled reports when "Export to filesystem" is disabled at site level
    T-12482    Fixed sending of multiple reminder messages when certification window closes


Release 2.5.13.1 (29th May 2014):
==================================================

Security Fixes:
    T-12441    Fixed potential XSS vulnerability in quicklinks block

Improvements:
    T-12433    Show names of participants in Appraisal overview and snapshots

Bug Fixes:
    T-12463    Fix critical SCORM error where subsequent attempts after an initial failed attempt are not recorded
    T-12326    Extend execution time limit on recovering lost course completion criteria data from activity completion records
    T-12202    Fix issue where some dialog boxes can become non-modal in Appraisals
    T-12444    Fix for the course completion import report sometimes returning zero records
    T-12121    Fix transaction error when quiz completion triggers sending of messages
    T-12277    Fix Face-to-face reminders still being sent to users who have cancelled from a session


Release 2.5.13 (14th May 2014):
==================================================

Security Fixes:
    MoodleHQ    http://docs.moodle.org/dev/Moodle_2.5.6_release_notes

Improvements:
    T-12201    Improve clarity of Audience Visibility language strings

Bug Fixes:
    T-12068    Fix reset of choice activity in certifications so course can be taken again when recertification opens
    T-12246    Fix course completion data reset for all users if a course is used as content in a certification
    T-12326    Recover lost course completion criteria data from activity completion records
    T-12286    Fix redirect of course page when SCORM opened in pop-up window
    T-12254    Fix sort order of Facetoface attendees and requested users in Feedback360
    T-12301    Fix Facetoface iCal attachments not being deleted from server after sending
    T-12196    Remove Facetoface iCal attachments from manager's email
    T-12313    Remove request approval button in Learning Plans while request is pending


Release 2.5.12.1 (7th May 2014):
==================================================

Bug Fixes:
    T-12280    Fix critical error causing deletion of course completion criteria data
    T-12159    Fix link to Release Notes forum on Notifications page
    T-12153    Fix the setting of users timecreated field when new users are created by Totara Sync
    T-12160    Fix breadcrumbs when a manager views a Record of Learning of one of their staff
    T-12198    Fix undeclared tag variable in wiki activity
    T-12204    Fix incorrect error message being displayed when uploading large files


Release 2.5.12 (15th April 2014):
==================================================

Improvements:
    T-12084    Added event triggers to program creation, updates and deletions
    T-12037    Added column headers to Upcoming Certifications Block
    T-12079    Made print_linked_evidence_list function reusable

Bug Fixes:
    T-12086    Move already-approved waitlisted users directly onto a Facetoface session when a space becomes available
    T-12142    Removed execution limit and increased available memory when exporting Report Builder reports
    T-12072    Fixed undefined variables when exception is thrown in Report Builder
    T-12118    Fixed issue where there was a horizontal scrollbar on the grader report screen
    T-12089    Fixed bad references in database foreign keys causing problem when upgrading
    T-12101    Fixed encoding issue in Facetoface email notifications
    T-11799    Fixed completion logic error when using grade and status in SCORM activities
    T-11914    Fixed sending thirdparty emails to the wrong users in Facetoface
    T-12128    Fixed links on Windows servers for uploaded files with filenames in non-Latin alphabets
    T-12115    Fixed PHP warning when importing users via cron and suspended field is not configured for import
    T-12113    Fixed learners being able to access courses in a Program courseset that is not open to them yet
    T-11912    Fixed incorrect America/Indianapolis timezone
    T-11989    Do not approve/decline facetoface signup requests that have already been dealt with
    T-12102    Fixed display of saved searches in Report Scheduler
    T-12082    Fixed issue with showing a user's own records on the Record of Learning evidence tab
    T-12085    Fixed duplicate key error when importing course completion


Release 2.5.11 (1st April 2014):
==================================================

Security Fixes:
    T-11770    Only display users email address in Totara dialogs if settings allow it
    T-11998    Removed security-risk YUI libraries that are no longer used

Improvements:
    T-9899     Removed 8-hour restriction so cron and scheduler work properly in Totara Sync

Bug Fixes:
    T-12076    Fixed 'Approval Required' tab for admin accessibility if admin is not a manager
    T-12074    Fixed 'usernotfound' error string in Learning Plans
    T-12046    Fixed Facetoface error when upgrading to 2.5.10 from earlier branches
    T-11986    Fixed recipients validation in send_to_users function when sending emails in Facetoface
    T-12047    Fixed the Required Learning page not always displaying certifications as expected
    T-12050    Fixed typo in the Audience Management ruleset
    T-12049    Fixed required learning using the wrong date for certifications due date
    T-12041    Fixed undefined method when searching for a program/certification
    T-11945    Fixed issue with 'SCORM format' courses when popup window is closed. Note that this fix may require clearing the Moodle cache and user browser caches


Release 2.5.10 (18th March 2014):
==================================================

Security Fixes:
    MoodleHQ   http://docs.moodle.org/dev/Moodle_2.5.5_release_notes
    T-11970    Fixed defaults on upgrade settings page when execution paths are disabled
    T-11770    Only display users email address in Totara dialogs if settings allow it

Improvements:
    T-11936    Empty categories are no longer displayed when audience visibility enabled
    T-11902    Improved performance of course import functionality for large sites
    T-11877    Added an approval requested notification to the Facetoface sign up page if manage approval is required
    T-11722    Made org and pos content restrictions consistent across report sources
    T-11904    Improved performance of sql query deleting orphaned message metadata

Bug Fixes:
    MDL-44547  Fixed incorrect version bump on Alfresco Repository plugin
    T-10473    Fixed issues with scheduled report builder reports timing when sending across multiple timezones
    T-11958    Fixed completion duration rules in Audiences
    T-11960    Fixed issue when upgrading from 2.4 to 2.5 and isfilter field doesn't exist
    T-11959    Added the right default values to the 'Default' label in Facetoface calendar filters settings
    T-10159    Ensure course completion is turned on by default on installation
    T-11838    Allowed position assign/start/end date rules to be used without position set
    T-11953    Fixed issue with Program Completion rule in dynamic Audiences
    T-11941    Global $CFG variable is now set in print_totara_user_profile function
    T-11913    Fixed a tinyMCE layout issue in the 'Standard Totara Responsive' theme
    T-11868    Fixed default capabilities allowing everyone to set their own temporary manager
    T-11881    Feedback activity is now reset correctly when feedback hasn't been submitted but activity is still complete
    T-11648    Ensure face to face activity completion is marked as soon as activity is complete
    T-11937    List of audiences is now filtered by context
    T-11952    Removed unnecessary tooltips to prevent secure content warning
    T-11934    Fixed 'page not found' exception when marking courses as complete via RPL
    T-11817    Fixed the 'Unlock completion criteria' option deleting RPL completion records
    T-11572    Raised MSSQL environment check to 2008
    T-11908    Fixed completion tracking when assigning courses to an Audience
    T-11638    Fixed issue with multiple "Show editing tools" tabs appearing in TinyMCE
    T-11849    Fixed Facetoface notifications being sent to all booked recipients when 'No shows only' option is selected
    T-11863    Fixed Facetoface notifications not being sent to managers when users choose not to receive notifications


Release 2.5.9 (4th March 2014):
==================================================

Improvements:
    T-11874    Enabled multimedia filter in Appraisal stage descriptions and fixed-text questions

Bug Fixes:
    T-11344    Fixed RPL not marking activities as complete
    T-11855    Deleted users are now excluded when certification stages are calculated
    T-11739    Fixed the handling of non UTF-8 encoded file uploads in Totara Sync
    T-11865    Fixed 'In progress' state not being set in certifications when cron is run
    T-11869    Fixed parameter validation for tm_message_send in Messaging
    T-11843    Fixed the wrong date being set in the firstaccess field when users first log in
    T-11886    Fixed the manage feedback link in the site administration block checking appraisals capabilities
    T-11665    Tasks and alerts blocks now respect the "show blocks when empty" setting
    T-11880    Fixed header tabs wrap when screen resolution is between 769px and 1050px
    T-11875    Fixed program assignment completion relative to program enrolment
    T-11831    Fixed PHP notice for Feedback Summary report in Report Builder
    T-11838    Fixed position start date rule in dynamic Audiences
    T-11836    Fixed wrong csv encoding type being set when uploading completion records for Courses/Certifications
    T-11860    Fixed a missing setType in report export form
    T-11857    Fixed Facetoface notification templates not saving 'Manager copy' and 'Status' values
    T-11797    Fixed nullability of positionid field in prog_pos_assignment to prevent errors on upgrade from 1.1 to 2.2
    T-11832    Fixed 'Set time relative to event' option not saving different instances of the same event
    T-11848    Fixed Facetoface room booking when one session finishes and other starts at the same time
    T-11833    Fixed issue where core totara themes weren't referencing image.php correctly
    T-11846    Fixed permissions checks on the Facetoface attendees page


Release 2.5.8 (18th February 2014):
==================================================

Security Fixes:
    T-11765    Set lockout threshold by default to help protect against brute force password attempt

Improvements:
    T-11596    Added capability to filter by some default fields in Facetoface calendar
    T-11780    Marked expired certifications due date as overdue
    T-11828    Avoided ajax call when changing rules in Audience that use radiobuttons
    T-11722    Made org and pos content restrictions consistent across report sources
    T-11786    Improved appearance of tables with headers/toolbars in responsive theme
    T-11506    Added Time signed up to attendees tab for Facetoface

Bug Fixes:
    T-10885    Fixed Learning Plan enrolment plugin to ensure it enrols learners in course
    T-11777    Allow wait-listed users to cancel Facetoface bookings if session is over or in progress
    T-11237    Fixed drop down list forgetting previously saved values in program/certification assignments
    T-11392    Fixed second level tabs overlapping the following text in Kiwifruit theme
    T-11815    Fixed fatal error when grading a quiz triggers completion notification messages
    T-10488    Fixed "reports to manager" Audience rule
    T-11677    Ensure parent page refresh to start completion checks when SCORM opens as popup
    T-11755    Fixed course completion upload when multiple records for one user exist in CSV file
    T-11825    Fixed appearance of popup windows in Kiwifruit theme
    T-11826    Fixed issue where tabs could appear above modal dialogs
    T-11798    Remove suspended users from any prior Facetoface bookings
    T-11791    Fixed issue where menu button didn't display the menu correctly on the iPhone in Totara responsive theme
    T-11308    Made extra-field aliases unique to avoid name collisions in Report Builder
    T-11793    Re-added program administration, course reminders, and course competencies navigation
    T-11784    Fixed issue where the Custom Totara theme wasn't inheriting the base renderer
    T-11802    Fixed Customtotara Theme issue where certain background colours could make headings hard to read
    T-11789    Added missing user fields to RoL Certification and Program report sources
    T-11795    Fixed issue with notice dialog buttons in Totara responsive theme
    T-11790    Fixed incorrect embedded url in RoL Programs Completion History report


Release 2.5.7 (4th February 2014):
==================================================

Security Fixes:
    T-11785    Cleaned modulename parameter before generating coursemodule instances
    T-11783    Added missing validation when exporting calendar
    T-11782    Added missing validation when managing user tags
    T-11766    Prevent admins editing system paths without a specific config setting in new installs only

Improvements:
    T-11746    Changed the totara sync behaviour around user passwords, see here http://community.totaralms.com/mod/forum/discuss.php?d=3708

Bug Fixes:
    T-11787    Fixed typo in facetoface session to show finish date properly
    T-11639    Fixed the display of tab trees containing a second row
    T-11775    Prevent new "Before Session" facetoface notifications from being sent retroactively
    T-11772    Fixed fatal error on completion with multiple dependant courses
    T-6072     Fixed whitespace formatting for CLI installs
    T-11729    Timezone information is now displayed for Facetoface sessions in the calendar
    T-11764    Fixed display of custom field names when multi-language filter is enabled in reportbuilder
    T-8008     Fixed staff manager capabilities on new installs
    T-11366    Fixed delete buttons after adding users to feedback360
    T-11781    Excluded suspended users from facetoface booking selector
    T-11776    Fixed Responsive Theme issue when adding rules to an audience
    T-11778    Fixed language string escaping on Program Assignments tab

API Changes:
    T-11779    Moved tables header code to totaratablelib.php


Release 2.5.6 (21st January 2014):
==================================================

Security Fixes:
    MoodleHQ   http://docs.moodle.org/dev/Moodle_2.5.4_release_notes

Improvements:
    T-10159    Course completion is now turned on by default on an upgrade from Moodle
    T-11736    Made Facetoface session date/time display on course page more logical
    T-11742    Added setting to override current course completions in course imports
    T-11735    Made the view sessions link inactive when the activity is unavailable to learners
    T-11743    Added human-readable text version of hierarchy paths in reportbuilder reports

Bug Fixes:
    T-11641    Fixed hardcoded string in required learning when program uses "or" coursesets
    T-11754    Fixed the display of grades in the Course Completion Report for courses completed via RPL
    T-11748    Fixed open recertification windows always being marked as overdue
    T-11760    Prevent deleted users' assignments from being synced
    T-11758    Fixed facetoface attendees exports and formatting of datetime custom fields
    T-11221    Fixed recurring courses copying grades into a new course
    T-11759    Fixed component pagination in Learning Plans
    T-11699    Fixed capability error when teachers click on Other Users in course enrolment
    T-11757    Fixed custom field textareas in reports when field id is greater than 9
    T-11747    Fixed course backup/restore to include the "completionstartonenrol" setting
    T-10346    Fixed managers email being left blank when exporting Facetoface attendance
    T-11656    Fixed permission warnings on some feedback360 capabilities
    T-11021    Fixed RTL issues on Badges pages

API Changes:
    T-11762    Moved positions navigation code out of Moodle Core


Release 2.5.5 (7th January 2014):
==================================================

Improvements:
    T-10914    Added totara settings to hide certain functionalities

Bug Fixes:
    T-11661    Fixed version number in totara core
    T-11527    Fixed config variable not being set when upgrading from an earlier version of Totara 2.4.8 - Affecting rules based on text in dynamic audiences
    T-11726    Allow suspended field in user source to be left blank in Totara Sync
    T-11729    Timezone information is now displayed for Facetoface sessions in the calendar
    T-11709    Fixed certification completion upload when multiple records for one user exist in CSV file
    T-11696    Fixed discrepancy between Facetoface Attendance and Export Attendance Reports


Release 2.5.4 (24th December 2013):
==================================================

New features:
    T-9788    Added "Program enrollment date" event to the program completion criteria options

Improvements:
    T-11669    Made the "Date Created" field editable for learning plans
    T-11703    Expanded help relating to course and program visibility
    T-11708    Added new optional column "preferred language" to reportbuilder user report source

Bug Fixes:
    MDL-34481  Ensure that completion is recalculated on next cron run following changes to completion settings
    T-11725    Backport MDL-43019 to fix IE11 crashes in SCORM
    T-11231    Fixed an issue with certification completion records missing if user is unassigned
    T-11695    Program report source now conforms to audience visibility
    T-11705    Fixed potential call to nonexistent function while updating program assignments
    T-11719    Fixed broken appraisal activation when secondary or aspirational positions are used
    T-11659    Fixed "Goal Assignments" title duplication when assigning a position, organisation or audience
               competency to a goal
    T-11707    Fixed "Assigned Goals" section duplication when adding goals and competencies to an organisation
    T-11607    Fixed dates when importing certifications using the historic import
    T-11710    Fixed the "CC managers" setting for facetoface notifications
    T-11245    Removed hover style in list of courses/programs
    T-11688    Removed link to blogs when they are disabled
    T-11684    Certification completion date is now used for expiry and recertification window calculations
    T-11702    Minor fixes related to visibility of programs and certifications
    T-11713    Fixed completion import when certification shortname contains an ampersand
    T-11674    Fixed user profile date fields being set to 1970 when disabled
    T-11629    Fixed emails not being sent when manually resolving Program exceptions
    T-5879     Fixed typos in English strings in 360 Feedback, Audiences, and Hierarchy
    T-11731    Fixed broken certification unit tests in MySQL with sql_auto_is_null setting enabled


Release 2.5.3 (10th December 2013):
==================================================

Improvements:
    T-11422    Made the audience visibility column editable for Audiences visible learning tabs
    T-11658    Completions upload reports now show all records instead of just errors
    T-11693    Improved required learning courseset operators to allow for longer string translations
    T-11675    Added additional warnings on the archive completions confirmation page

Database Upgrades:
    T-11682    Changed program/certification completion times to be based off course completion
    T-11670    Added coursename variable to facetoface notifications and fixed the labelling of facetofacename variables
    T-11680    Fixed bug where assigning a manager to a secondary position could affect primary positions

Bug Fixes:
    T-11607    Fixed dates when importing certifications using the historic import
    T-11671    Fixed the handling of blank values for date/time custom fields in Totara Sync
    T-11614    Fixed the framework selector for appraisal and feedback360 assignment dialogs
    T-11622    Fixed goal permissions being applied inconsistently
    T-11690    Fixed a string not being translated correctly on the required learning page
    T-11673    Fixed access to reports when site roles have been renamed
    T-11569    Fixed the required course grade for languages using different characters for the decimal point
    T-11687    Fixed textarea and file custom course fields not displaying in report builder
    T-11629    Fixed programs sending duplicate enrolment messages when changing due date between set and relative
    T-11552    Fixed icals not opening automatically in Outlook 2010
    T-11534    Fixed facetoface calendar entries not taking course visibility into account
    T-11657    Fixed role name missing in security overview report
    T-11650    Fixed access to facetoface approvals page with guest access enabled
    T-11608    Fixed "Restrict initial display" option not being applied in embedded reports
    T-11603    Fixed rendering issue in appraisal snapshots
    T-11685    Fixed facetoface notifications form elements not saving when unchecked
    T-11661    Prevent password reuse if rotation limit setting enabled
    T-11681    Fixed ability to view courses within required learning for learners
    T-11672    Fixed hardcoded string in the completion imports success message

API Changes:
    T-11662    Added a database event to delete related position assignments when a user is deleted


Release 2.5.2 (26th November 2013):
==================================================

API Changes:
    T-10928    See http://community.totaralms.com/mod/forum/discuss.php?d=3507 for more details
    T-11651

Improvements:
    T-11594    Improved hidden courses display in course overview block
    T-11537    Added an option to enable/disable Totara sync field in bulk user actions
    T-11634    Added content restriction options to goal and appraisal report sources
    T-11105    Report builder source files are now available in 'Language customisation'
    T-11566    Made 'My Reports' and 'My Bookings' pages editable so that blocks can be added

Bug Fixes:
    T-11606    Added a check to prevent duplicate certification assignments when uploading completion history
    T-11321    Session info is now included in notification emails when Face-to-face details are updated
    T-11505    Fixed error when inserting more than 1000 records into the cohort_msg_queue table for MSSQL
    T-11546    Fixed exceptions if the user is already assigned to program
    T-11647    Removed confirmation message when signing up for Face-to-face session with 'No email' option
    T-11636    Fixed undefined variable warning on course view when Audience visibility is enabled
    T-11621    Fixed image handling in textarea custom fields
    T-11540    Fixed display of minimum time required on required learning pages
    T-10726    Changed page editing to happen via edit button on 'My Team' page
    T-11619    Fixed 'Completion import: Certification status' report URL
    T-11618    Fixed company goals link redirecting to wrong place on 'My Goals' page
    T-11620    Fixed use of MySQL reserved word in database query in Goals
    T-5879     Fixed leading spaces in reportbuilder source language file


Release 2.5.1 (12th November 2013):
==================================================

Security fixes:
    Fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.5.3_release_notes

Improvements:
    T-11456    Improved appearance of heading rows in flexible tables
    T-11449    Improved message when no file selected for custom fields
    T-11604    Moved toolbar above the column headers in totara tables
    T-11581    Only show available databases in Totara Sync external database settings

Bug Fixes:
    T-11616    Fixed goal review questions in appraisals when using postgreSQL
    T-11592    Facetoface session info is shown on the course view page again
    T-11508    Fixed user profile field rules for MSSQL Server
    T-11610    Fixed failing log inputs during program extension requests
    T-11315    Added description and type to the my goals page when showing details
    T-11551    Fixed facetoface signup notification types
    T-10444    Fixed reminderperiod substitution which was not occurring in face to face notifications
    T-11588    Excluded suspended users from all user selectors
    T-11590    Fixed character escaping in feedback360 and appraisals assignments javascript setup
    T-11574    Fixed error when upgrading via command line
    T-11575    Added new completion setting fields to course backup/restore
    T-11558    Deleted users are once again shown on browse list of users page
    T-11579    Fixed permissions for managing course custom fields
    T-11567    Fixed javascript error on notification page
    T-11599    Changed button icon for topics add/remove sections in courses
    T-11582    Fixed 'Standard Totara Responsive' theme problem when using upload completion records options
    T-11559    Prevent people requesting 360 feedback from suspended users
    T-11533    Cleaned up course_modules_completion table when course id deleted
    T-10832    Fix icon picker to account for slash arguments setting
    T-11571    Fixed fatal error on request feedback page when javascript is turned off
    T-11583    Fixed upgrade from Totara 2.4 to Totara 2.5 when a site has external backpacks connected
    T-11479    Only show delimiter selector on CSV sources in Totara Sync
    T-11564    Fixed format hint string next to date pickers on audience editing page

API Changes:
    T-11560    Removed optional $certifpath param from course_set and multi_course_set class constructors


Release 2.5.0 (31st October 2013):
==================================================

Initial release of Totara 2.5

Totara 2.5 introduces the following new features:

* Performance Management
  * Create company wide and personal goals and track progress towards
    meeting those goals.
  * Create custom appraisal forms and assign them to groups of users.
  * Track appraisal progress with summary and detailed reports.
  * Create 360 feedback forms and assign them to groups of users.
  * Allow users to monitor 360 feedback they have received.
    (thanks to GKN and BMI for part funding this work)

* Certifications
  * Ability to create "Certifications", which are Programs that can expire
    after a set time and can be retaken.
  * Manage expiration periods and recertification windows.
  * Supports recertification paths when recertification involves completion
    of a different set of courses to the original certification path.
  * Ability to reset certain activities within courses to support the same
     user taking a course multiple times.
  * A course completion history report which shows previous completion attempts.
  * Course completion import tool for uploading legacy completion data.
    (thanks to BMI for funding this work)

* Audience Visibility
  * Provides an alternative way of managing course and program visibility across
    the whole site.
  * Allows courses and programs to be made visible and accessible to specific
    audiences only.
    (thanks to Kineo US and Kohls for the original patch and Learning Pool for help
    with integration)

* Course catalog changes
  * Changes to the appearance of the course catalog to integrate recent improvements from
    Moodle.

* Manager Delegation
  * Allows a user's manager role to be temporarily delegated to another user.
  * A time limit determines when the temporary assignment is automatically revoked.
    (thanks to Catalyst IT for the original patch)

* Program Progress report source
  * View program completion status and the course completion status of each individual
    course that makes up the program in a single integrated report.
    (thanks to Catalyst IT and Bodo Hoenen from Social Learning Project for the original patch)

* Report builder PDF export
  * All report builder reports now include the option to export to PDF in either
    portrait or landscape mode.
    (thanks to Michael Gwynne from Kineo UK for the original patch)

* Customisable report builder filter names
  * Report creators can customise the names of filters which controls the label
    that appears next to the filter on the report page.

* Relative date support in report builder date filters
  * Report builder date filters now allow relative date ranges such as
   "in the last 3 days".
    (thanks to Jamie Kramer from E-learning Experts for the original patch)

* Instant course and program completion
  * Instead of waiting for the hourly or daily cron, course and program completions
    are now calculated instantly.

* Email notification settings in Totara Sync
  * Administrators can receive emails when there are warnings or errors during
    syncing.

* Experimental Responsive Totara theme for mobile devices
  * A new Totara theme based of the 'bootstrap' base theme designed to scale the
    site to work on any device size.
    This theme is still experimental at this stage, we plan to improve it via 2.5
    point releases and fully support it in Totara 2.6.

* New option to mark face-to-face activity completion based on signup status rather
  than grade. Note: This option also uses the session time as the completion date for
  course and activity completion (rather than the time attendance is marked).

* More minor improvements including:
  * T-11182 New capabilities for managing hierarchy scales.
  * T-11493 New capability for managing write access to idnumber field.
  * T-10930 More fine-grained control over create/update/delete actions within Totara sync.
  * T-11049 Make all program messages optional.
  * T-9833  Improved styling of program management pages.
  * T-11387 Added new web service to store mobile device data for push notifications.

This release updates Totara to be based on Moodle 2.5, which includes the following improvements:

* New admin tool for installing add-ons.
* Transparency and RGB support in the themes colour picker.
* Collapsable form sections to improve the usability of large forms.
* Reduced the size of description fields and simplified the default editor.
* Search the list of users enrolled in a course.
* New assignment settings for handling resubmissions.
* Option to auto-save during quiz attempts.
* Option to drag and drop media files or text onto a course page to create a label.
* Option to display course summary files in course listings.
* View and edit catalog now separated.
* Performance improvements, particularly greater use of the Moodle Universal Cache (MUC).
* Improved security of hashed passwords (Totara contribution to Moodle).
* New user account lockout mechanism.
* Behat test framework integration.
* Progress indicator when dragging files into the filepicker.

For more details on the Moodle changes see:

http://docs.moodle.org/dev/Moodle_2.5_release_notes
http://docs.moodle.org/dev/Moodle_2.5.1_release_notes
http://docs.moodle.org/dev/Moodle_2.5.2_release_notes

See INSTALL.txt for the new system requirements for 2.5.


2.5 Upgrade notes:
==================

2.5 introduces a new, more secure password hashing scheme. If you are upgrading from 2.4 via the web interface ensure
you are logged into you 2.4 site as a site administrator prior to replacing the codebase.

As always make sure you replace the whole code directory rather than copying 2.5 files on top of the 2.4 code. See
UPGRADE.txt for more details.


2.5 API Changes:
================

* Moodle API changes as detailed in http://docs.moodle.org/dev/Moodle_2.5_release_notes#For_developers:_API_changes
* T-11133 Kiwifruit theme will no longer display totara menu bar or breadcrumbs until you are logged in.
* T-11202 Unenrolling users from a course will unenrol them from any future face to face courses they were booked in.
* T-11258 Code changes to the way embedded reports are set up - see comments in the reportbuilder class constructor.
* T-9833  Changes to code to support improved styling of program management. Custom themes may need updating.
* T-11493 Enforcing uniqueness on most 'idnumber' fields (All totara ones plus the user idnumber from Moodle). You
*         will not be able to upgrade to 2.5.0 if you have any duplicates in existing sites.
* T-10878 Removed a number of unused database fields and tables.
*         Removed unused functions organisation_backup() and related functions.
*         Remove unused $exceptiondata argument from insert_exception() and raise_exception() functions.
* T-11182 Added new hierarchy scale capabilities and reworked existing hierarchy capability checks to make them more
*         independent of each other.
* T-10107 New optional arguments in totara_cohort_add_association(), totara_cohort_delete_association() and
*         totara_cohort_get_associations() to support audience visibility.
*         Updated totara_cohort_check_and_update_dynamic_cohort_members() to use progress_trace object instead of
*         boolean verbose flag.
*         Removed unused function totara_print_main_subcategories().
* T-9833  Added optional $fieldset argument to totara_add_icon_picker() to allow icon picker without separate fieldset.
* T-9390  New optional arguments on totara_get_manager() to support more options related to temp managers.
* T-11158 Changed 2nd argument of totara_get_category_item_count() from bool to string to support certifications.
*         Added $certifpath argument to get_total_time_allowance() and get_courseset_groups().
*         Added optional $iscertif and $certifpath arguments to get_content_form_template().
*         New $certificationpath argument to display_edit_assignment_form().
*         Renamed incorrectly named $userpic argument to $user in display_user_message_box().
* T-11182 Add 2 new permission related arguments to customfield_edit_icons().
*         Removed unused 2nd argument from competency_scale_display_table().
* T-11309 Added $type argument to prog_get_programs().
*         Added $type argument and removed two $where arguments from prog_get_programs_search().
* T-11102 Removed unused functions prog_print_programs(), prog_print_program(), prog_print_whole_category_list(),
*         prog_print_category_info(), prog_print_viewtype_selector() and print_program().
* T-11279 get_competency_courses() function visibility changed from private to public.
* T-11049 Add $newprogram boolean argument to prog_messages_manager class constructor.
*
*/
?>
