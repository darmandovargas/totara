<?php
/*

Totara LMS Changelog

Release 2.9.9 (26th July 2016):
===============================


Important:

    TL-9703        This release contains fixes made in Moodle 2.9.9

                   Moodle 2.9.9 received five fixes as noted below:

                   1. MDL-53431 tool_monitor: Access control for tool monitor subscriptions
                      Imported as TL-9551
                   2. MDL-55069 core: escape special characters in email headers
                      Imported as TL-9515
                   3. MDL-53019 environment: 3.2 requirements added
                      Imported as TL-9556
                   4. MDL-54564 behat: Wait after hover, to ensure page is ready
                      Imported as TL-9631
                   5. MDL-54620 ratings: display '0' when aggregate = 0
                      Imported as TL-9633


Security issues:

    TL-9340        Fixed access control when deleting calendar subscriptions

                   Users can only delete their own calendar subscriptions.
                   Previously it was possible to craft a special request that would allow you
                   to delete a calendar subscription regardless of whether you were the owner
                   or not.
                   The moodle/calendar:manageownentries capability is now consistently
                   checked.

    TL-9400        Fixed access control when deleting personal goals

                   A user's personal goals can only be deleted if one of the following
                   conditions is true for the current user:

                   1. They have the totara/hierarchy:managegoalassignments capability in the
                   system context.
                   2. They are a manager of the goal's owner and they have the
                   totara/hierarchy:managestaffpersonalgoal capability in the users context.
                   3. It is one of their own personal goals and they have the
                   totara/hierarchy:manageownpersonalgoal capability in the system context.

                   Previously it was possible to craft a special request that would allow you
                   to delete any personal goal, regardless of whether it was one of your
                   personal goals or not.
                   The relevant capability checks are now consistently applied.

    TL-9515        Fixed sanitisation of user's firstname and lastname when sending emails

                   Totara was not previously sanitising the users firstname and lastname
                   correct when compiling emails to the user.
                   An authenticated user could therefor alter their firstname or lastname in
                   Totara to contain invalid content including additional email addresses.
                   As their firstname and lastname was not being correctly sanitised this
                   could be abused to send spam to others.
                   The users firstname and lastname is now properly sanitised.

                   References MDL-55069

    TL-9668        Improved the security of all repository plugins

                   Previously it may have been possible to perform SSRF attacks on a server
                   through the repository API which was not working with installed repository
                   plugins to sanitise downloaded content.
                   With this update comes a change to the repository API that allows it to
                   work with the repository plugins to ensure that content requested for
                   download is expected and valid.
                   By default any plugin which attempts to use the repository API to download
                   content without implementing the now required get_file() method will stop
                   working as this is deemed a security risk.
                   We are aware that some subscribers do use third party repository plugins,
                   and that this change may stop those plugins from working.
                   Whilst it is our recommendation for those sites to get the affected third
                   party repositories updated to support the new API and downloading of files
                   we have also in 2.9 added a special setting to bypass the lacking support
                   and allow the plugins to function as they once did.
                   This setting is present in 2.9 only and will not be available in 9.0.
                   To enable this setting add the following to your config.php:
                   {code}
                   $CFG->repositoryignoresecurityproblems = 1;
                   {code}
                   Please be aware that adding this setting may open a security hole on your
                   site.
                   We do not recommend adding it.

Improvements:

    TL-8996        Added support for syncing a user's image during SSO login
    TL-9221        Added the ability to resolve dismissed program exceptions to the completion editor

                   The Program and Certification completion editors now display information
                   about dismissed program exceptions when viewing a user's completion data,
                   and allow dismissed exceptions to be overridden.

    TL-9265        Added a new filter for Audience Visibility to Course reports

                   Previously a Visibility filter could be added to Course reports, however
                   there was no corresponding Audience Visibility filter for those sites that
                   had Audience Visibility turned on.
                   A new Audience Visibility filter has been added to all Course reports so
                   that those sites that have Audience Visibility turned on can filter by the
                   relevant visibility options.

    TL-9276        Improved the description of Global Report Restrictions when only one restriction exists

                   If there is only one Global Report Restriction for a user it is
                   automatically applied for that user.
                   This was previously undocumented.
                   The description within the Global Report Restriction user interface has
                   been improved to elude to this behaviour.

    TL-9314        Improved the information shown when viewing a Certification

                   When a user views one of their certifications, they will see a more verbose
                   description of the status.
                   It is now clear when a user is not required to work on a certification.
                   When working on a specific certification path, only courses in that path
                   are shown (as before), otherwise both paths are shown, rather than trying
                   to show the last path completed (which cannot be calculated under several
                   circumstances).

                   Additionally, a warning has been added, and is shown when the user is due
                   to recertify but the window opening process has not yet occurred.

    TL-9344        Improved the time allowance strings used for Programs to ease translation
    TL-9378        Ensured that goal management capabilities are consistently applied

                   Personal goals created by either a site administrator or a user's manager
                   cannot be edited or deleted by the user.
                   Additionally the action icons for actions you can't preform are now greyed
                   out.

    TL-9383        Improved the performance of sidebar searches within Report Builder

                   For reports which had multi-check filters enabled in the sidebar, such as
                   in the course catalog, item counts shown in the filter were sometimes being
                   queried twice unnecessarily.
                   In cases where there were thousands of items, this had a noticeable effect
                   on performance.
                   These items counts are now only queried once, and only if needed.

    TL-9433        Developers may now disable editor autosave in forms where it is not desirable

                   Previously it was not possible for the developer to disable autoasaving
                   within an editor when defining a form.
                   A small improvement has been made to allow the developer to pass
                   ['autosave' = false] as an editor option, this gets passed through to the
                   editor initialisation and allows the developer to disable autosaving when
                   defining the form.

    TL-9456        Plugins can now define Report Builder filters within the plugin space

                   If is now possible for plugins to define their own Report Builder filters
                   for use within their own Report Sources.
                   In order to do this the plugin defines an class called
                   `rb_filter_"filtertype"` in a location it chooses, and then requires the
                   file containing the class within the Report Builder sources that will use
                   it.

    TL-9483        Fixed Behat file uploads to work in all browsers and in remote selenium instances
    TL-9484        Added a workaround for missing alert confirmation support in PhantomJS
    TL-9502        The Course and Activity completion reports now use the standard paging control

                   The Course completion and Activity completion reports now use the standard
                   paging control bar.
                   This helps bring the look and feel of these reports (which are not Report
                   Builder reports) inline with the other reports available in the system.

    TL-9556        Environment definition updated to reflect Moodle 3.2 requirements
    TL-9670        Course visibility filters show as not applicable depending on the sites audience visibility setting

Bug fixes:

    TL-7907        Fixed manager approval for Face-to-face direct enrolment when automatic signup is enabled

                   Previously if you had a Face-to-face activity that was configured to
                   require manager approval, within a course with a Face-to-face direct
                   enrolment instance added and configured to automatically sign new users up
                   to all available sessions, then when a new user signed up they would be
                   automatically booked to the session requiring manager approval, bypassing
                   the approval stage.
                   Now the Face-to-face direct enrolment plugin, with automatic signup
                   enabled, correctly respects the manager approval requirements for available
                   sessions.

    TL-8179        Program and Certification reports now order courseset data correctly

                   The Program and Certification overview reports now ensure that columns
                   displaying courseset information order the content in the same manner that
                   is applied when viewing the Program or Certification content.

    TL-8555        Recurring courses now respect the tempdir setting

                   When recurring courses were copied during cron, it was assumed that the
                   temp folder was set to its default rather than what was in the 'tempdir'
                   config setting. The temporary backup folder is now created in the location
                   specified by the 'tempdir' setting.

                   This fix also ensures that the copy recurring courses cron task will run
                   when certifications are disabled, but programs are enabled, as recurring
                   courses can only be used within programs.

    TL-8601        Fixed backup and restore of multi-select and file type Course custom fields
    TL-8985        Suspending a user no longer cancels past Face-to-face signups

                   Previously if you suspended a user any Face-to-face signups they had made
                   would be cancelled. Even when the Face-to-face session had already been
                   run.
                   Now when a user is suspended only Face-to-face signups for future sessions
                   are cancelled.

    TL-9056        Fixed program enrolment messages not being sent

                   It was possible that some program and certification enrolment messages were
                   not being sent. This would only occur in the unlikely event that the
                   program messaging scheduled task took some time to run, and that program
                   assignments changed during that time (either by a manual change made in the
                   Assignments interface when there were less than 200 users involved in the
                   program, or due to one of the two user assignment scheduled tasks running
                   at the same time). This has now been fixed. This patch does not
                   retroactively send program/certification enrolment messages that were
                   missed.

    TL-9086        HR Import now validates incoming user custom field values consistently

                   Previously HR Import was validating incoming user custom field data without
                   first passing it through the user custom fields API.
                   This could lead to invalid data passing validation as it had not been
                   appropriately translated.
                   HR Import now correctly passes incoming data through the user custom fields
                   API prior to validation to ensure any invalid data is detected and not
                   imported.

    TL-9115        Improved the display of averaged columns in Report Builder

                   When averaging a field the number of decimal places shown was the default
                   returned by the database.
                   The display has been improved to only show 2 decimal places.

    TL-9118        HR Import now converts mixed case usernames to lower case

                   This fixes a backwards compatibility issue introduced by TL-8502.
                   TL-8502 improved validation of usernames being imported through HR Import.
                   Unfortunately a previously added hack was present which was converting
                   mixed case usernames to lower case.
                   TL-8502 reverted this hack, ensuring only completely valid usernames could
                   be imported, and any invalid usernames would be skipped with an error.
                   After the release of 2.9.7 we received several reports of people relying on
                   this conversion to import their data.
                   After much discussion we decided to treat this as a backwards compatibility
                   issue and fix it as a bug in 2.7 and 2.9.
                   Now when you import a username with mixed case you will receive a warning,
                   the username will be converted to lower case and the user will be
                   imported.
                   Please note that in Totara 9.0 you will receive an error and the user will
                   not be imported.
                   We advise those who are getting these warning to fix the data they are
                   importing so as to make it accurate.

    TL-9135        Fixed the use of files within textarea type custom fields
    TL-9159        Multi-select custom field data params are now correctly deleted when the field is deleted

                   Previously data params for multi-select custom field values were not being
                   deleted when the multi-select custom field was deleted.
                   This resulted in orphaned data param records being left in the database.
                   Now when a multi-select custom field is deleted the data params for it are
                   also deleted.
                   Additionally an upgrade step will clean up any orphaned multi-select data
                   params that may be lurking in your database.

    TL-9162        Removing a user from an allocated Face-to-face session now returns capacity

                   Previously when a user was removed from an allocated spot in a Face-to-face
                   session by their manager the space they were occupying was not returned to
                   the available capacity of the session, nor were they being informed that
                   their allocation had been cancelled.
                   Now when a user is removed from an allocated spot the capacity is returned
                   and the user is notified.

    TL-9187        Fixed searching of the Program exceptions list by firstname and lastname
    TL-9210        Fixed a missing iCal attachment in the Face-to-face session allocation notification email
    TL-9235        Fixed the display of aggregated yes_or_no Report Builder columns

                   "Yes" is counted as 1, "No" is counted as 0. Aggregate functions use these
                   values for the calculations.

    TL-9241        Ensured the ability to choose an appraiser is not available when appraisals have been disabled
    TL-9261        Fixed the "Re-sort" button within the Certification management UI
    TL-9341        Fixed the User's Position Framework ID filter within the User report source
    TL-9362        Fixed the status display for certification in progress within the Record of Learning
    TL-9387        Fixed the display of Face-to-face sessions in the Face-to-face block
    TL-9388        Fixed the expansion of the Site Administration menu in IE8
    TL-9392        Available courses on the front page are no longer duplicated when the user is not enrolled in any courses

                   If the front page had been configured to display a list of Enrolled Courses
                   and the user was not enrolled on any courses then a list of available
                   courses would be displayed in stead.
                   Previously if you had also configured the front page to contain a list of
                   available courses this would then lead to the list of available courses
                   being displayed twice.
                   Now when the front page has been configured to display a list of available
                   courses and enrolled courses, when the user is not enrolled on courses then
                   nothing is printed.
                   This stops the list of available courses from being printed twice.

    TL-9397        Fixed an error encountered while exporting a Face-to-face cancellation report

                   This fixes a regression introduced by TL-6962, released in Totara 2.7.14,
                   2.9.6.

    TL-9434        Fixed a bug preventing roles from being assigned via audiences at the category level
    TL-9438        Fixed average aggregation within Report Builder when using MSSQL

                   MSSQL now ensures that it is using decimals when fetching average
                   aggregations.

    TL-9453        Prevented the adding of a Program to a Learning Plan from resetting Program status

                   When a program was already assigned to a user, if the same program was then
                   added to the user's learning plan, the status of the program was reset. The
                   program would likely be re-marked completed by cron, but only if the course
                   requirements were unchanged and the courses involved were still marked
                   complete.
                   Additionally, dates related to the program may have changed.
                   This fix prevents changes when adding a program to a learning plan if the
                   user is already assigned to the program.

    TL-9473        Fixed the "Download all" button within the file manager in IE and Safari
    TL-9485        Fixed data param handling in the core data object class
    TL-9669        Fixed the possibility of a "maximum SQL input variables" bug within the Face-to-face upgrade

Contributions:

    * Davo Smith at Synergy Learning - TL-9485
    * Francis Devine at Catalyst NZ - TL-9086
    * Nigel Cunningham at Catalyst AU - TL-8601, TL-9261


Release 2.9.8 (14th June 2016):
===============================


Important:

    TL-9190        Fixed Face-to-face session deletion custom field data loss

                   This is a regression introduced by TL-6962 in Totara 2.9.6, and 2.7.14,
                   both released April 2016.
                   In these releases the foreign key for Face-to-face custom fields was
                   changed from the "facetoface_signups_status" table to the
                   "facetoface_signups" table to ensure that data entered by the user was
                   maintained when their session signup status changed.
                   However the session deletion code was overlooked and was still using the
                   old relation to wipe the associated custom field data.
                   If a user deleted a Face-to-face session it may have incorrectly deleted
                   custom field data belonging to a different session.
                   This patch fixes the deletion code so it is using the correct relation and
                   ensures that when the session is deleted, the correct custom field data is
                   also deleted.

                   If you are on either of the mentioned versions we strongly recommend
                   upgrading to the latest release.


Improvements:

    TL-8708        Face-to-face session and event durations can now be aggregated and graphed

                   Face-to-face report sources now handle durations as integers.
                   This allows the the duration field to be aggregated, and used in graphs if
                   so desired.
                   The display of the field within the report is unchanged.

    TL-8719        Improved the help text for the "Add new courses" Totara Connect client setting
    TL-9050        Improved the help on Column and Row settings for textarea custom fields
    TL-9106        The user's name is now maintained when forcing use of the no-reply address

                   Previously in Totara 2.9, when the site had been configured to send all
                   emails from the no-reply email address, it was transposing the sending user
                   with the support user and overriding the support user's email address to
                   ensure all emails were coming from the no-reply address.
                   This meant that details of who was sending the email, including the
                   sender's name, were lost and replaced by the support user's details. This
                   was not the desired effect of this setting and was the result of a setting
                   conflict in 2.9.0.
                   The fix for this issue is to only override the email address, ensuring the
                   name of the sender is not lost.

                   Emails sent from the system when "Always send email from the no-reply
                   address?" is turned on still use the no-reply email address as the sender's
                   email address, however they now show the sender's name.


Bug fixes:

    TL-8152        Fixed the deletion of user accounts with empty email addresses

                   Previously if you attempted to delete two or more user accounts with empty
                   email addresses at the same time you would get an error.
                   This was visible most commonly in HR Import.
                   This has now been fixed. A unique non-numeric username is now generated as
                   a holding username during deletion.

    TL-8410        Fixed date validation when uploading Course and Certification completion data

                   Completion dates in course and certification uploads are now more
                   thoroughly validated.
                   If the value for the month is greater than 12, or the value for the day is
                   greater than what should be in the month, the date will be considered
                   invalid and the row will not be processed.

                   This patch also fixes a minor issue with how line endings are processed.
                   Now prior to processing the uploaded file all line endings in the file are
                   normalised.
                   This ensures that files generated on different operating systems are all
                   processed identically.

    TL-8650        Fixed result counting discrepancies within Appraisal reports

                   On the appraisals reports page there is a list of appraisals with counts
                   for "Overdue", "On target", "Complete", etc. There were some discrepancies
                   between these numbers and the reports displayed when clicking on the
                   counts.

    TL-8688        Corrected Face-to-face attendees dialog URL handling to prevent accidental removal of all attendees

                   Prior to this change, in some circumstances, the Face-to-face attendees
                   dialog would generate unexpected URL parameter value combinations which
                   could result in the removal of all users from the attendee list.

    TL-8790        Fixed the display of the user's full name for the roles column within the Face-to-face sessions report
    TL-8874        Face-to-face booking confirmation notification no longer ignores the "Manager copy" setting

                   Prior to this change the booking confirmation notification would be sent to
                   the attendee's manager even if the "Manager copy" setting was turned off.
                   The booking confirmation notification now correctly checks this setting.

    TL-8924        Fixed a display issue with empty due dates on the Program assignments tab
    TL-8928        Fixed Face-to-face notification substitutions in translated languages
    TL-9074        Fixed searching within the audience filter when the context id is not set
    TL-9079        Fixed a bug with header alignment when scrolling within the grader report
    TL-9102        The "Hide cost and discount" Face-to-face setting now correctly hides the discount code
    TL-9103        Fixed Face-to-face session location custom field filters
    TL-9248        Brackets are now correctly escaped during "LIKE" searches when using MSSQL

                   Previously during "LIKE" search operations, brackets "[" and "]" were not
                   being correctly escaped, which could on occasion lead to incorrect
                   results.
                   This was not exploitable but could have made searching difficult for some
                   MSSQL sites.

    TL-9273        Fixed MSSQL database structure consistency for sites upgraded from old Moodle installations


Release 2.9.7 (23rd May 2016):
==============================


Important:

    TL-8973        Activity completions will now always reset on archive regardless of their visibility

                   When activity completions were archived during a certification window
                   opening, the completions for activities set to hidden were ignored and
                   would be retained. Activity completions are now archived regardless of
                   their visibility.

                   This patch also fixes an issue where Face-to-face completion data was not
                   being fully reset if the completion time of the Face-to-face activity was
                   changed to a later time.

                   This change means that after the archive_course_activities function is run,
                   any activities that should not be complete will have no record in the
                   course_modules_completion table, rather than have one which is set to
                   incomplete.

                   As well as affecting certification window opening, these changes will also
                   apply when using the archive completions function within a course.


Security issues:

    TL-9057        Added sesskey checks when applying automatic fixes on the check completions page in the Program completion editor


Improvements:

    TL-6666        Enabled the randomisation of test table ids

                   In Moodle 2.9 phpunit testing was changed so that the auto-increment IDs of
                   records created in each table started with a different value. This was
                   designed to improve the testing quality by preventing code and tests from
                   using the wrong ID, but still coincidently passing the tests. For example,
                   if a course and certification were created during a test, previously it
                   could be possible to reference the course ID when the certification ID
                   should be used, because they were both 1, but with the change the two IDs
                   will be different, and use of the incorrect ID will be illuminated. This
                   improvement was initially disabled because many tests needed to be updated
                   to support it - the improvement has now been enabled and all of the core
                   tests have been updated to run with it. Any custom tests using fixed record
                   IDs may need to be updated.

    TL-7993        Removed the obsolete 'Manager emails' settings from Face-to-face
    TL-8237        Improved the reliability of behat in Firefox and Chrome using the latest version of Selenium

                   The behat integration has been tuned for the latest releases of Selenium.
                   Several old "hacks" made in Totara to get behat working have been removed
                   as the Selenium drivers have improved. This has greatly improved both the
                   performance and reliability of behat in core, though could have some impact
                   on any custom behat tests.

    TL-8376        Refactored the Face-to-face completion state SQL to improve performance
    TL-8629        Rephrased the help text for the SCORM activity's "Force new attempt" setting to improve its clarity
    TL-8665        Added an environment check for "always_populate_raw_post_data"
    TL-8705        Improved how deleted users are being handled on the browse list of users page

                   The detection of legacy deleted users, checking that their email address
                   field is set to an MD5, has been improved by using a regular expression.
                   Users who have an invalid email address (without an @ symbol) will now show
                   in the user list on the "Browse list of users" page.

    TL-8768        Improved the wording on the Documentation settings page, and ensured that all the settings work correctly
    TL-9020        Created initial Program and Certification completion transaction logs

                   If a user assigned to a Program or Certification did not have any
                   transaction logs, a snapshot log record will be created during upgrade.
                   Likewise, a certification settings snapshot will be created if none exists.
                   This will help with diagnosing future problems.

    TL-9022        Added confirmation when applying automated fixes to program completions

                   When using the program or certification completion checker or editor, when
                   you activate one of the fixes, you will now need to confirm the action.
                   This is to prevent accidental clicks, and provides additional warnings.

    TL-9033        Increased the form field lengths on the Certification settings form


Bug fixes:

    TL-8046        An editor is displayed when editing role descriptions

                   This change reverted MDL-50222 which converted the role description from an
                   editor to a plain text field as it was deemed to be internal only. Totara
                   however uses this field more than Moodle and the above change was reported
                   as a bug.

                   We have now reverted Moodle's change and returned the editor for that
                   field.

    TL-8247        Fixed missing history records when not overriding the current record during a course completion import

                   Previously if you ticked the override checkbox when uploading course
                   completions, but the most recent completion date in the upload was less
                   than the current completion date in an existing record, the upload would
                   ignore the first record and move straight on to the next one. That first
                   record is now placed into history instead.

    TL-8389        Fixed an issue with empty variables inside aggregate questions
    TL-8408        Fixed the Face-to-face user cancellation status by checking the user's current status, avoiding multiple cancellations
    TL-8472        Fixed the Terms & Conditions dialog box for Face-to-face self approval
    TL-8494        Fixed changes to editing trainer assignments not being reflected in the course catalog immediately
    TL-8554        Fixed zero values for appraisals rating questions

                   Both positive and negative numbers are valid values for ratings questions
                   in Appraisals, but a lot of the validation checks were using !empty() which
                   caused problems when trying to use zero. These checks have been updated and
                   zero is now an acceptable value in both numeric and custom ratings

    TL-8561        Changed the display of certification settings in the completion editor to use translatable strings
    TL-8587        Improved the 'Grade to pass' setting validation in Quizzes

                   If the 'Require passing grade' activity completion setting is enabled, the
                   'Grade to pass' must now have a greater-than-zero value. This restriction
                   is also enforced when editing Quiz settings in the gradebook.

    TL-8599        Corrected the completion time used for completion criteria based on completion of another course

                   Completion criteria based on completion of another course now use the
                   completion time of that course when setting the completion time of the
                   criteria, rather than using the time that the criteria was aggregated.

    TL-8605        Fixed certification completon records affected by the reassignment bug

                   Patch TL-6790 in the March release of Totara changed the behaviour when
                   re-assigning users onto a certification. This patch repairs certification
                   completion records for users who were, before that patch, re-assigned and
                   ended up being unable to certify. All users which are identified by the
                   completion checker as "Program status should be 'Program incomplete' when
                   user is newly assigned. Program completion date should be empty when user
                   is newly assigned.", and have an "unassigned" historical completion record,
                   will have that historical record restored, as is the current behaviour when
                   reassigning users. Any records which do not meet these specific criteria,
                   or would be in an invalid state if the change was applied, will not be
                   affected and must be processed manually.

    TL-8621        Fixed the progress bar on the Required learning page when Programs use "AND" courseset operators
    TL-8667        Added functionality to fix duplicated Face-to-face notifications

                   In extremely rare cases the automatic notifications for Face-to-face are
                   being duplicated. If this happens, a warning box will appear for course
                   administrators on the session or  notifications pages and it will be
                   possible to remove the duplicated notifications leaving only the required
                   ones.

    TL-8696        Added a workaround for incorrect rendering of tables in pdf exports using wkhtmltopdf
    TL-8721        Fixed the download file functionality for file pickers when using Internet Explorer
    TL-8732        Fixed capability checks around suspended users within the course enrolment interfaces
    TL-8753        Added an automatic fix for mismatched program and certification completion dates

                   The program completion date should match the certification completion date
                   when a user's certification is "Certified, before the window opens". To
                   repair records where the date is incorrect, this patch added an automated
                   fix which can be triggered to copy the certification completion date to the
                   program completion date. Relates to TL-9014.

    TL-8764        Deleted orphaned course reminders for deleted courses
    TL-8771        Removed duplicated Face-to-face event action icon titles
    TL-8785        Removed the incorrect 'leave this page' warning when editing Feedback activity questions
    TL-8788        Fixed the display of the program completion block when there are no programs visible
    TL-8793        Reminders which are sent belonging to a user are now deleted when the user is deleted
    TL-8807        Fixed search in the completion upload results report
    TL-8867        Fixed the incorrect display of hidden positions and organisations during self registration
    TL-8872        Fixed the ordering of the transaction logs in program and certification completion editors
    TL-8919        Fixed incorrect id being used when preparing an overview for a SCORM activity
    TL-8936        Fixed access to course/info.php when audience visibility is in use
    TL-8942        Fixed test failures caused by a new timezone in Venezuela
    TL-8960        Fixed an issue with creating courses, caused by a guest access setting

                   Previously if you set "require password" for the guest access enrolment
                   plugin, and set the plugin to add a new instance to all new courses. When
                   you then attempted to create a new course, the setting would not be copied
                   to the new course correctly.

    TL-8969        Updated the help string for the "fullnamedisplay" setting
    TL-8983        Fixed the repeating update of signup status for suspended and deleted users in Face-to-face

                   Previously a cancellation status update was written to the database for
                   each deleted or suspended user who had signed up to a Face-to-face session
                   prior to deletion/suspension, this happened every time cron ran.
                   Face-to-face now correctly checks if the user already has a cancellation
                   status and does not write a redundant duplicate status.

    TL-8991        Fixed the wrong date being used to calculate the certification completion date

                   If a certification had a course set with more than one course, where not
                   all of the courses were required for completion. And before being assigned
                   to the certification, a user completed (manually or via course completion
                   upload) enough of the courses to complete the course set. The certification
                   completion date was being incorrectly calculated as the latest date of all
                   completed courses, rather than the maximum course set completion date. This
                   patch corrects this, and provides an automated fix (part of the
                   Certification completion editor) to repair any affected records.

    TL-9017        Fixed the incorrect redirection to file serving scripts after interruption actions

                   This fix makes two changes:
                   1) File serving scripts no longer set themselves to the return URL if
                   triggered during an interruption action such as the user being forced to
                   change their password.
                   2) Blocks are no longer shown on the change password screen, it now uses
                   the "login" page layout, the same as the main login page.

    TL-9021        Fixed a race condition when loading JavaScript for Totara dialogs

                   When in an appraisal there was a chance that dialogues were attempted to be
                   initialised before the dialog code was downloaded.

    TL-9030        Fixed the removal of text formatting in the display of descriptions for Report builder reports
    TL-9044        Fixed the calculation of substitute colours within the custom Totara responsive theme

                   In the Custom Totara responsive theme, there was an error in the text
                   colour calculation where it would always result in going to the dark
                   colour, regardless of what the background colour was. Now if the background
                   colour is dark, the text will be light

    TL-9052        Fixed the status of notification templates when they were updated by a user
    TL-9061        Fixed an error when double clicking on filters in the enhanced catalog


Contributions:

    * Artur Poninski at Webanywhere - TL-8599
    * Carlos Jurado at Kineo - TL-8960
    * Chris Wharton at Catalyst NZ - TL-8867
    * Davo Smith at Synergy Learning - TL-8788
    * Francis Devine at Catalyst NZ - TL-8919
    * Malgorzata Dziodzio at Webanywhere - TL-8376
    * Stacey Walker at Catalyst EU - TL-8936


Release 2.9.6.1 (26th April 2016):
==================================

Important:

    TL-8846        Face-to-face upgrade restores the latest non-empty signup and cancellation custom field data

                   The 2.9.6 release contained a fix for TL-6962 which was not acting in a way
                   that all users wanted it to.
                   Given an upgrade step is non-reversible, we have put out an emergency
                   release to allow administrators to choose how they want the upgrade to
                   behave.

                   TL-6962 was fixing Face-to-face signup and cancellation custom field data
                   being lost when the user's signup status changed.
                   The root cause of that issue is that custom field data was being stored
                   against the user's signup status rather than the signup itself.
                   Because a user could pass through multiple statuses, this data was lost in
                   the user interface as soon as the user's status changed. This was most
                   commonly seen if manager approval was turned on, in which case the signup
                   note entered by the user when they signed up would be lost when the manager
                   approved them.
                   The solution was to change this, so that data is stored referencing the
                   signup rather than the signup status.
                   This ensures that the data is maintained throughout a user's signup,
                   regardless of which statuses they pass through.
                   During upgrade we had to remap existing data and a choice had to be made.
                   Either we kept the data consistent with what users had previously seen in
                   the system OR we restored the last non-empty value for the field for each
                   signup.
                   We chose in 2.9.6 to keep the data consistent with what users were seeing
                   prior to the upgrade.
                   Since the release we have had feedback that this is not what all sites
                   expected and that they would prefer to have the last non-empty value
                   restored.
                   We appreciate this request and have come up with a solution that will allow
                   each site to choose, if they wish, which they would like to happen.
                   There is now a special configuration variable that can be defined in PHP to
                   change the upgrade behaviour.
                   The following explains what this upgrade step does and how to choose the
                   alternative behaviour if you want it.

                   Default upgrade behaviour:
                   The upgrade finds the last non-empty value for each Face-to-face signup or
                   cancellation custom field and uses that as the value the user entered.
                   This is consistent with the behaviour you will see AFTER upgrading to this
                   version.
                   It is not consistent with the previous behaviour before upgrading, which
                   was not maintaining the value the user entered.
                   This is the default behaviour so you don't need to do anything except
                   upgrade.

                   Alternative upgrade behaviour:
                   Instead of the default behaviour, restore the latest value recorded for the
                   Face-to-face signup or cancellation field, which may be empty due to status
                   changes, and store that as the user's current value.
                   This is consistent with the behaviour prior to custom fields being fixed.
                   It is not consistent with the current behaviour which ensures the value the
                   user entered is maintained.
                   To get this behaviour you must add the following to your config.php before
                   upgrading to 2.9.6.1:
                       $CFG->facetoface_customfield_migration_behaviour === 'latest';

                   If you have already upgraded to the 2.9.6 release the alternative behaviour
                   would have already been applied as this was the only behaviour available in
                   that release.
                   It is possible to change from the alternative behaviour to the current
                   behaviour if you have a backup from prior to the upgrade.
                   If this is you please get in touch with us and we'll provide instructions
                   on how to re-run this part of the upgrade using the data in the backup.


Release 2.9.6 (20th April 2016):
================================


Important:

    TL-8417        Historical completion records belonging to a course are now deleted if the course gets deleted

                   Previously when a course was deleted the historical completion records were
                   forgotten about and left orphaned.
                   This lead to errors and visual inconsistencies when trying to work with the
                   historical completion records as they now referenced removed courses.
                   Now when a course is deleted all historical completion records held for it
                   are also deleted.
                   Please note that during upgrade all orphaned historical completion records
                   are deleted.

    TL-8711        Scheduled reports belonging to a user are now deleted when the user gets deleted

                   Previously when a user or audience was deleted any scheduled reports
                   belonging to that user were left in the system.
                   This lead to errors as the scheduled reports now referenced users that no
                   longer existed.
                   Now when a user is deleted all scheduled reports belonging to that user are
                   also deleted.
                   During upgrade all orphaned scheduled reports belonging to previously
                   deleted users will be cleaned up.

                   The same is true of audiences referenced as recipients of scheduled
                   reports.
                   Now when an audience is deleted orphaned scheduled report recipient records
                   are also cleaned up.
                   During upgrade all orphaned scheduled reports referencing audiences that no
                   longer exist will be cleaned up.


Improvements:

    TL-8174        Fixed visibility for the 'My Learning' SCORM activity overview
    TL-8358        Updated the help text for a custom fields' "Locked" setting
    TL-8393        Performance improvement when admins view a course with many activities

                   Previously, when an admin viewed a course, the admin's completion data for
                   each course would be checked for each activity multiple times. The higher
                   the number of activities in a course, the more often these completion
                   checks would occur, causing performance issues when there were many
                   activities involved. This only affected users who could access the course
                   but were not enrolled, such as site administrators. Enrolled users were not
                   affected by this bug. Guest users were also not affected as completion data
                   is not checked for them.

                   The issue occurred due to cached data being cleared incorrectly for the
                   affected users. This has been corrected and page load times for admins on
                   the view course page will now be similar to that of enrolled learners.

    TL-8421        Usernames on login page now avoid mobile OS default capitalisation
    TL-8522        Template library now has a context for admin_tool/list_templates_page
    TL-8595        Added cost information to Face-to-face direct enrolment for sign-up page
    TL-8657        Improved performance of adding courses and programs to audiences
    TL-8751        Added links to run completion checker over whole site

                   Links were added in Manage Programs and Manage Certifications which allow
                   privileged users to run the program and certification completion checkers
                   over all programs or certifications on a site, rather than having to run
                   them one program or certification at a time.

    TL-8759        Added help popup for Require view activity completion criteria


Bug fixes:

    TL-6962        Made signup and cancellation fields consistent throughout Face-to-face

                   Previously Face-to-face custom fields for signup and cancellations were
                   being attached to a users signup status.
                   This was a regression from the conversion of Face-to-face custom fields in
                   2.7 that has been the cause of a several hard to track down problems.
                   In this fix we have changed the attachment point from signup status to the
                   signup itself.
                   This has lead to several minor changes in the Face-to-face API's as noted
                   below.

                   * facetoface_get_attendee no longer returns the statusid or usernote as
                   part of the record it returns.
                   * facetoface_get_attendees no longer returns a usernote as part of the
                   record it returns.
                   * facetoface_user_signup the usernote argument 10 has been deprecated and
                   now displays a debugging notice if used.
                   * facetoface_update_signup_status the usernote argument 4 has been
                   deprecated and now displays a debugging notice if used.
                   * facetoface_get_cancellations no longer returns a cancellation reason
                   property as part of its response.
                   * facetoface_get_requests no longer returns a usernote property as part of
                   the record it returns.
                   * facetoface_user_import no longer imports a usernote (this was not being
                   stored correctly)

    TL-8101        Removed the incorrect "role change" warning for completed dynamic appraisals
    TL-8136        Fixed Face-to-face custom field filters when applied within the calendar
    TL-8156        Fixed capability checks when adding audiences and users as scheduled report recipients
    TL-8162        Ensured only eligible activities are selectable for feedback reminders

                   Only activities which are part of course completion can be tracked for
                   sending out feedback reminder messages. However, it was previously possible
                   to select other activities and the reminder would simply not go out. The
                   select options for activity completion to base a feedback reminder on are
                   now restricted to those that are part of course completion criteria.

    TL-8338        Fixed the Face-to-face signup by waitlist functionality by including overbook capability check
    TL-8346        Corrected Face-to-face terminology within the session report source

                   The Face-to-face session report now correctly refers to users who have self
                   booked via the self-booking service as "Self booked", previously they were
                   incorrectly referred to as "Reserved"

    TL-8355        Corrected spelling of re-classify and re-classifying by removing hyphen
    TL-8374        Ensured the certification completion date is only calculated on the current paths courses
    TL-8380        Removed the sorting from Progress column for Certification overview report
    TL-8399        Fixed the coursenames column in the Program/Certification overview report

                   Previously if a course's short name contained a comma it would be
                   incorrectly processed by the Program overview and Certification overview
                   reports.
                   It is now correctly handled.

    TL-8428        Fully disabled Syncing Position ID number field in HR Import when Position Hierarchies are disabled

                   The previous behaviour was that if you have any of the position fields
                   (Position Title, Position ID Number, Position start date, Position end
                   date) enabled for the sync and then Position hierarchies are disabled then
                   the position fields are removed from the interface but are still synced.
                   The new behaviour is that Position ID number will be completely disabled
                   (it will not sync the field until Position hierarchies are re-enabled) and
                   the other fields will not be disabled.

    TL-8434        Added columns for custom program fields to Program Completion, Program Membership and Program Overview report sources
    TL-8438        Added a missing string used within the Program membership report
    TL-8458        Face-to-face module can now be managed by users with the 'totara/core:modconfig' capability
    TL-8461        Fixed course deletion to more accurately update program coursesets

                   Previously, all competency course sets were inadvertently being removed
                   from programs whenever any course on the site was deleted. This, and
                   deletion of courses that left other course sets empty, also resulted in
                   exceptions being displayed when viewing programs.

                   This behaviour has been prevented.

                   Two methods have been added to the course_set abstract class in
                   totara/program/program_courseset.class.php, get_courses and delete_course.
                   These will be abstract methods in the next major release. For existing
                   releases, they will output a message if debugging has been turned on. If
                   any custom classes have been created that inherit from this class, it is
                   recommended that you overwrite these methods in the custom class.

    TL-8471        Fixed 'totara/dashboard:manage' capability for non admin user
    TL-8475        Fixed position type display function for Face-to-face session report
    TL-8502        HR Import now correctly handles invalid usernames by logging a warning and continuing on

                   This issue was only encountered when the user delete setting was set to
                   suspend users, and there were users being deleted. However this adds extra
                   validation to the HR import sanity checks so any invalid users will be
                   detected during any sync action.

    TL-8582        Updated course multiselect custom field type to update all data records when option text or icons are changed
    TL-8585        Face-to-face notification iCalendar attachments now support updates during signup status and/or session date changes

                   Please note, software that does not support iCalendar sequence will still
                   create new event each time instead of updating it.

    TL-8603        Fixed multilang support within Report description field
    TL-8633        Fixed use of the duedate placeholder in program messages
    TL-8634        Fixed Audience: Visible Learning report when no id is set
    TL-8653        Fixed image used by the template library when viewing the core/pix_icon template
    TL-8672        Fixed removal of seleted audiences when editing a course
    TL-8685        Fixed pagination when viewing global report restriction list
    TL-8691        Fixed the handling of locked custom course fields when creating a new course
    TL-8698        Fixed minor JavaScript error when using AMD get_strings implementation in IE9
    TL-8707        Made the 'Duration' column within Face-to-face reports translatable
    TL-8760        Fixed deactivation of the "require end reach" completion condition for Lesson activities


Release 2.9.5 (23rd March 2016):
================================


Important:

    TL-6790        Changed the default behaviour of certification reassignment

                   Previously a user who was unassigned and reassigned to a certification
                   would be placed back into their initial certification path. Depending on
                   their current course completions, their status may have been reaggregated
                   on the next cron run. Now the system will look for the latest unassigned
                   certification completion history record and the user will be restored to
                   their previous status instead. Any events that need to occur (such as
                   window opening) will take place when the relevant scheduled task runs (e.g.
                   update_certification_task).


Security issues:

    TL-8641        The following security fixes were included with the merge of Moodle 2.9.5

                   * MDL-51167 Hidden courses are shown to students in Event Monitor
                   * MDL-52378 Non-Editing Instructor role can edit exclude checkbox in Single
                   View
                   * MDL-52651 Add no referrer to links with _blank target attribute
                   * MDL-52727 Reflected XSS in mod_data advanced search
                   * MDL-52774 Enumeration of category details possible without
                   authentication
                   * MDL-52808 External function get_calendar_events return events that
                   pertains to hidden activities
                   * MDL-52901 External function mod_assign_save_submission does not check due
                   dates
                   * MDL-53031 CSRF in Assignment plugin management page


Improvements:

    TL-6296        Added an aria-label to select user checkbox when viewing course participants
    TL-6723        Added automatic test coverage of the security overview report
    TL-7864        Added haschildren class to top level totara menu items when applicable
    TL-8295        Improved perfomance when getting items assigned to plans

                   This get_assigned_items function by default was returning the counts of any
                   linked items. This was leading to performance issues when the counts were
                   not required. The function now returns this information only when required.

    TL-8422        Improved output of the standard logstore cleanup task
    TL-8478        Added pagination to the Global Report Restriction administration page
    TL-8484        Linked Report Builder Financial year setting labels to their inputs
    TL-8532        Added an accessible label when adding a comment to a learning plan


Bug fixes:

    TL-8205        Removed unassigned users that incorrectly show up in certification completion reports

                   Reports that used the 'Certification Completion' report source would
                   contain users that had been unassigned from a certification. This would
                   only be the case if the user was unassigned before their recertification
                   window opened and the data for these users would be incorrect for some
                   columns. Unassigned users will no longer show up in certification
                   completion reports, which is in line with documentation on this report
                   source.

                   Note that if you require a report that includes data for unassigned users.
                   You may like to create a report that uses the Record of Learning:
                   Certification report source.

    TL-8274        Fixed calendar navigation on non-default home page
    TL-8277        Fixed incorrect highlighting of menu items

                   When enhanced catalog was off, viewing the pages specific to the enhanced
                   catalog were leading to the Find Learning menu items being highlighted.
                   This has been corrected.

    TL-8280        Fixed manual changes to course completion competency proficiency being overridden

                   Before the patch, if a manager set a course completion competency to
                   proficient, it was being overridden by a cron task. Now, the change the
                   manager made will be kept.

    TL-8339        Fixed saving of due dates when creating and editing objectives in learning plans
    TL-8345        Ensured sum aggregation uses display function if available
    TL-8363        Ensured courses assigned to plans are removed when a course is deleted
    TL-8364        Removed extra line breaks in Face-to-face messages
    TL-8381        Ensured Hierarchy custom field data is deleted when a Hierarchy item is deleted
    TL-8407        Improved layout of the graph tooltip in Internet Explorer using a rtl langauge
    TL-8409        Prevented saving scheduled reports without a recipient
    TL-8412        Fixed 'menuofchoice' custom field for sidebar filter in report builder
    TL-8419        Fixed issue that prevented blocks from being edited with Totara Dashboard enabled as default home
    TL-8427        Fixed position selecting which was incorrectly disabled when disabling position hierarchies
    TL-8441        Increased maxlength of objective scales value name to 255 characters
    TL-8444        Fixed Program and Certification Membership reports for MSSQL
    TL-8457        Fixed a spelling mistake in the program extension request error message
    TL-8477        Fixed Date (No timezone) user profile field in Report Builder
    TL-8479        Fixed the MSSQL NVARCHAR migration upgrade step
    TL-8482        Removed empty labels when adding/editing External tools
    TL-8496        Fixed count of overdue users on Appraisals report page
    TL-8506        Fixed AJAX deletion of an assigned audience when creating a dashboard
    TL-8508        Fixed untranslatable string "Face-to-face name" in Face-to-face sessions report source
    TL-8521        Improved course participants template for template library
    TL-8538        Fixed dates in ODS exports to use current user timezone to match all other export options
    TL-8583        Session end time is now adjusted in IE11 when start time is adjusted


Release 2.9.4 (22nd February 2016):
===================================


Security issues:

    TL-8235        Included session key check in Face-to-face when adding and removing attendees
    TL-8392        Fixed handling of non-numeric answers to numeric feedback activity questions


New features:

    TL-8115        Added a new URL custom field type

                   This new custom field type can be used in Courses, Hierarchies, Goals and
                   Face-to-face.


Improvements:

    TL-7542        Added a new report source for language customisations
    TL-7970        Added the program and certification completion editor

                   Enabled with Site administration -> Advanced features -> Enable program
                   completion editor. Only users with the 'totara/program:editcompletion'
                   capability (site admins only, by default) will be able to access the new
                   tab 'Completion' when editing a program or certification. For more
                   information, see the community post:
                   https://community.totaralms.com/mod/forum/discuss.php?d=11040.

    TL-8276        Removed unused CFG settings from Totara messaging code

                   The removed settings are "message_contacts_refresh", "message_chat_refresh"
                   and "message_offline_time".

    TL-8290        Increased maximum value of sortorder field in the Feedback360 questions table.

                   When running MySQL in particular, the number of questions in one Feedback
                   questionnaire would be limited to 128. This was due to the sortorder field
                   in the corresponding table being of the type tinyint. This sortorder field
                   will now use the bigint datatype for all supported databases, which is
                   consistent with similar fields in other tables.

    TL-8294        Improved layout of the learning plan page at small screen widths
    TL-8365        Added a link to the course completion report from the user profile page
    TL-8371        Changed program course sets to display courses in the order they were added

                   The order of courses in a program or certification course set would vary
                   when returned by a database. They are now ordered by ID of the
                   prog_courseset_course table, making the order more consistent. This means
                   they will be in the same order as what they were when first added to the
                   course set.


Bug fixes:

    TL-6593        Fixed course completion status not updating when changing completion criteria

                   Users were not being marked "In progress" when the were assessed against
                   the new completion criteria.

    TL-8075        Fixed error in HR Import when setting the CSV delimiter to Tab
    TL-8078        Completion progress details page was reworded to more accurately indicate the status

                   Previously, the course status in the Completion progress details page
                   (accessed by clicking the "Progress" bar in Record of Learning: Courses or
                   "More details" in the Completion status block) would show "Not started"
                   even though the learner had actually viewed and completed a SCORM lesson.
                   Moreover, the SCORM activity status would be "Viewed the scorm, Achieved
                   grade" even though the learner had not achieved the grade to complete the
                   activity. These were fixed in this patch. Course status is now "incomplete"
                   as long as its activities are not complete and the activity status
                   correctly indicates the learner failed to achieve the required grade.

    TL-8226        Fixed an issue with the course completion scheduled task

                   There was a problem in the completion cron when a user had completed an
                   activity but hadn't had the module completion record written into the
                   database. The criteria review would call get_info() which now updates the
                   state, creating the module completion record. However the initial review
                   would then continue and due to a dataobject lacking the now existing record
                   it would try to write the record again, causing a conflict. The dataobject
                   is now created after the get_info() call, avoiding this issue.

    TL-8240        Fixed capability checks when assessing a user's access to resources using audience visibility

                   Prior to this fix, in rare situations where the current user was viewing
                   resources available to another user, the access checks were being
                   incorrectly performed for the current user. The checks are now correctly
                   performed for the given user rather than the current user in this
                   situation.

    TL-8253        Fixed a bug which occured in some situations when deleting audiences without members

                   Prior to this fix, if you attempted to delete an audience which had a role
                   assignment associated with it, but not members, you would receive a fatal
                   error. This has now been fixed and the audience is correctly deleted.

    TL-8319        Fixed the display of the "Add audiences" button when setting access rules for dashboards

                   When navigating to the access tab for a dashboard, if the restrict by
                   audience checkbox was already checked then the "Add audience" button would
                   incorrectly be disabled. The button now displays correctly when navigating
                   to the access tab.

    TL-8322        Fixed problem when upgrading to patch T-12199

                   The upgrade step in this patch was changing cohort visibility records for
                   certifications. It tried to change the program-type records to
                   certification-type. Now, if the certification-type record already exists,
                   the program-type record will instead be deleted.

    TL-8361        Fixed incorrect hardcoded max table name length in the XMLDB editor
    TL-8391        Fixed reportbuilder sorting and pagination when Restrict initial display is enabled
    TL-8397        Fixed scheduled task not completing for recurring courses

                   The scheduled task which backs up and restores a recurring course within a
                   program was not successfully completing. This has been fixed.


Contributions:

    * Eugene Venter at Catalyst NZ - TL-7542, TL-8276
    * Hamish Dewe at Orion Health - TL-8371
    * Jo from Kineo - TL-8392


Release 2.9.3 (18th January 2016):
==================================================


Important:

    TL-7896        Fixed dynamic audience rules that reference an organisation menu type custom field

                   Dynamic audience rules for Organisation menu custom fields can have one of
                   two operators, "Equal to" and "Not equal to".
                   Prior to this fix these operators functioned in reverse. "Equal to" would
                   lead to users within an organisation for which the custom field did NOT
                   include the selected options.
                   Likewise if "Not equal to" was used users within organisations for which
                   the selected value was used would be included as audience members.
                   After this fix the operators are applied correctly.

                   If you have dynamic audiences with rules based upon organisation menu
                   custom fields then we strongly recommend you review these dynamic audience
                   rules and the associated audience memberships.
                   During upgrade these rules will be corrected and audience memberships may
                   change.
                   If you have affected audiences, you can fix them without incurring
                   membership changes by following these steps:

                   1. Disable cron prior to your upgrade.
                   2. Upgrade your site.
                   3. Review the dynamic audiences that are affected. If you need memberships
                   to stay exactly the same then changing the condition on the rule from
                   "Equals to" to "Not equals to" (or vice-versa) will ensure that audience
                   memberships stay as they were prior to this version.
                   4. Approve your changes and review the audience memberships.
                   5. Re-enable and run the cron.

    TL-8047        Fixed a bug found within SQL search routines used by both dialog searches and dynamic audience rules

                   Prior to this fix if you had a dynamic audience with two or more rules in a
                   single ruleset, where the rules have comma separated values specified in
                   conjunction with any of the following conditions "Contains", "Is equal to",
                   "Starts with", "Ends with" then membership may be incorrect.
                   The bug is due to multiple value search SQL not being correctly wrapped in
                   brackets.

                   After this fix comma separated values are correctly applied when
                   determining dynamic audience membership.

                   Depending upon the order of the rules and how they apply to the users
                   currently in the audience, membership may or may not change.
                   If you have an audience you believe is affected we strongly urge that you
                   first test this version on a copy of your site and after upgrading, closely
                   review audience membership.
                   You will need to review and amend the audience rules if users are removed
                   and you require them to still be included.

                   This bug may also have affected dialog searches when multiple values were
                   being used. Searching in dialogs now correctly handles multiple search
                   values.


Improvements:

    TL-7560        Added missing foreign key to the type field in the pos_assignment table
    TL-7816        Time can now be set when assigning due dates for programs

                   Previously when setting fixed due dates for a program or certification,
                   only the date could be set but not the time, which would fall at the
                   beginning of the day for the person setting it. Now the time can also be
                   set which means less ambiguity for when a due date will expire,
                   particularly for sites where users are in different timezones from each
                   other.

                   If a user is requesting an extension of their due date in a program, they
                   can also specify the time.

                   If a manager's team members have pending extension requests, the manager
                   can now navigate to the page where these requests are updated via the 'My
                   Team' page. Previously they could only get to the page by a link in an
                   email or typing in the url.

    TL-7973        Added a warning for Report builder when internally required columns break custom aggregations
    TL-8133        Renamed the Position and Organisation Report builder filters to be more consistent
    TL-8144        Improved the multi-lang support for Appraisal management pages
    TL-8155        Improved compatibility with PostgreSQL 9.5
    TL-8166        Added a new column 'Course Completions as Evidence' to the My Team embedded report
    TL-8183        Improved the Face-to-face session room filter
    TL-8210        Replaced the logos in the standardtotararesponsive theme with SVG equivalents
    TL-8228        Improved the multi-lang support for Questions in Appraisals and Feedback360


Bug fixes:

    TL-7012        Fixed the course completion progress bar for courses within a completed learning plan

                   The course completion progress bar was not being correctly displayed in the
                   Record of Learning for course that are part of an already completed
                   learning plan.

    TL-7527        Fixed the default settings for the example appraisal

                   The example appraisal previously required some of the question content to
                   be opened and saved via the interface before goals or competencies could be
                   selected by learners. On a new install of Totara, example appraisals can
                   now be assigned and activated without having to open the question settings
                   beforehand. This also fixes certain instances where a manager could not
                   review goals after they had been reviewed by the learner.

    TL-7608        Increased the maximum character length to 255 for various user fields in HR Import

                   The maximum character length of the institution, department, address and
                   password fields have been increased to 255 to match those allowed through
                   the user interface.

    TL-7809        Updated the language strings for the learning plans "objectives approval" and "status" columns
    TL-7826        Course completions stats on the My Team report now include RPL completions

                   Switched the Course Completion statistics on the My Team embedded report to
                   use course_completion records instead of block_totara_stats.

    TL-7946        Removed the link from progress icon if the user is not enrolled in the course

                   If a user is enrolled in a program but not yet enrolled in a course within
                   that program (e.g. they have not yet launched the course), the progress
                   icon included a link to their completion status. Clicking on this would
                   take that user to a page with an error saying they are not yet enrolled.
                   The progress icon now only acts as a link if they are enrolled or already
                   have a completion status by some other means.

    TL-7978        Fixed the layout of strings in the Completion status block

                   A couple of strings in the completion status block were appended together
                   and were missing spaces. The second part of the string is now passed into
                   the language string which fixes the layout and also allow the string to be
                   translated correctly which previously was not possible.

    TL-8041        Fixed access controls when adding and removing audiences while editing courses

                   When adding audiences via the course edit page, the checks are now ensuring
                   that the cohort enrolment plugin is enabled and that the logged in user has
                   the capabilities 'moodle/course:enrolconfig' and 'enrol/cohort:config' in
                   the course or higher context. Also the audience selector now only displays
                   audiences that the user can view (with 'moodle/cohort:view' in the
                   necessary context).

    TL-8049        Fixed an error when hiding blocks on learning plan pages

                   Previously when trying to hide a block in a learning plan page
                   (totara/plan/component.php) an error would be displayed and the block would
                   not be hidden.

    TL-8056        Fixed styles for the assignment marking guide criterion form section
    TL-8083        Removed dashboards associated with deleted audiences
    TL-8124        Fixed error when deleting course with Face-to-face activities
    TL-8127        Fixed filters requiring javascript in embedded Audience Member reports
    TL-8128        Fixed the link edit current user profile in the navigation block
    TL-8129        Fixed the homepage redirect when a dashboard is set to be the default homepage
    TL-8135        Fixed the risk displayed for the totara/program:markstaffcoursecomplete capability
    TL-8160        HR Import now correctly sets the default language when creating users
    TL-8167        The Graphical report block now uses the default sort order of the report
    TL-8173        Fixed HTML validation error due to missing closing div tag on the program assignments page
    TL-8184        Stopped timezones being displayed in Face-to-face reports when they are disabled in the plugin settings
    TL-8185        Fixed the pagination on the "Manage programs" and "Manage certifications" pages
    TL-8191        Fixed the validation of Report builder date filters using number of days selectors
    TL-8197        Fixed text placement for RTL graphical reports in Internet Explorer and Edge
    TL-8207        Fixed notice when editing pages with custom block regions without JavaScript
    TL-8221        Course icons are now shown in all circumstances

                   With the enhanced course catalogue disabled, the course icons previously
                   had an incorrect URL causing them to not be displayed. We now validate the
                   URL to ensure it is correct.

    TL-8229        Changed the required learning page to show user's program details even if complete

                   Previously, if a manager tried to view a learner's program or certification
                   and it was complete, the manager would instead see their own status in the
                   program or the learner's Required Learning page, rather than their
                   student's.

    TL-8231        Switched the Face-to-face edit attendees from sending GET params to POST params

                   Prior to this change when editing the attendees of a Face-to-face session
                   the dialog would submit any changes made as GET params.
                   If the session had hundreds or thousands of attendees this could lead to an
                   exceptionally long URL.
                   The length of the URL may then cause problems on some systems, particularly
                   IIS and any site running Suhosin.

    TL-8245        Fixed cohort log data in site logs
    TL-8251        Fixed an error with updating competency properties in a learning plan with JavaScript disabled

                   When updating either priority or status for a competency in a Learning Plan
                   with JavaScript turned off there was a error message thrown. The update was
                   saved but an message was displayed every time there was an update.

    TL-8263        Fixed room validation during Face-to-face session creation when the datetime is not known

                   Prior to this fix when creating a Face-to-face sessions, if a room is
                   selected then a date is selected which causes a resource conflict when
                   saving. If the user then sets "date/time known" to "No" the validation
                   would still fail and stop the session from being saved.


Contributions:

    * Pavel Tsakalidis from Kineo UK - TL-7560
    * Russell England from Kineo USA - TL-8191


Release 2.9.2 (14th December 2015):
===================================


Security issues:

    TL-7957        Totara Connect now prevents reuse of ssotokens for user logins
    TL-7975        Added read/write access controls to group assignment code throughout Totara
    TL-8076        Prevented access to external blog pages when either blogs or external blogs are disabled


New features:

    TL-7679        New PDF export plugin in Report builder using wkhtmltopdf binary

                   This export plugin is compatible with RTL languages, has increased
                   performance, and lowered memory use.


Improvements:

    TL-4429        Added an advanced multi-item course name filter to various Report builder report sources
    TL-6283        Removed all uses of deprecated function sql_fullname in Feedback360
    TL-6474        Shortened the display of Report builder Graph labels and legend entries

                   It is now possible to specify limitations on label length for Report
                   builder graphs using the following syntax in the custom settings input:
                     label_shorten = 20
                     legend_shorten = 40

                   To get the previous behaviour without shortening use value 0.

    TL-7810        Improved the performance of building hierarchy lists
    TL-8020        Added advanced multi-item Position and Organisation name filters to various Report builder report sources
    TL-8061        Changed the default settings for badge owner notifications to always send email

                   This only effects new installs. Before this patch, by default, badge
                   creators would not receive an email (or any notification) if they were
                   logged in.

    TL-8065        Improved the accessibility of the question bank export
    TL-8066        Improved the performance of the Audience enrolments sync
    TL-8073        Blogs are now disabled by default in new installations
    TL-8093        Improved the display of select boxes with a specified size


Bug fixes:

    TL-6789        Fixed the handling of transactions when exceptions occur within HR Import user sync

                   Prior to this patch, if an exception was generated while assigning user
                   positions, the exception would be handled and processing would continue.
                   However, if the exception occurred within a database transaction, the
                   transaction was not being cleaned up.

    TL-7355        Managers approving Face-to-face booking requests are now notified of the updates success

                   Previously, when a manager approved staff requests for bookings into a
                   Face-to-face session, they would then be redirected to a page saying 'You
                   can not enrol yourself in this course' (assuming they were not enrolled or
                   did not have other permissions to view the attendees page). Following any
                   approvals (by a manager or any other user), the page will now refresh onto
                   the approval required page, with a message confirming the update was
                   successful.

    TL-7426        Fixed the course completion status of users after their RPL is deleted

                   Previously their completion would not be re-aggregated until they made
                   further progress in the course, now it is re-aggregated immediately.

    TL-7504        Updated the permissions for the unobscured user email column in Report builder reports

                   Previously the unobscured user email column and filter were only shown when
                   email was turned on in user identity settings, now it is also shown if the
                   user has the site:config capability. This ensures that the admin can use
                   these columns regardless of the user identity setting.

    TL-7521        Fixed values for position start and end dates when syncing with database source

                   If an external database that was being synced via HR Import contained a
                   Null value for position start date and position end date, this was throwing
                   an error. Null values will now mean that no value will be added to the
                   position details.

                   In addition to this, if a position start or end date field contained the
                   value 0, the value added into the position details in Totara would be the
                   current time. This has been changed such that 0 and null are equivalent and
                   result in no value being added to the position details. This is consistent
                   with imports via CSV.

    TL-7620        Fixed the display of defaults for text input custom fields in Report builder
    TL-7712        Fixed an issue with assigning a large number of users to programs

                   Previously when a large number of individuals were already assigned to a
                   program, adding more assignments could lead to an HTTP 414 error due to a
                   large amount of data being included in the URL.

    TL-7729        Replaced hardcoded strings with lang strings in the old program catalog
    TL-7731        Fixed the display of non-latin characters in program summaries when viewing Report builder reports
    TL-7781        Fixed pop-up behaviour for admins using a single-activity course with a file
    TL-7842        Fixed stuck certification completions due to a bug previously fixed in TL-6979

                   Certifications which experienced the problem which was fixed in TL-6979
                   would be stuck after upgrading. This patch will repair those records by
                   triggering the window open event again. The records will be in the correct
                   state after installing the upgrade and then running the Update
                   Certifications scheduled task.

    TL-7879        Stopped Program un-enrolment messages being sent to suspended users
    TL-7904        Fixed Terms & Conditions dialog box for Face-to-face direct enrolment plugin
    TL-7911        Fixed the restoration of certificate user information on different sites
    TL-7915        Added missing include to the Competency Status History report source
    TL-7917        Fixed the "User is suspended" dynamic audience rule when it is used more than once in the same rule set
    TL-7925        Fixed an issue with duplicate grade items when using the assignment submissions report source
    TL-7927        Fixed SCORM activities set to "display package" in the "new window (simple)" mode
    TL-7931        Fixed the booked-by & actioned columns in Face-to-face session report sources

                   The columns now display the actual user name and link instead of the
                   "Reserved" word for the "Booked by" and "Actioned by" columns.

    TL-7953        Stopped the surround legend style from being applied to child elements in Totara themes
    TL-7965        Fixed consecutive usage of the Face-to-face attendees menu option

                   Previously after adding or removing users via the attendees page, you would
                   have to refresh the page before it would work again.

    TL-7966        Replaced hardcoded "Advanced options" string with a translatable string in Report builder
    TL-7971        Corrected the positioning of short form date pickers for rtl languages
    TL-7980        Fixed the deletion of scheduled reports
    TL-7997        Fixed the shortname field for Goal types
    TL-8010        Removed unformatted html from output when exporting a user's Record of Learning to PDF
    TL-8026        Fixed the display of Face-to-face session details within Calendar events
    TL-8048        Fixed the sidebar filter for Report builder reports with paging

                   When a sidebar filter is changed, you will be taken back to the first page
                   of results (as happens with other search and filters). This patch also
                   fixes a problem which occurred if the toolbar search was used immediately
                   after using a sidebar filter.

    TL-8050        Prevent the deletion of unrelated scheduled report recipients when deleting a scheduled report

                   Previously if the ID of the scheduled report being deleted matched the ID
                   of a Report builder report, all recipients for scheduled reports based off
                   that report would also be incorrectly deleted.

    TL-8121        Corrected the display of certification due dates when exporting to pdf


Contributions:

    * Artur Rietz at Webanywhere - TL-8010
    * Chris Wharton at Catalyst NZ and Haitham Gasim at Kineo USA - TL-7980
    * Haitham Gasim at Kineo USA - TL-8026
    * Pavel Tsakalidis at Kineo UK - TL-7975
    * Tim Price at Catalyst Australia - TL-7911


Release 2.9.1.1 (9th December 2015):
====================================


Bug fixes:

    TL-8096        Fixed course module completion calculation

                   This fixes a regression introduced by TL-6981 in 2.9.1, 2.7.9, 2.6.26, and
                   2.5.33 in which the calculation of course module completion would lead to
                   all activities being marked complete incorrectly for a user.
                   The problem occurs when the user completes the first activity in the
                   course. It occurs if the user manually marks themselves complete, achieves
                   the completion criteria (with the exception of "Student must view this
                   activity to complete it"), or is marked complete by a trainer. The user
                   must then log out and log back in again in order to see the problem.
                   The problem will not occur if it is not the first activity in the course.
                   When this occurs all activities in the course will be marked complete,
                   regardless of which section or order they are within the course and
                   regardless of whether they are required for course completion or not.


Release 2.9.1 (16th November 2015):
==================================================


Security issues:

    TL-7886        Fixed access checks for the position assignment AJAX script
    TL-7829        Removed reliance on url parameter for choosing table

                   The script for getting the positions and organisations to assign to a
                   program relied on a url parameter to choose which table to access. The
                   table is now chosen according to the type of hierarchy that the query is
                   for.

    MoodleHQ       Security fixes from MoodleHQ http://docs.moodle.org/dev/Moodle_2.9.3_release_notes

                   Security related issues:
                   * MDL-51861 enrol: Don't get all parts in get_enrolled_users with groups
                   * MDL-51684 badges: Make sure 'moodle/badges:viewbadges' is respected
                   * MDL-51569 mod_choice: validate user actions and availability
                   * MDL-51091 core_registration: session key check in registration.
                   * MDL-51000 editor_atto: No autosave for guests
                   * MDL-50837 mod_scorm: Fix availability checks
                   * MDL-50426 messaging: Fix permissions checks when sending messages
                   * MDL-49940 mod_survey: Fix XSS
                   * MDL-48109 mod_lesson: prevent CSRF on password protected lesson


Improvements:

    TL-6282        Improved handling and displaying of the user's name in Core dialogs
    TL-6529        Added the manager's email as a selectable column for reports that include user's position fields
    TL-6657        Added actual due dates to program Assignments and audience Enrolled Learning tabs

                   The Assignments tab in programs and certifications and the Enrolled
                   Learning tab in audiences now include a column "Actual due date". This new
                   column shows the due date that the user will see. For group assignments
                   (such as audiences or organisations), clicking the "View dates" link will
                   show a popup with a list of all assigned users relating to that group
                   assignment. The help popup for the "Actual due date" column explains why
                   assignment due dates may be different from the actual due dates. After
                   upgrading, the "Actual due date" field can be manually added to the
                   "Audience: Enrolled Learning" embedded report, or you can reset it to the
                   default to have it automatically added.

    TL-7183        Trigger updates to program user assignments when changing assignments via the audience Enrolled Learning tab

                   When you make a change in an audience's Enrolled Learning tab, it will
                   immediately trigger an update of program and certification user
                   assignments. If there are less than 200 total users involved in the program
                   then the users will be processed immediately, otherwise the update will be
                   deferred. By default, deferred program user assignments are processed the
                   next time cron runs. This patch makes the behaviour consistent with making
                   changes in a program's Assignments tab.

    TL-7256        Mark programs for deferred user assignment update when assignment membership changes

                   This patch includes several improvements which cause program and
                   certification memberships to be updated sooner:
                   * When audience membership changes, either by a user manually editing an
                   audience or when a dynamic audience's membership is automatically updated,
                   related programs and certifications will be marked as having user
                   assignment changes deferred.
                   * When a user's assigned position, organisation or manager change, programs
                   and certifications related to the old and new positions, organisations and
                   management hierarchy are marked as having user assignment changes
                   deferred.

                   With this change in place, all changes to program membership should now be
                   detected as they occur and are either processed immediately or by the
                   "Deferred program assignments changes" scheduled task. As such, we
                   recommend setting the related tasks to their default schedules: "Deferred
                   program assignments changes" can be run every time cron runs, while
                   "Program user assignments" only needs to be run once per day.

    TL-7575        Removed Totara menu from the print layout
    TL-7741        Removed HTML table behind the Weekend Days setting
    TL-7745        Added labels to settings on Site administration > Front page > Front page settings
    TL-7748        Improved Accessibility when editing the Site administration > Plugins > Activity modules > Quiz Settings
    TL-7750        Improved layout of "User Fullname (with links to learning components)" Report builder column
    TL-7792        Added settings to enforce https access and prevent embedding of content in external Flash and PDF files
    TL-7813        Reduced events triggered when program user assignments are updated

                   Some events were being triggered unnecessarily when updating program and
                   certification user assignments. They will now only be triggered if it is
                   certain that there are changes that need to be signalled.

                   Please remember that user_assignments_task by default is scheduled to
                   execute just once per day, whereas assignments_deferred_task is designed to
                   be run every time cron runs.

    TL-7824        Moved program user assignment deferred flag reset to start of function

                   If changes are made to a program's assignments while the function is
                   running in cron, those changes will be processed the next time the deferred program
                   assignments scheduled task runs (default: Every cron run), rather than having to
                   wait until  program user assignments scheduled task runs (default: Nightly) or
                   another change is made.

    TL-7878        Added a page title when adding and removing Feedback360 requests with javascript turned off


Bug fixes:

    TL-6936        Face-to-face direct enrolment plugin allows users to signup to more then one Face-to-face.

                   Users can now sign up to one session per Face-to-face in the course via the
                   Face-to-face direct enrolment plugin. If at least one of the session
                   signups was successful then user will be enrolled to the course.

                   If all successful signups require managers approval then course enrolment
                   will be pending. T&Cs when enabled are required and will be checked before
                   any signups or enrolments are processed.

    TL-6957        Display correct due date value in the upcoming certifications block
    TL-6981        Reaggregate course completion when activity completion criteria are unlocked without deletion

                   Previously, course completion status was only reaggregated if "unlock with
                   delete" was used. If "unlock without delete" was used, it was possible that
                   users who meet the new completion criteria were not marked complete, and
                   this would not be fixed by any cron task. This could lead to users being
                   stuck with an incomplete status. Now, the records will be marked for
                   reaggregation and will be processed by the completion cron task.

    TL-7273        Corrected the help text for Report builder simple select filters

                   Filters that use a drop-down select with no additional options such as 'not
                   equal to' now have correct corresponding help text, rather than referring
                   to additional options that do not exist.

    TL-7437        Switched the badges backpack URL to use HTTPS
    TL-7514        Fixed the display order of Face-to-face sessions for the Face-to-face direct enrolment plugin

                   Sessions will now be displayed in order of their start date/times instead
                   of when they were created

    TL-7559        Enabled the transfer of position and organistion custom fields for the database source of HR Sync
    TL-7562        Fixed strings for audience rules based on course and program completion
    TL-7594        Fixed users booked on a Face-to-face session with no dates being incorrectly removed when another user cancels their booking
    TL-7602        Re-enabled the Save and Cancel buttons for the Face-to-face take attendance tab

                   Save and Cancel buttons present in previous versions have been reintroduced
                   to the Face-to-face take attendance tab. Save must be clicked in order to
                   update attendance records.

    TL-7611        Fixed the handling of username and suspended fields for external database sources in HR Import
    TL-7644        Corrected the amount of white space in the 'recordoflearning' language string
    TL-7659        Prevented cancellation notifications being sent to users booked in completed Face-to-face sessions when the course is deleted
    TL-7660        Fixed the behaviour of pagination on hierarchy index pages

                   When viewing Positions, Organisations, Competencies or Goals within a
                   framework, pagination was not working correctly and instead was displaying
                   all of the items even though the paging bar was displaying the correct
                   number of pages.

    TL-7664        Fixed dynamic audience rules based upon checkbox position custom fields
    TL-7675        Fixed the display of an aggregation warning for Report builder columns

                   The warning that column aggregation options may not be compatible with
                   reports that use aggregation internally is now shown only for reports that
                   actually use aggregation internally.

    TL-7676        Fixed the display of duplicate categories in pie charts
    TL-7686        Fixed URL validation when adding new links to the quicklinks block
    TL-7695        Re-aggregate when course completion criteria is changed without deletion

                   When changing course completion criteria, and unlocking without deleting
                   existing completion data, re-aggregation was not being performed. Now,
                   users who are assigned but not complete and match the new criteria will be
                   marked complete after cron re-aggregates them. To fix any users affected by
                   this problem, an upgrade script will mark all incomplete users in all
                   courses for re-aggregation, which will be performed by cron, and may take a
                   while to process on larger sites.

    TL-7698        Fixed the handling of position and organisation 'Text area' custom fields within HR Import
    TL-7711        Fixed the "duedate(extra info)" column for Report builder export to pdf
    TL-7724        Fixed an error when adding audience visibility during program creation.

                   A user who was assigned the site manager role within a category context
                   would previously be presented with an error when giving audiences
                   visibility during program creation. This error no longer appears.

    TL-7732        Allow HR import to set posenddate value as blank when posstartdate is set
    TL-7769        The Report builder "Manager's name" filter now counts users without a manager as "empty"
    TL-7770        Fixed date validation for Face-to-face sessions when removing dates or wait-listing a session
    TL-7783        Fixed the ordering of the Face-to-face waitlist

                   Previously when a user cancelled an overbooked session the Face-to-face
                   replaced them with a user from the waitlist based off the user's names, now
                   the replacement is decided based off their signup time.

    TL-7784        Fixed the help text for Face-to-face 'minimum capacity' setting
    TL-7789        Fixed the formatting of the Face-to-face intro page
    TL-7821        Fixed a Totara Connect upgrade step that introduced a non-existent local plugin
    TL-7833        Fixed cron failure when sending Face-to-face notifications

                   When scheduled Face-to-face notifications were being sent out, the cron
                   task would potentially fail if notifications were going to users who had
                   their session bookings approved by a manager. This has now been fixed,
                   notifications go out as normal, and cron is not disrupted.

    TL-7836        Ensured images are restricted by their assigned widths

                   If an image is resized from its native dimensions and then displayed,
                   Internet Explorer would display the image at its native size, and not the
                   size that had been requested.

    TL-7844        Grader report now scrolls when it is too wide for the screen
    TL-7849        Removed reports and saved searches from the report table block when users do not have access
    TL-7851        Fixed the display of the "duedates" column for program and certification overview Report builder reports
    TL-7876        Stopped the incorrect archiving of facetoface sessions without dates

                   Previously if a user was waitlisted on a Face-to-face session which had no
                   dates set, in a Certification Course. When the user's recertification
                   window opened, the signup would be marked as archived, meaning it would no
                   longer count towards course completion.

    TL-7881        Recreate course completion records when activity criteria are reset with deletion

                   Course completion records for users who were not complete according to the
                   new criteria were not being recreated immediately. Although the records
                   were being created when the completion cron task was run or when a user's
                   status in the course changed, it was possible that some unexpected
                   behaviour could have occurred due to the missing records.

    TL-7883        Fixed date handling on the Face-to-face block calendar page
    TL-7909        Make sure url params are passed when using report builder toolbar search
    TL-7921        Fixed regression with media playback when request_order="GPC" in PHP.ini


Release 2.9.0 (3rd November 2015):
==================================

New features:

    TL-2250        New options to turn off extension requests for programs and certifications

                   It is now possible to disable program/certification extension requests both
                   for the whole system and for individual instances via the edit details page.

    TL-2565        New "Fixed date" custom user profile field type

                   A fixed date new custom user profile field type has been added.
                   This new field type is designed to store absolute dates for which
                   timezones are irrelevant and not applied.
                   An example of where this field is applicable is your birthday.
                   Regardless of your location you birthday is the same.

                   Data for this date field is stored as midday UTC for the selected date.

    TL-7098        Dynamic audience rules for the new fixed date custom user profile field

                   These rules include being able to define an audience according to their
                   custom profile field date being before or after a fixed date.
                   There are also duration-based rules, meaning they can be set according to
                   the profile dates being within or before a previous number of days, as well
                   as within or after an upcoming number of days.

                   Notes:
                      * With duration-based rules audiences will be updated at midday UTC.

    TL-4485        New personal goal types with custom fields

                   Personal goal types can now be defined and custom fields added to them.
                   Preexisting goal types have been renamed to company goal types and continue to
                   function as they did previously.
                   Personal goal types differ from company goal types in that the custom field
                   values entered for a personal goal will be associated with the user whom
                   the personal goal belongs to.

                   Thanks to Ryan Lafferty at Learning Pool for the contribution.

    TL-5094        Support for anonymous 360 feedback

                   We have added a new "Anonymous" setting when creating or editing a
                   360 Feedback.
                   Enabling this hides the name of responders to the 360 Feedback.
                   Responders can see whether a 360 Feedback is anonymous in the header of the
                   response page, along with the number of requests sent.
                   This setting does restrict some functionality to maintain anonymity:

                      * When enabled, requests for feedback can only be added, they can not be
                        cancelled. This is to stop users from potentially cancelling all
                        requests in order to figure out who has replied.
                      * Reminders can still be sent but who will receive them will no
                        longer be displayed to you.

                   While we have endeavoured to enforce anonymity please be aware that
                   responders are still recorded and there are ways to get this information
                   out of the system, such as:
                      * Site logs.
                      * Malicious code written to reveal it.
                      * Direct database investigation.
                      * Activity logs
                      * Blocks displaying Recently logged in users

    TL-5097        New options to disable changes in membership for dynamic audiences

                   With this feature you can now control if users are automatically added or
                   removed from a dynamic audience's membership when they meet, or no longer
                   meet, the criteria defined by the rule set.
                   This is facilitated with a new setting "Automatically update membership"
                   which can be found on the rule sets tab when editing a dynamic audience.
                   This new setting has two options, both of which are enabled by default:

                      * Make a user a member when they meet rule sets criteria
                      * Remove a user's membership when they no longer meet the rule sets
                        criteria

                   Toggling these settings allows you to prevent new members being added to
                   the audience and/or prevent users from being removed from the audience.

    TL-5818        Report builder reports can now be cloned

                   Added a new action that clones reports to the Report builder manage
                   reports page. Cloning a report creates a full copy of the report
                   and its columns, filters and settings. It does not copy any scheduling
                   or caching that has been set up for the report.
                   Both user created and embedded reports can be cloned.

                   In order to clone a report the user must have the
                   totara/reportbuilder:managereports capability.

    TL-6023        New program completion block

                   A new program completion block has been added in this release that lists
                   one or  more selected programs and the users completion status for each.
                   If no programs have been selected the block is not displayed.

                   Thanks to Eugene Venter at Catalyst NZ for the contribution

    TL-6525        New report table block

                   Added new block that displays tabular data belonging to a selected Report
                   builder report.
                   Optionally a saved search for the report can also be selected to limit the
                   data shown in the block.

                   Notes:
                      * Backward incompatibility of saved searches with third party filters
                        might occur. If saved searches do not work with your third party
                        filters, please contact the developer of the filters to update them.
                      * Only user created reports can be selected. Embedded reports cannot
                        be used within this block at present.

                   Thanks to Dennis Heany at Learning Pool for the contribution.

    TL-6621        Report Builder export is now pluggable

                   Reportbuilder export code was abstracted into a new plugin type 'tabexport'
                   located in folder '/core/tabexport'.
                   Tabular export plugins may now have settings and administrator can disable
                   individual export plugins.
                   New plugins have to include a class named '\tabexport_xyz\writer' that extend
                   base class '\totara_core\tabexport_writer'.
                   The base class contains a basic developer documentation, included plugins
                   can be used as examples.

    TL-6684        Added new global report restrictions

                   Global report restrictions allows rules to be applied to a report
                   restricting the results to those belonging to the users you are allowed to
                   view.
                   This allows you to define relationships between groups of users limiting
                   the information a user can see to just information belonging to the
                   permitted group or groups of users.

                   Notes:
                      * All users including the administrator can be restricted.
                      * Global report restrictions are only supported by report sources where
                        data can be seen as owned by one or more users.
                      * There are internal limitations for some database backends. For example
                        MySQL is limited to 61 tables in one join which may limit the maximum
                        number of items in each restriction.
                      * Active restrictions may impact the performance of reports.
                      * Report caching is not compatible with Global Report Restrictions and
                        is ignored when restrictions are active.

                   Thanks to Maccabi Healthcare Services for funding the development of this
                   feature.

    TL-6942        Define and use different flavours of Totara during installation and upgrade

                   A new feature set including plugin type has been added called Flavours.
                   Flavours can change default settings, the sites actual settings, and force
                   settings into a specific state.
                   During installation and upgrade the selected Flavour is applied allowing it
                   to control which settings get turned on or off.
                   It is also given the opportunity to execute code post installation or
                   upgrade.

                   Notes:
                      * Sites that do not use a specific flavour will default to the
                        Enterprise flavour that ships with Totara.
                        This flavour does not make any configuration changes.
                      * This feature was added for the benefit of Totara Cloud to allow us to
                        control cloud functionality. It is not used by default by Totara and
                        provides no new functionality

    TL-7021        Added a new setting to the advanced features page that enables/disables Competencies
    TL-7105        Added optional support for producing PDF snapshots of Appraisals via wkhtmltopdf executable
    TL-7246        Totara Connect Client

                   Totara Connect makes it possible to connect one or more Totara LMS or
                   Totara Social installations to a master Totara LMS installation.
                   This connection allows for users, and audiences to be synchronised from the
                   master to all connected client sites.
                   Synchronised users can move between the connected sites with ease
                   thanks to the single sign on system accompanying Totara Connect.


Improvements:

    TL-2368        Capability to manage reminders added to courses

                   A new capability moodle/course:managereminders has been created to allow
                   fine grained control over which roles can manage reminders within a
                   course.
                   Prior to this capability the moodle/course:update capability was used.
                   Now both capabilities are required.
                   Only site managers are given this capability by default.

    TL-5020        Change of 'from' email address when sending emails

                   Now all Totara messages (Email and alerts) use the system wide
                   "noreply" address as the "From" address.
                   This can be configured by the admin via 'Site administration > Plugins >
                   Message outputs > Email > No reply address'.

                   In the case of Facetoface, where there is another setting in 'Site
                   administration > Plugins > Activity modules > Facetoface > Sender From' the
                   system will send Facetoface messages from that address if it is set, or from
                   the no-Reply address otherwise.

    TL-5088        Logo now scales for smaller screens

                   When using the Custom Totara Responsive theme with a custom logo uploaded,
                   it now scales on smaller screens

    TL-5239        Added several new columns to the site log report source

                   This change introduced several new columns to the site log report source:

                      * A new column "Event name with link"
                      * A new column "Context"
                      * A new column "Component"
                      * A new filter "Event name"

                   This now facilitates filtering by event name (for example this report can
                   can show only "Course Completed" events) as well as providing a column that
                   links to event source (corresponding course, report, user, etc).

    TL-5356        Added new user columns and filters to the Messages report source

                   The standard user information columns and filters have been added to the
                   messages report source.
                   This allows you to find out information such as who the message was sent
                   to.

    TL-5362        Assessor, Regional Manager and Regional Trainer roles were removed

                   Previously roles Assessor, Regional Manager and Regional Trainer were
                   automatically created during Totara installation. These roles did not have
                   any special capabilities by default.
                   As of Totara 2.9.0 these roles will no longer be automatically created.
                   If you need them you may easily create them and add any required
                   capabilities.

    TL-5394        The initialdisplay setting can now be passed when creating embedded reports

                   Thanks to Russell England at Vision NV for the contribution.

    TL-5511        Added pagination to the bottom of Report builder reports

                   When viewing a report pagination is now shown both above and below the
                   report.

    TL-5954        Added a link between the start and finish date pickers for Facetoface sessions

                   The start and finish date pickers are now linked so when changing the start
                   date the finish date will automatically change to the same day.

    TL-6022        Added the AND operator to course set operators in Programs and Certifications

                   This allows people to create rules such as "Learner must complete one of
                   course1, course2, course3 AND one of course4, course5, course6".

                   Thanks to Eugene Venter at Catalyst NZ for the contribution.

    TL-6154        Refactor filters to use named constants instead of numbers

                   Previously filter operators within code were represented just as integers.
                   This change introduced new constants to make the handling of these
                   operators much clearer.

    TL-6204        Customisable font when exporting a report to PDF

                   A new setting has been introduced that allows the font used within Report
                   builder PDF exports to be customised.
                   This allows those on non-standard installations to work around required
                   fonts that they do not have.

    TL-6206        Improvements of CSV export in Report builder

                   CSV export now starts sending data immediately instead of waiting for the
                   whole file to be generated.
                   The total processing time is the same, memory usage is decreased and users
                   may download the file in the background.

    TL-6308        Improve control over who can approve Facetoface attendance requests

                   A new capability mod/facetoface:approveanyrequest has been added that is
                   now required in order to approve Facetoface session attendance request.
                   Prior to this patch only site administrators or a user's assigned manager
                   could approve a request. Now anyone with this capability can also approve
                   an attendance request.
                   This capability is not given to anyone by default.

                   Thanks to Eugene Venter at Catalyst NZ for the contribution.

    TL-6383        Improved accessibility of the general settings page

                   Previously there was an empty label associated with the warnings checkbox
                   following the "Send notifications for" label. This has now been improved so
                   that "Send notifications for" is now a legend and the "Errors" and
                   "Warnings" checkboxes now have labels correctly assigned to them.

    TL-6413        Report builder sources may now be marked as ignored

                   The Report builder report source API has been extended so that report
                   sources can now inform Report Builder that they should be ignored.
                   Report builder can then choose to treat an ignored source differently, at
                   the very least ensuring that it is not accessible.

                   This can be used in situations such as when the source depends upon a
                   plugin or feature being enabled.
                   Previously this would could lead to errors if someone tried to use the
                   source.
                   Now it is dealt with gracefully.

    TL-6414        Added several new placeholders to Facetoface notifications

                   The following placeholders were added for notification emails regarding
                   Facetoface sessions:

                      * [lateststarttime] - Start time of the session. If there are multiple
                        session dates it will use the last one.
                      * [lateststartdate] - Date at the start of the session. If there are
                        multiple session dates it will use the last one.
                      * [latestfinishtime] - Finish time of the session. If there are multiple
                        session dates it will use the last one.
                      * [latestfinishdate] - Date at the end of the session. If there are
                        multiple session dates it will use the last one.

                   These can be used in conjunction with existing placeholders that use the
                   first session date. For example: "[starttime], [startdate] to
                   [latestfinishtime], [latestfinishdate]" will give the overall start and
                   finish times of a multi-date session.

    TL-6451        Added option in HR Import to force password reset when undeleting users

                   Previously, users would have their password reset if it was not provided in
                   the same import. This change makes the reset optional. If a password is
                   provided in the import then it will still take precedence and the reset
                   will not occur.

    TL-6453        Added a time due column to the program and certification completion report sources

                   Thanks to Eugene Venter at Catalyst NZ for the contribution

    TL-6454        Improved the robustness of Facetoface archive tests

                   Thanks to Andrew Hancox at Synergy Learning for the contribution.

    TL-6496        Added several new filters to the certification overview report source

                   The following filters have been added to the certification overview report
                   source:

                      * Add status
                      * Renewal status
                      * Time completed

                   Thanks to Eugene Venter at Catalyst NZ for the contribution.

    TL-6497        Added a timedue filter to the program overview report source

                   Thanks to Eugene Venter at Catalyst NZ for the contribution.

    TL-6531        Improved the performance of prog_get_all_programs

                   Thanks to Pavel Tsakalidis at Kineo UK for the contribution

    TL-6605        Improved the alignment of advanced checkbox labels in all themes
    TL-6629        DOMPDF library has been updated to 0.6.1

                   DOMPDF has been upgraded from 0.6.0 to 0.6.1.
                   This upgrade includes a large number of fixes to both bugs and stability.

    TL-6655        Removed legacy md5 hashing from lessons and lesson user / group overrides
    TL-6667        Course completion now correctly considers activity completion without a grade as complete

                   This patch fixes an inconsistency in how activity completion gets treated.
                   Prior to this patch if you achieved activity completion without getting a
                   passing grade for that activity some places would consider it as complete
                   and others would not.
                   This is now consistently and correctly considered to be complete by all
                   areas of Totara that work with activity completion.

    TL-6676        Improved responsive design when viewing an appraisal
    TL-6761        Updated jQuery dataTables plugin from version 1.9.4 to 1.10.7
    TL-6777        Minified Totara specific JavaScript files

                   Currently there are a large number of JavaScript files that are transferred
                   from your Totara server that are not minified. This issue minifies files
                   for Totara dialogues, and ensures the jQuery plugin files that we use are
                   minified. The minified files are only delivered if the cachejs
                   configuration value is set to true (as it should be on production sites).

                   Minified files reduce the amount of data that is transferred from the
                   server to the browser, resulting in faster page loading times (although
                   this may not be noticeable).

    TL-6880        Role definition page now shows the number of users having each role
    TL-6913        Reviewed language strings that used Moodle and improved them where required
    TL-6915        Forum post emails are now using "totaraforumX" in list ids.
    TL-6919        Installation and upgrade reliability improvements

                   The following changes have been made to the installation and upgrade
                   process:

                   * Fixes and improvements in install and upgrade logic
                   * Fixed Totara plugin environment tests
                   * Fixed missing 'canvas' theme when upgrading from Moodle

    TL-6920        Session Cookie names now use Totara as a prefix
    TL-6926        Improved memcached cache store prefix handling

                   Prior to this patch if no prefix was specified and the settings for the
                   cache store instance were changed, the cache environment could become
                   corrupt and the cache would need to be manually purged.
                   Now if no prefix is specified, a hash is generated from the store instance
                   settings and this is used as the prefix.
                   As the prefix will now change when the settings change, keys cannot conflict
                   and this avoids any need to manually purge the cache.
                   Those who have a prefix set will still need to manually manage their
                   memcached purging if they change any settings.

    TL-6931        Curl requests made by Totara now use a specific TotaraBot agent string
    TL-6943        Support generating of tree structures when bulk adding hierarchy items

                   It is now possible to use the bulk add functionality to generate a tree
                   structure instead of just a flat list of new items. Use 2 spaces in front
                   of the item name to indent an item by one level.

    TL-6961        Each custom field type is now managed by a single capability

                   In Totara 2.7 and all older versions every custom field type had three
                   capabilities used to manage them (create, edit, delete).
                   This improvement sees the capabilities simplified so that each custom field
                   type uses only a single capability for management instead of the three.
                   This ensures that any actions taken by a user can also be undone, it also
                   greatly simplifies management of capabilities around custom field types.
                   The old create, edit, and delete capabilities have been removed.

                   The following is a list of custom field types and the new capability that
                   is used to manage them:

                   * Facetoface custom fields managed by mod/facetoface:managecustomfield
                   * Course custom fields managed by totara/core:coursemanagecustomfield
                   * Program and Certification custom fields managed by
                     totara/core:programmanagecustomfield
                   * Competency custom fields managed by
                     totara/hierarchy:competencymanagecustomfield
                   * Goal custom fields managed by totara/hierarchy:goalmanagecustomfield
                   * Organisation custom fields managed by
                     totara/hierarchy:organisationmanagecustomfield
                   * Position custom fields managed by
                     totara/hierarchy:positionmanagecustomfield

    TL-7013        Installer now only shows available language packs

                   Prior to this change the installation process showed all possible language
                   packs, rather than just those that were available.

    TL-7019        Dashboard functionality can now be disabled via advanced features
    TL-7022        My Team functionality can now be disabled via advanced features
    TL-7031        The URL download repository is now disabled by default on new installations

                   This change is intended to improve security. We strongly recommend that those sites
                   which are upgrading also disable this repository, unless they are actually using its
                   functionality.
                   The repository itself allows content to be downloaded from the internet and
                   used within the site.
                   Whilst measures are taken to ensure the download and use of internet
                   content is handled safely and securely it is not possible to completely
                   inoculate the system from threat.
                   We recommend putting the Totara server into a DMZ if this repository is
                   enabled and used.

    TL-7038        Report default sort order is used consistently after report updates
    TL-7072        Converted Facetoface predefined room JS into an AMD module

                   The previously defined totaraDialog_handler_addpdroom has been converted to
                   an AMD module allowing the module to be loaded only when needed.

    TL-7140        Improved the display of Totara table borders such as those used for embedded reports
    TL-7159        Facetoface predefined rooms are no longer required to specify a name, building or address

                   The capacity field is still required.

    TL-7162        Converted the myappraisal JS to an AMD module

                   The M.totara_appraisal_myappraisal JavaScript code has been converted from
                   a statically loaded JS file to an AMD module.
                   This allows the JS to be loaded dynamically with much greater ease and
                   unlocks the benefits AMD brings such as minification and organisation.

                   This change removes the totara/appraisal/js/myappraisal.js file.

    TL-7197        Converted plan templates JS into an AMD module

                   The totara_plan_template JS class has been converted into an AMD module
                   allowing it to be required only when needed.

    TL-7198        Converted the totara_plan_component JS into an AMD module

                   The totara_plan_component JavaScript class has been converted into an AMD
                   module allowing it to be required only when needed.

                   The totara/plan/component.js file was removed as part of this change.

    TL-7236        Login prompt state is now maintained across invalid attempts

                   The state of the the login prompt is now maintained upon a failed
                   authentication attempt.
                   The username entered by the user will remain in the username field, and the
                   state of the remember username checkbox will persist.

    TL-7237        Serving of user submitted files has been hardened to improve security

                   The headers used when serving user submitted files has been improved.
                   Mime type handling has been improved and the following headers are now
                   included when the file being served is forcing a download:

                   * X-Content-Type-Options: nosniff
                   * X-Frame-Options: deny
                   * X-XSS-Protection: 1; mode=block

    TL-7244        Converted M.totara_cohort_assignroles JS into an AMD module

                   The file totara/cohort/assignroles.js has been removed as part of this
                   change.

    TL-7293        Session timezone is now used for date fields when editing Facetoface session
    TL-7297        Guest access is now disabled in new installations
    TL-7331        New framework for improved error message handling when AJAX calls fail

                   Previously there was no framework for when a jQuery AJAX call fails.
                   This can leave a number interactions in Totara with nondescript errors.
                   This fix provides a framework for errors to be caught, handled and
                   displayed. It also provides debugging information when debug has been
                   turned on allowing JS issues to be investigated with much more ease.

    TL-7384        Begin phasing out the "Hide" option for advanced Totara features

                   Previously many of the advanced features added in Totara could be set to
                   three states enabled, disabled, hidden.
                   The hidden state in many situations was poorly and inconsistently
                   implemented.
                   After discussions it was decided that the hidden state would be removed in
                   favour of a more straight forward enabled/disabled state.

                   Any sites using the "Hide" state will continue to experience the same
                   behaviour they have previously.
                   However the "Hide" state is no longer made available for selection.
                   In the future support for the "Hide" state will be removed.

    TL-7388        Improved reliability of the Atto editor superscript and subscript buttons
    TL-7389        Improved rtl language support for the collapse block icon

                   This introduces a new icon that points to the right in right to left
                   languages (such as Hebrew) when a block is collapsed (t/switch_plus_rtl)

    TL-7432        Added a new capability to allow marking of course completion for related users

                   A new capability has been added totara/core:markusercoursecomplete which
                   can be assigned within the user context and allows a user with that
                   capability to mark another user's required learning courses as complete.
                   Previously, this was only possible for managers marking completion for
                   their staff.

                   This new capability is not given to anyone by default.

    TL-7482        Updated the TCPDF library from 6.2.6 to 6.2.12
    TL-7510        Improved the flow of links within the Appraisal report source
    TL-7524        Improved the secure page layout within standard Totara responsive
    TL-7529        Fixed handling of RPL records when resetting or deleting a course or its completions

                   This change fixes how RPL records are handled when a course is reset by a
                   certification, deleted or reset by a user, or course completions unlocked
                   by a teacher.

                   When deleting or resetting a course, RPL completions are now also deleted
                   correctly. Previously these were not removed. An upgrade step will safely
                   remove invalid data records for deleted courses.

                   In 2.9.0 when a users course completion gets reset by a certification
                   window opening, all course and activity RPL completions will be removed.

                   As before, when a teacher unlocks course completion criteria and selects to
                   delete, course and activity RPL records will be kept and still count
                   towards a users completion.

                   Thanks to Eugene Venter at Catalyst NZ for the contribution

    TL-7530        Improved the display of error messages for date controls
    TL-7589        Added timezone support to plans and plan templates
    TL-7682        Improved the date display code to ensure it is consistent across all platforms

                   Language packs may now use all strftime parameters as listed here
                   http://php.net/manual/en/function.strftime.php


Accessibility improvements:

    TL-5275        Removed the fieldset surrounding the action buttons within a form

                   Previously the action (submit + cancel) buttons within a form were being
                   printed within a fieldset.
                   In order to improve accessibility across all forms by reducing the number
                   of nested fieldsets this particular fieldset was removed.

    TL-6234        Removed the HTML table used for layout when adding badge criteria

                   This patch also improves accessibility around single selects.

    TL-6239        Improved accessibility when setting a custom room

                   When editing a Facetoface session, the form elements for setting a custom
                   room had labels that were not correctly linked to their HTML elements, and
                   had an unnecessary HTML table.

    TL-6291        Improved the accessibility when viewing learning plans
    TL-6294        Removed the table used for layout on the course participants page

                   When viewing participants within a course, the filters at the top of the
                   page were within an HTML table. This has been removed and replaced with a
                   series of div elements making the page more accessible and responsive.

    TL-6310        Removed incorrect label on the Certificate settings page
    TL-6320        Replaced invalid use of HTML labels within the add activity dialog
    TL-6337        Removed the HTML table used on the group user management page for courses
    TL-6380        Improved accessibility of question bank export
    TL-6381        Improved accessibility of question bank import
    TL-6382        The fieldset template within forms now uses a fieldset

                   There were a number of form fieldsets that were incorrectly used, making a
                   number of web pages inaccessible to screen readers.
                   This change improves accessibility considerably but is likely to cause
                   display problems for themes that have restyled forms.
                   A good place to look at check your theme styles would be by reviewing the
                   form used when adding a Facetoface session.

    TL-6388        Improved accessibility on the users badge profile setting page
    TL-6390        Removed empty labels and legend attributes from all form element
    TL-6394        Removed the HTML label from admin settings when it was not referencing anything

                   What were formerly HTML label elements are now spans with the admin-label
                   css class. Any CSS styles that were applied to HTML labels (in the admin
                   area), will also need to be applied to this class (adjusting the font-size
                   will need to override ".form-item .admin-label")

    TL-6423        Removed the HTML table within a course user details view
    TL-6585        Improved accessibility uploading images into the Certificate module
    TL-7139        Removed heading around no results messages for flexible tables
    TL-7187        Removed the HTML table around user details when inside a chat activity
    TL-7188        Removed the HTML table used for layout when entering a chat message
    TL-7552        Replaced individual hierarchy item description table with a datalist


Database schema changes
=======================

New tables:
Bug ID   New table name
-----------------------------
TL-4485  goal_user_info_data
TL-4485  goal_user_info_data_param
TL-4485  goal_user_info_field
TL-4485  goal_user_type_cohort
TL-4485  goal_user_type
TL-6684  report_builder_global_restriction
TL-6684  reportbuilder_grp_cohort_record
TL-6684  reportbuilder_grp_org_record
TL-6684  reportbuilder_grp_pos_record
TL-6684  reportbuilder_grp_user_record
TL-6684  reportbuilder_grp_cohort_user
TL-6684  reportbuilder_grp_org_user
TL-6684  reportbuilder_grp_pos_user
TL-6684  reportbuilder_grp_user_user
TL-7246  auth_connect_servers
TL-7246  auth_connect_users
TL-7246  auth_connect_user_collections
TL-7246  auth_connect_sso_requests
TL-7246  auth_connect_sso_sessions

New fields:
Bug ID   Table name                New field name
------------------------------------------------------------
TL-2250  prog                      allowextensionrequests
TL-4485  goal_personal             typeid
TL-4485  goal_personal             visible
TL-5094  feedback360               anonymous
TL-5097  cohort_rule_collections   addnewmembers
TL-5097  cohort_rule_collections   removeoldmembers
TL-6684  report_builder            globalrestriction

Modified fields:
Bug ID   Table name                Field name
------------------------------------------------------------
TL-6621  report_builder_schedule   format        Converted from int to char


API Changes
===========

TL-2250 New options to turn off program extension requests
----------------------------------------------------------
 * New totara_prog_extension_allowed function returns true if the given program allows extension requests

TL-2565 Fixed date custom user profile field type
-------------------------------------------------
 * totara_date_parse_from_format has a new forth argument $forcetimezone

TL-4485 New personal goal types with custom fields
----------------------------------------
 * New report source class rb_source_goal_custom
 * New totara_cohort_get_goal_type_cohorts function returns the cohorts associated with a personal goal type
 * customfield_base::customfield_definition has a new optional sixth argument $disableheader
 * totara_customfield_renderer::get_redirect_options has a new optional third argument $class
 * totara_customfield_renderer::customfield_manage_edit_form has a new ninth argument $class
 * hierarchy::get_type_by_id new optional second argument $usertype
 * hierarchy::display_add_type_button new optional second argument $class
 * hierarchy::delete_type new optional second argument $class
 * hierarchy::delete_type_metadata new optional second argument $class
 * New totara_hierarchy_save_cohorts_for_type function to save the cohort/audience data against the
   hierarchy type
 * totara_hierarchy_renderer::mygoals_personal_table new third optional argument $display

TL-5020 Change of 'from' email address when sending emails
----------------------------------------------------------
 * New totara_get_user_from function returns a user to use as the from user when sending emails

TL-5094 Support for anonymous 360 feedback
------------------------------------------
 * New property feedback360->anonymous [bool]
 * totara_feedback360_renderer->display_feedback_header() has two new arguments $anonymous and $numresponders
 * totara_feedback360_renderer->view_request_infotable() has a new argument $anonymous
 * totara_feedback360_renderer->system_user_record() has a new argument $anonymous
 * totara_feedback360_renderer->external_user_record() has a new argument $anonymous
 * totara_feedback360_renderer->nojs_feedback_request_users() has a new argument $anonymous

TL-5097 New options to disable changes in membership for dyanmic audiences
--------------------------------------------------------------------------
 * New event totara_cohort\event\option_updated fired when ever cohort options are updated.
 * New totara_cohort_update_membership_options function to update cohort options. Fires the above event.

TL-5356 Added new user columns and filters to the Messages report source
---------------------------------------------------------------------
 * rb_base_source->add_user_table_to_joinlist() has a new argument $alias
 * rb_base_source::add_user_fields_to_filters() has a new argument $addtypetoheading

TL-5818 Report builder reports can now be cloned
------------------------------------------------
 * New totara_reportbuilder\event\report_cloned event that gets fired when a report is cloned.
 * New reportbuilder_set_default_access function that sets the default restrictive access for new report
 * New reportbuilder_clone_report function to clone a report

TL-6234 Removed the HTML table used for layout when adding badge criteria
-------------------------------------------------------------------------
 * core_renderer::single_select has a new argument $attributes

TL-6310 Removed incorrect label on the Certificate settings page
----------------------------------------------------------------
 * Deleted mod/certificate/adminsetting.class.php and the mod_certificate_admin_setting_upload class within

TL-6413 Report builder sources may now be marked as ignored
-----------------------------------------------------------
 * New reportbuilder::reset_caches static method to reset user permitted report caches
 * New reportbuilder::get_user_permitted_reports static method to get the reports a user can access
 * reportbuilder_get_reports has been deprecated, please use reportbuilder::get_user_permitted_reports instead
 * New rb_base_source::is_ignored method that can be overridden if the report should always be available

TL-6525 New report table block
------------------------------
 * New reportbuilder::overrideuniqueid() to set a unique ID.
 * New reportbuilder::overrideignoreparams() tells report builder to ignore the standard params when
   constructing the next report.
 * New reportbuilder->get_uniqueid() to report the reports unique ID. All external calls to $report->_id
   should be upgraded to use this method.

TL-6684 Added new global report restrictions
--------------------------------------------
 * New rb_global_restriction class which manages report restrictions rules
 * New rb_global_restriction_set class which integrates restrictions into report builder
 * New parameter in reportbuilder constructor which expects instance of rb_global_restriction_set
 * New rb_base_source::global_restrictions_supported method which should be overridden by report sources
   that support Global Report Restrictions
 * New rb_base_source::get_global_report_restriction_join method to inject Global Report Restrictions
   SQL snippet into base query
 * New parameters signature in rb_base_source::__construct now it should be ($groupid, rb_global_restriction_set
   $globalrestrictionset = null) for all inherited classes
 * New reportbuilder::display_restriction method which displays current restrictions and options to change
   them on report pages
 * New rb_base_embedded::embedded_global_restrictions_supported method which should be overridden by embedded
   report classes to indicate their Global Report restrictions support

TL-6942 Define and use different flavours of Totara during installation and upgrade
-----------------------------------------------------------------------------------
 * New Totara Flavour plugins, component is totara_flavour, plugins are flavour_pluginname.
 * New totara_flavour\definition class that all flavours must extend.

TL-6961 Each custom field type is now managed by a single capability
--------------------------------------------------------------------
 * New method totara_customfield\prefix\*_type->get_capability_managefield()
 * Deleted method totara_customfield\prefix\*_type->get_capability_editfield()
 * Deleted method totara_customfield\prefix\*_type->get_capability_createfield()
 * Deleted method totara_customfield\prefix\*_type->get_capability_createfield()
 * Deleted method totara_customfield\prefix\competency_type->get_capability_deletefield()

Capability changes
 * Added capability: totara/core:coursemanagecustomfield
 * Added capability: totara/core:programmanagecustomfield
 * Added capability: mod/facetoface:managecustomfield
 * Added capability: totara/hierarchy:positionmanagecustomfield
 * Added capability: totara/hierarchy:organisationmanagecustomfield
 * Added capability: totara/hierarchy:goalmanagecustomfield
 * Added capability: totara/hierarchy:competencymanagecustomfield
 * Removed capability: totara/core:createcoursecustomfield
 * Removed capability: totara/core:updatecoursecustomfield
 * Removed capability: totara/core:deletecoursecustomfield
 * Removed capability: totara/core:createprogramcustomfield
 * Removed capability: totara/core:updateprogramcustomfield
 * Removed capability: totara/core:deleteprogramcustomfield
 * Removed capability: mod/facetoface:updatefacetofacecustomfield
 * Removed capability: mod/facetoface:createfacetofacecustomfield
 * Removed capability: mod/facetoface:deletefacetofacecustomfield
 * Removed capability: totara/hierarchy:updatecompetencycustomfield
 * Removed capability: totara/hierarchy:createcompetencycustomfield
 * Removed capability: totara/hierarchy:deletecompetencycustomfield
 * Removed capability: totara/hierarchy:updategoalcustomfield
 * Removed capability: totara/hierarchy:creategoalcustomfield
 * Removed capability: totara/hierarchy:deletegoalcustomfield
 * Removed capability: totara/hierarchy:updateorganisationcustomfield
 * Removed capability: totara/hierarchy:createorganisationcustomfield
 * Removed capability: totara/hierarchy:deleteorganisationcustomfield
 * Removed capability: totara/hierarchy:updatepositioncustomfield
 * Removed capability: totara/hierarchy:createpositioncustomfield
 * Removed capability: totara/hierarchy:deletepositioncustomfield

TL-7237 Serving of user submitted files has been hardened to improve security
-----------------------------------------------------------------------------
 * New totara_tweak_file_sending function that gets called before serving files.

TL-7246 Totara Connect Client
-----------------------------
 * Totara Connect makes it possible to connect one or more Totara LMS or Totara Social
   installations to a master Totara LMS installation.
 * This connection allows for users, and audiences to be synchronised from the
   master to all connected client sites.
 * Synchronised users can move between the connected sites with ease thanks to the
   single sign on system accompanying Totara Connect.

TL-7529 Fixed handling of RPL records when resetting or deleting a course or its completions
--------------------------------------------------------------------------------------------
 * New method completion_info->delete_course_completion_data_including_rpl()


Deleted files
=============

Bug ID   File
----------------------------------------------
TL-5094 totara/feedback360/request/save.php
TL-6310 mod/certificate/adminsetting.class.php
TL-6684 mod/feedback/rb_sources/lang/en/rb_source_feedback_questions.php
TL-6684 mod/feedback/rb_sources/lang/en/rb_source_graphical_feedback_questions.php
TL-6684 mod/feedback/rb_sources/rb_preproc_feedback_questions.php
TL-6684 mod/feedback/rb_sources/rb_source_feedback_questions.php
TL-6684 mod/feedback/rb_sources/rb_source_graphical_feedback_questions.php
TL-6777 totara/core/js/lib/jquery.dataTables.js
TL-6777 totara/core/js/lib/jquery.dataTables.min.js
TL-6777 totara/core/js/lib/jquery.placeholder.js
TL-6777 totara/core/js/lib/jquery.placeholder.min.js
TL-6777 totara/core/js/lib/jquery.treeview.js
TL-6777 totara/core/js/lib/jquery.treeview.min.js
TL-6777 totara/core/js/lib/load.placeholder.js
TL-6777 totara/core/js/lib/readme_totara.txt
TL-6777 totara/core/js/lib/totara_dialog.js
TL-7013 install/lang/ Multiple language files for unsupported languages
TL-7162 totara/appraisal/js/myappraisal.js
TL-7197 totara/plan/templates.js
TL-7198 totara/plan/component.js
TL-7244 totara/cohort/assignroles.js


Contributions:

    * Andrew Hancox at Synergy Learning - TL-6454
    * Dennis Heany at Learning Pool - TL-6525
    * Ryan Lafferty at Learning Pool - TL-4485
    * Eugene Venter at Catalyst NZ - TL-6022, TL-6023, TL-6308, TL-6453, TL-6496, TL-6497, TL-7529
    * Maccabi Healthcare Services a client of Kineo Israel - TL-6684
    * Pavel Tsakalidis at Kineo UK   - TL-6531
    * Russell England at Vision NV - TL-5394

 */
